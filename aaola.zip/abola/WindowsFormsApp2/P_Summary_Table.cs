﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Runtime.InteropServices;
using Microsoft.Office.Interop.Excel;
using Excel = Microsoft.Office.Interop.Excel;
using System.Text.RegularExpressions;
using System.Collections.Generic;

namespace abola
{
    partial class Bolt
    {
        string test_name3;
        int row = 0;
        int row_flow = 0;
        //public List<string> test_name2 = new List<string>();

        public void MakesummaryTable(string mode)
        {

            //ptop_write_data = new object[5000, 200];

            for (int i = 1; i <= 4; i++)
            {
                for (int h = 1; h <= ptop_flow_data.GetLength(1); h++)
                {
                    ptop_write_data[i, h] = ptop_flow_data[i, h]?.ToString();

                }
            }

            for (int i = 1; i < 5; i++)
            {
                for (int j = 1; j <= ptop_instance_data.GetLength(1); j++)
                    ptop_write_data[i, j + 33] = ptop_instance_data[i, j];
            }
            

            row_flow = 4;


            for (int i = 5; i <= ptop_flow_data.GetLength(0); i++)
            {

                int instancecount = 0;

                //test_name2.Add(ptop_flow_data[i, 8]?.ToString());
                test_name3 = ptop_flow_data[i, 8]?.ToString().ToUpper();

                if (mode == "normal")
                {
                    if (test_name3 == "FLAG_CHECK") continue;
                }

                if (mode == "normal")
                {
                    if (ptop_flow_data[i, 7]?.ToString().ToUpper() == "USE-LIMIT") continue;
                }

                if (mode == "normal")
                {
                    if (ptop_flow_data[i, 5]?.ToString().ToUpper() == "DEL") continue;
                }

                if (mode == "normal")
                {
                    if (ptop_flow_data[i, 5]?.ToString().ToUpper() == "DELF") continue;
                }

                if (mode == "normal")
                {
                    if (ptop_flow_data[i, 6]?.ToString().ToUpper() == "DEL") continue;
                }

                if (mode == "normal")
                {
                    if (ptop_flow_data[i, 6]?.ToString().ToUpper() == "DELF") continue;
                }

                if (mode == "normal")
                {
                    if (ptop_flow_data[i, 7]?.ToString().ToUpper() == "FLAG-FALSE-ALL") continue;
                }

                if (mode == "normal")
                {
                    if (ptop_flow_data[i, 7]?.ToString().ToUpper() == "ASSIGN-SITE-VAR") continue;
                }

                if (mode == "normal")
                {
                    if (ptop_flow_data[i, 7]?.ToString().ToUpper() == "BINTABLE") continue;
                }

                if (mode == "normal")
                {
                    if (ptop_flow_data[i, 7]?.ToString().ToUpper() == "SET-DEVICE") continue;
                }

                row = 0;


                for (int k = 5; k <= ptop_instance_data.GetLength(0); k++)
                {
                    if (test_name3 != null && ptop_instance_data[k, 2]?.ToString() != null && ptop_instance_data[k, 2]?.ToString().ToUpper() == test_name3.ToUpper())
                    {
                        instancecount++;
                        row = k;
                    }

                }

                //for (int j = 1; j <= ptop_flow_data.GetLength(1); j++)
                //{
                //    ptop_ss.Cells[i, j] = ptop_flow_data[i, j];
                //}

                for (int s=1;s<= instancecount; s++)
                {
                    row_flow++;

                    int temp = instancecount - s;

                    for (int j = 1; j <= 33; j++)
                    {
                        ptop_write_data[row_flow, j] = ptop_flow_data[i, j];
                    }

                    //for (int j = 1; j <= ptop_instance_data.GetLength(1); j++)
                    //{
                    //    ptop_ss.Cells[i, j + ptop_flow_data.GetLength(1)] = ptop_instance_data[row, j];
                    //}
                    if (row != 0)
                    {
                        for (int j = 1; j <= ptop_instance_data.GetLength(1); j++)
                        {
                            ptop_write_data[row_flow, j + 33] = ptop_instance_data[row-temp, j];
                        }
                    }
                }

                if(instancecount==0)
                {
                    row_flow++;
                    for (int j = 1; j <= 33; j++)
                    {
                        ptop_write_data[row_flow, j] = ptop_flow_data[i, j];
                    }
                }


            }

            //for (int i=1; i<5; i++)
            //{
            //    for (int j = 1; j <= ptop_instance_data.GetLength(1); j++)
            //        ptop_ss.Cells[i, j + ptop_flow_data.GetLength(1)] = ptop_instance_data[i, j];
            //}




            //ptop_summary_range = ptop_ss.UsedRange;
            //ptop_summary_data = ptop_write_data;

        }

        //for (int i = 0; i <= ptop_instance_data.GetLength(0); i++)
        //{
        //    for (int j = 0; j <= ptop_instance_data.GetLength(1); j++)
        //    {
        //        ptop_ss.Cells[i, j] = ptop_instance_data[i, j];
        //    }
        //}


        //        namespace WindowsFormsApp2
        //{
        //    partial class Bolt
        //    {
        //        public void MakeInstanceSheet()
        //        {
        //            this.j = 0;
        //            PotopSheetInit(ate_data);
        //            for (int i = 1; i <= ate_data?.GetLength(0); i++)
        //            {
        //                if (test_name.IndexOf(ate_data[i, 2]?.ToString()) >= 0)
        //                {
        //                    flow_name = "";
        //                    MakeFlowShhet_sub(ate_data, i);
        //                }
        //            }
        //            ptop_instance_range = ptop_ss.UsedRange;
        //            ptop_instance_data = ptop_instance_range.Value2;
        //        }
        //    }
        //}




    }
    }

