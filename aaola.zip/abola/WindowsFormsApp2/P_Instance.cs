﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Runtime.InteropServices;
using Microsoft.Office.Interop.Excel;
using Excel = Microsoft.Office.Interop.Excel;

namespace abola
{
    partial class Bolt
    {


        public void MakeInstanceSheet()
        {
            this.j = 0;


            PotopSheetInit(ate_data);
            

            for (int j = 5; j <= ptop_flow_data.GetLength(0); j++)
            {
                if (ptop_flow_data[j, 8]?.ToString() != null && ptop_flow_data[j, 8]?.ToString() != "FLAG_CHECK")
                {
                    test_name_list.Add(ptop_flow_data[j, 8].ToString());
                }
            }


            for (int i = 1; i <= ate_data?.GetLength(0); i++)
            {
                if (test_name_list.IndexOf(ate_data[i, 2]?.ToString()) >= 0)
                {
                    flow_name = "";
                    MakeFlowShhet_sub(ate_data, i, "instance");
                }
            }
            //ptop_instance_range = ptop_ss.UsedRange;
            //ptop_instance_data = new object[5000, 200];
            //ptop_instance_data = ptop_write_data;

        }
    }
}
