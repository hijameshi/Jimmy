﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Runtime.InteropServices;
using Microsoft.Office.Interop.Excel;
using Excel = Microsoft.Office.Interop.Excel;
using System.Text.RegularExpressions;
using System.IO;

namespace abola
{
    partial class Bolt
    {
        int arg53count = 50;
        List<string> comp_pat = new List<string>();
        List<string> sitevardiff = new List<string>();

        string bira_env_before = "";
        string bira_env_after = "";
        int bira_env_end = 0;
        int bira_env_end_3 = 0;

        int bira_env_cnt = 1;

        static public string bintablenamepublic;

        int flow_num = 1;
        int uselimit_cnt = 0;

        string emptyarg53 = "arg53";

        int k = 0;
        int w = 0;
        int a0; string a1; string a2; string a3; string a4; string a5; string a6; string a7; string a8; string a9; string a10; string a11; string a12; string a13; string a14; string a15; string a16; string a17;
        public StreamWriter flow;
        public StreamWriter sitevarfile;
        public StreamWriter sitevarnot0;

        List<string> pat = new List<string>();
        string split;
        int split_count;

        int flow_first_check = 0;
        string endifcheck = "";
        string temp20 = "";

        string before_var = "";
        int var_cnt = 1;
        int var_cnt_3 = 1;

        List<string> pat_list = new List<string>();

        int check_patset = 0;

        int testnum;

        string G_FLAG_TRUE;
        string G_VAL_TRUE;
        string var;
        string TEST_NAME;
        //string category_job;
        string BIRA_EXEC;

        string g_label_var;
        string g_result_flag_var;
        string g_pass_flag_var;
        string g_fail_flag_var;
        string g_last_fail;

        string HWBin;
        string SWBin;

        string tset;
        string pset;

        string arg3;
        string arg6;
        string arg16;
        string arg19;
        string arg51;
        string arg52;
        string arg53;
        string type_name;

        string StartOfBodyF;
        string PreTestF;
        string PostTestF;
        string EndOfBodyF;

        string StartOfBodyF_name;
        string PreTestF_name;
        string PostTestF_name;
        string EndOfBodyF_name;
        
        string StartOfBodyF_arg;
        string PreTestF_arg;
        string PostTestF_arg;
        string EndOfBodyF_arg;
        
        string UTIL1_PINS;
        string UTIL0_PINS;
        
        int powerset;

        public Worksheet bin_table_sheet;
        public object[,] bin_table_object;
        public Range bin_table_rage;

        public Worksheet flow_bintable_sheet;
        public object[,] flow_bintable_object;
        public Range flow_bintable_range;

        string bt_name = "Flow_BinTable_DFT";

        string arg6name;
        string arg3name;
        int uselimitcrosscheck = 0;

        List<string> timing_file_list = new List<string>();
        string[,] timing_speed;

        int assign_flag_end_point;

        public void MakeFlow_Txt(string timing = "")
        {
            int b5bin_error = 0;
            if (timing == "timing")
            {
                string path = rootsavepath + "\\DAT\\timing";
                if (System.IO.Directory.Exists(path))
                {
                    System.IO.DirectoryInfo di = new System.IO.DirectoryInfo(path);
                    foreach (var item in di.GetFiles())
                    {
                        timing_file_list.Add(item.Name);
                    }
                }
                timing_speed = new string[timing_file_list.Count, 4];

                for (int i = 0; i < timing_file_list.Count; i++)
                {
                    timing_speed[i, 0] = timing_file_list[i];

                    if (timing_file_list[i].Contains("SPDTST"))
                    {
                        string[] listtoarray = new string[2];
                        string list_split;
                        list_split = timing_file_list[i].ToString();
                        listtoarray = list_split.Split(new string[] { "__" }, StringSplitOptions.None);

                        Array.Resize(ref listtoarray, 2);

                        timing_speed[i, 1] = listtoarray[0];
                        timing_speed[i, 1] = timing_speed[i, 1].Replace("_SPDTST", "");
                        timing_speed[i, 1] = timing_speed[i, 1] + ".dat";

                        timing_speed[i, 2] = listtoarray[1];

                        string[] temp1 = new string[2];
                        string temp2;
                        temp2 = timing_speed[i, 2];
                        temp1 = temp2?.Split(new string[] { "_" }, StringSplitOptions.None);
                        Array.Resize(ref temp1, 2);

                        timing_speed[i, 2] = "_" + temp1[0];
                        timing_speed[i, 3] = temp1[1];

                        timing_speed[i, 3] = timing_speed[i, 3].Replace(".dat", "");
                    }
                }
                //timing_speed.sort
            }

            string savePath = rootsavepath + "PTOP_FLOW.c";

            flow = new StreamWriter(new FileStream(savePath, FileMode.Create));
            
            flow.WriteLine("#pragma region flow_table");

            string jobsheetname_1 = "Job";
            string jobsheetname_2 = "Jobs";
            Excel.Worksheet job_sheet;
            int job_choice = 0;

            try
            {
                job_sheet = ate_bb.Worksheets[jobsheetname_1];
                job_choice = 1;
            }
            catch (Exception ex)
            {
                job_sheet = ate_bb.Worksheets[jobsheetname_2];
                job_choice = 2;
            }

            Excel.Range job_sheet_range;
            job_sheet_range = job_sheet.UsedRange;
            object[,] jot_sheet_value = job_sheet_range.Value2;

            string pat_set_name = jot_sheet_value[5, 8]?.ToString().ToUpper();
            //bintablenamepublic = jot_sheet_value[5, 10]?.ToString().ToUpper();

            string pat = "";

            SelectWorksheet("temp", pat_set_name);
            ReadRange("temp");
            CopyToArray("temp");

            string[] patset_name = new string[temp_data.GetLength(0) - 3];

            for (int i = 1; i <= temp_data.GetLength(0) - 3; i++)
            {
                patset_name[i - 1] = temp_data[i + 3, 2].ToString();
            }

            for (int i = 1; i <= ate_data.GetLength(0); i++)
            {
                if (ate_data[i, 5]?.ToString().ToUpper() == "SET" )
                {

                    for (int t = 1; t <= ate_data.GetLength(0); t++)
                    {

                        if (ate_data[i, 22] != null && (ate_data[i, 22]?.ToString() == ate_data[t, 30]?.ToString()) && ate_data[t,8]?.ToString().ToUpper() != "FLAG_CHECK")
                        {
                            row_set = t;
                            //break;
                        }
                    }

                    ate_data[i, 37] = ate_data[row_set, 37];

                    for (int u = 48; u <= ate_data.GetLength(1); u++)
                    {
                        ate_data[i, u] = ate_data[row_set, u];
                    }
                }
            }

            //for(int j =1; j<= ate_data.GetLength(0)-4; j++)
            //{
            //    pat.Add(ate_data[i, 49].ToString());

            //}

            //string[] pat_data = new string[pat.Count()];
            //pat_data = pat.ToArray();

            //string[][] pat_data_split = new string[pat_data.GetLength(0)][];

            //for (int k = 1; k<= ate_data.GetLength(0) - 4; k++)
            //{
            //    split = pat_data[k];
            //    pat_data_split[k] = split.Split(new char[] { ',' }, StringSplitOptions.None);

            //}

            string[] pat_split; // = new string[pat.Count(',').ToString()];
            
            for (w = 5; w <= ate_data.GetLength(0); w++)
            {
                uselimitcrosscheck++;
                
                string before = ate_data[w - 1, 1]?.ToString();
                string after = ate_data[w, 1]?.ToString();
                
                if (w > 4 && (before != after))
                {
                    flow_first_check++;
                    temp20 = ate_data[w, 1].ToString();
                    if (flow_first_check != 1)
                    {
                        flow.WriteLine("#endif // {0}", endifcheck);
                    }
                    flow.WriteLine("\n // Flow : {0}", temp20);
                    flow.WriteLine("#ifndef {0}", temp20);
                    endifcheck = ate_data[w, 1].ToString();
                }

                //if (patset_name.ToString().IndexOf(ate_data[w, 49].ToString()) >= 0)
                //{

                //if (ate_data[w, 5]?.ToString().ToUpper() == "SKIP")
                //{
                //    continue;
                //}

                if (ate_data[w, 5]?.ToString().ToUpper() == "DEL" || ate_data[w, 6]?.ToString().ToUpper() == "DEL")
                {
                    continue;
                }

                string opcode_flag = ate_data[w, 7]?.ToString();

                if (w > assign_flag_end_point && (opcode_flag == "flag-false-all" || opcode_flag == "assign-site-var"))
                {
                    MakeFlow_Txt_assign_sate_var(w, opcode_flag);
                    continue;
                }

                if (ate_data[w, 7]?.ToString().ToUpper() == "SET-DEVICE")
                {
                    if (ate_data[w, 18]?.ToString().ToUpper() == "1")
                    {
                        continue;
                    }
                    MakeFlow_Txt_setdevice_flagcheck(w);
                    continue;

                }

                if (ate_data[w, 5]?.ToString().ToUpper() == "B5BIN" || ate_data[w, 6]?.ToString().ToUpper() == "B5BIN" )
                {
                    MakeFlow_Txt_flagcheck_bira_bin_5(w);
                    continue;
                }

                if (ate_data[w, 5]?.ToString().ToUpper() == "B3BIN" || ate_data[w, 6]?.ToString().ToUpper() == "B3BIN" )
                {
                    MakeFlow_Txt_flagcheck_bira_bin_3(w);
                    continue;
                }

                if(ate_data[w, 7]?.ToString().ToUpper() == "USE-LIMIT" && (ate_data[w, 37]?.ToString().ToUpper() == "PRE_BIRA_BIN_DEFINE" || ate_data[w, 37]?.ToString().ToUpper() == "BIRA_FMIN_FLAG_CHECK" || ate_data[w, 37]?.ToString().ToUpper() == "BIRA_FMAX_FLAG_CHECK"))
                {
                    //MessageBox.Show("Bira Use-Limit 관련 B3BIN, B5BIN missing 존재!!! 확인필요!!!");
                    b5bin_error += 1;
                    continue;
                }

                if (ate_data[w, 7]?.ToString().ToUpper() == "USE-LIMIT")
                {
                    if (ate_data[w, 49]?.ToString() != ate_data[w - 1, 49]?.ToString())
                    {
                        uselimit_cnt = 0;
                    }
                    uselimit_cnt++;
                    MakeUseLimit(w, uselimit_cnt, uselimitcrosscheck);
                    continue;
                }

                uselimit_cnt = 0;
                uselimitcrosscheck = 0;

                if (ate_data[w, 8]?.ToString().ToUpper() == "FLAG_CHECK")
                {
                    MakeFlow_Txt_flagcheck(w);
                    continue;
                }

                //if (ate_data[w, 4]?.ToString() == "ETC")
                //{
                //    string temp = ate_data[w, 8]?.ToString();
                //    MakeFlow_Txt_etc(temp, w);
                //    continue;
                //}

                //if (ate_data[w, 8]?.ToString() == bt_name)
                if (ate_data[w, 4]?.ToString().ToUpper() == "BIN")
                {
                    Makebintable_inflow(w);
                    continue;
                }


                if (ate_data[w, 7]?.ToString().ToUpper() == "BINTABLE")
                {
                    Makebintable(w);
                    continue;
                }

                else
                {
                    for (int k = 1; k <= temp_data.GetLength(0) - 3; k++)
                    {
                        if (ate_data[w, 49]?.ToString() != null && ate_data[w, 49]?.ToString() == temp_data[k, 2]?.ToString())
                        {
                            pat = temp_data[k, 5]?.ToString();

                            pat_split = pat.Split(new char[] { ',' }, StringSplitOptions.None);
                            split_count = pat_split.Length;


                            MakeFlow_Txt_sub(split_count, pat_split, w);

                            check_patset = 1;
                        }
                    }

                    if (ate_data[w, 49]?.ToString() != null && check_patset == 0)
                    {
                        pat = ate_data[w, 49]?.ToString();

                        pat_split = pat.Split(new char[] { ',' }, StringSplitOptions.None);
                        split_count = pat_split.Length;

                        if (ate_data[w, 5]?.ToString().ToUpper() == "MERGE" || ate_data[w, 6]?.ToString().ToUpper() == "MERGE")
                        {
                            string temppat = pat_split[0];
                            temppat = temppat.Replace(".PAT", "_merge.PAT");
                            pat_split[0] = temppat;

                            MakeFlow_Txt_sub(1, pat_split, w);
                        }

                        else
                        {
                            MakeFlow_Txt_sub(split_count, pat_split, w);
                        }

                    }

                    if (ate_data[w, 49]?.ToString() == null)
                    {
                        pat = ate_data[w, 49]?.ToString();

                        pat_split = new string[1];
                        pat_split[0] = ate_data[w, 49]?.ToString();
                        split_count = pat_split.Length;

                        MakeFlow_Txt_sub(1, pat_split, w);

                    }

                    check_patset = 0;

                    //}

                    //else
                    //{


                    //}
                }
            }

            //string[] b = new string[a.Count()];
            //b = a.ToArray();

            //for (int i = 0; i < b.GetLength(0); i++)
            //{
            //    Console.WriteLine(b[i].ToString());
            //}

            //string[][] c = new string[b.GetLength(0)][];
            //for (int j = 0; j < b.GetLength(0); j++)
            //{
            //    d = b[j];
            //    c[j] = d.Split(new string[] { "__" }, StringSplitOptions.None);
            //    for (int q = 0; q < 3; q++)
            //    {
            //        Console.Write(c[j][q].ToString());
            //        MatchCollection matches = Regex.Matches(c[j][q], "a");
            //        int cnt = matches.Count;
            //        Console.WriteLine(cnt.ToString());

            //    }

            flow.WriteLine("#endif // {0}", endifcheck);
            flow.WriteLine("#pragma endregion");

            flow.Close();

            pat_list = pat_list.Distinct().ToList();
            
            MakePatNmaeFile(pat_list, "pat_list");
                       
            string savePath2 = rootsavepath + "sitevar count diff.txt";
            sitevarfile = new StreamWriter(new FileStream(savePath2, FileMode.Create));
            for (int a = 0; a< sitevardiff.Count; a++)
            {
                sitevarfile.WriteLine(sitevardiff[a]);
            }

            sitevarfile.Close();

            if (sitevardiff.Count != 0)
            {
                MessageBox.Show("sitevar 갯수 다름 존재, sitevar count diff.txt 참조");
            }
            if (b5bin_error > 0)
            {
                MessageBox.Show("Bira Use-Limit 관련 B3BIN, B5BIN missing 존재!!! 확인필요!!!");
            }
            //MakeFlgInit(ate_data, "flag");
            //MessageBox.Show("완료");
        }

        public void MakeFlow_Txt_assign_sate_var(int w, string opcode_flag)
        {
            int i = w;

            if (opcode_flag == "flag-false-all")
            {
                string condition_category = "";
                string condition_arg = "1";
                string condition_value = "1";
                if (ate_data[i, 29]?.ToString().ToUpper() == "FLAG-TRUE")
                {
                    condition_category = ate_data[i, 29]?.ToString();
                    condition_arg = ate_data[i, 30]?.ToString();
                    condition_value = "1";
                }
                if (ate_data[i, 29]?.ToString().ToUpper() != null && ate_data[i, 29]?.ToString().ToUpper() != "FLAG-TRUE")
                {
                    MessageBox.Show("flag-false-all condition 에 flag-true 아닌 값 존재");
                }

                string list_split = ate_data[i, 8]?.ToString();
                string G_FLAG_TRUE = list_split;
                string G_VAL_TRUE = "0";
                flow.Write("/*flag-false-all*/ TEST_STEP_IN(testnum, " + '"' + "{0}" + '"' + ", {1}, {2}) ", condition_category, condition_arg, condition_value);
                flow.Write(" {0} = {1};  ", G_FLAG_TRUE, G_VAL_TRUE);
                flow.WriteLine("TEST_STEP_OUT()");
            }

            if (opcode_flag == "assign-site-var")
            {

                string condition_category = "";
                string condition_arg = "1";
                string condition_value = "1";
                if (ate_data[i, 29]?.ToString().ToUpper() == "FLAG-TRUE")
                {
                    condition_category = ate_data[i, 29]?.ToString();
                    condition_arg = ate_data[i, 30]?.ToString();
                    condition_value = "1";
                }
                if (ate_data[i, 29]?.ToString().ToUpper() != null && ate_data[i, 29]?.ToString().ToUpper() != "FLAG-TRUE")
                {
                    MessageBox.Show("assign-site-var condition 에 flag-true 아닌 값 존재");
                }

                string[] listtoarray = new string[2];
                string list_split;
                list_split = ate_data[i, 8]?.ToString();
                listtoarray = list_split.Split(new string[] { " " }, StringSplitOptions.None);
                string G_FLAG_TRUE = listtoarray[0];
                string G_VAL_TRUE = listtoarray[1];

                flow.Write("/*assign-site-var*/ TEST_STEP_IN(testnum, " + '"' + "{0}" + '"' + ", {1}, {2}) ", condition_category, condition_arg, condition_value);
                flow.Write(" {0} = {1};  ", G_FLAG_TRUE, G_VAL_TRUE);
                flow.WriteLine("TEST_STEP_OUT()");
            }
        }

        public void MakeUseLimit_2(int w)
        {
            int i = w;
            flow_num++;

            int testnum = flow_num;

            int i_tnum = testnum;
            string test_name = ate_data[i, 9]?.ToString();
            string SWbin = "-1";
            string HWBin = "-1";

            string category_job = "";
            if (ate_data[i, 4]?.ToString() != null)
            {
                category_job = ate_data[i, 4]?.ToString().ToUpper();
            }

            if (ate_data[i, 19]?.ToString() != null)
            {
                SWbin = ate_data[i, 19]?.ToString();
                HWBin = ate_data[i, 17]?.ToString();
            }

            string fail_flag = "DUMMY_FAIL_FLAG";
            if (ate_data[i, 22]?.ToString() != null)
            {
                fail_flag = ate_data[i, 22]?.ToString();
            }

            string con_flag = "-1";
            string con_falg_val = "-1";

            //if (ate_data[i, 29]?.ToString() == "flag-true")
            //{
            //    con_flag = ate_data[i, 30]?.ToString();
            //    con_falg_val = "1";
            //}

            //if (ate_data[i, 29]?.ToString() == "flag-false")
            //{
            //    con_flag = ate_data[i, 30]?.ToString();
            //    con_falg_val = "0";
            //}


            string con_var = "STRING_ARG_DUMMY";
            string con_var_val = "0";

            //if (ate_data[i, 29]?.ToString() == "site-var=")
            //{
            con_var = ate_data[i, 49]?.ToString();
            con_var_val = ate_data[i, 37]?.ToString();
            //}

            string parameta = ate_data[i, 8]?.ToString();

            string del_before = ate_data[i - 1, 5]?.ToString().ToUpper();
            string del_after = ate_data[i + 1, 5]?.ToString().ToUpper();

            string bira_env = "";

            bira_env_before = ate_data[i - 1, 6]?.ToString();
            if (del_before == "DEL") { bira_env_before = null; }
            bira_env = ate_data[i, 6]?.ToString();
            bira_env_after = ate_data[i + 1, 6]?.ToString();
            if (del_after == "DEL") { bira_env_after = null; }


            //if (bira_env_before != bira_env && bira_env_end == 1)
            //{
            //    if (var_cnt < 5)
            //    {
            //        MessageBox.Show("이전 Bira Use Limit 5개 미만 : " + parameta + " 이전항목!! PGM 확인필요!!");
            //    }
            //}

            if (bira_env_before != bira_env)
            {
                var_cnt = 1;
            }

            if (bira_env_before == bira_env)
            {
                bira_env_end = 0;
                var_cnt++;
            }

            //if (var_cnt > 5)
            //{
            //    MessageBox.Show("Bira Use Limit 5개 초과 확인필요 : " + parameta);
            //}

            flow.WriteLine("/*bira_Use-Limit : {12} {10}*/ testnum++; /*{11}*/ FLAG_CHECK({0}, " + '"' + "{1}" + '"' + ", {2}, {3}, {4}, {5}, {6}, {7}, {8}({9}, {10})); FLAG_CHECK_OUT()", "testnum", test_name, HWBin, SWbin, fail_flag, con_flag, con_falg_val, con_var, con_var_val, con_var, var_cnt, testnum, parameta);
            //flow.WriteLine("testnum++; /*{9}*/ FLAG_CHECK({0}, " + '"' + "{1}" + '"' + ", {2}, {3}, {4}, {5}, {6}, {7}, {8});", "testnum", test_name, SWbin, HWBin, fail_flag, con_flag, con_falg_val, con_var, con_var_val, testnum);

            //test_name, HWBin, SWbin, fail_flag, con_flag, con_falg_val, con_var, con_var_val, con_var, var_cnt, testnum, parameta

            //if (var_cnt == 1)
            //{
            //    flow.WriteLine();
            //    flow.WriteLine("{0}(" + '"' + "{1}" + '"' + ", {2},", con_var_val, parameta, con_var);
            //}
            //if (var_cnt < 5)
            //{
            //    flow.WriteLine('"' + "{0}" + '"' + ", {1},", test_name, fail_flag);
            //}
            //if (var_cnt == 5)
            //{
            //    flow.WriteLine('"' + "{0}" + '"' + ");", test_name);
            //}


            //flow.WriteLine('"' + "{0}" + '"' + ", {1},", test_name, con_flag);
            //flow.WriteLine("{0}(", con_var_val);
            //flow.WriteLine("{0}(", con_var_val);
            //flow.WriteLine("{0}(", con_var_val);
                                 
            if (bira_env != bira_env_after)
            {
                bira_env_end = 1;
                flow.WriteLine();
            }

            //if (bira_env != bira_env_after && bira_env_end == 1)
            //{
            //    if (var_cnt < 5)
            //    {
            //        MessageBox.Show("Bira Use Limit 5개 미만 : " + parameta + " 항목!! PGM 확인필요!!");
            //        //Environment.Exit(0);
            //        //System.Diagnostics.Process.GetCurrentProcess().Kill();
            //        //this.Close();

            //    }
            //}

            //before_var = con_var;
            //FLAG_CHECK(int i_tnum, string test_name, int SWbin, int HWBin, int * fail_flag, int con_flag, int con_falg_val, int con_var, int con_var_val)
        }

        public void MakeFlow_Txt_flagcheck_bira_bin_3(int w)
        {
            int i = w;
            flow_num++;

            int testnum = flow_num;

            int i_tnum = testnum;
            string test_name = ate_data[i, 9]?.ToString();
            string SWbin = "-1";
            string HWBin = "-1";

            string category_job = "";
            if (ate_data[i, 4]?.ToString() != null)
            {
                category_job = ate_data[i, 4]?.ToString().ToUpper();
            }

            if (ate_data[i, 19]?.ToString() != null)
            {
                SWbin = ate_data[i, 19]?.ToString();
                HWBin = ate_data[i, 17]?.ToString();
            }

            string fail_flag = "DUMMY_FAIL_FLAG";
            if (ate_data[i, 22]?.ToString() != null)
            {
                fail_flag = ate_data[i, 22]?.ToString();
            }

            string con_flag = "-1";
            string con_falg_val = "-1";

            //if (ate_data[i, 29]?.ToString() == "flag-true")
            //{
            //    con_flag = ate_data[i, 30]?.ToString();
            //    con_falg_val = "1";
            //}

            //if (ate_data[i, 29]?.ToString() == "flag-false")
            //{
            //    con_flag = ate_data[i, 30]?.ToString();
            //    con_falg_val = "0";
            //}


            string con_var = "STRING_ARG_DUMMY";
            string con_var_val = "0";

            //if (ate_data[i, 29]?.ToString() == "site-var=")
            //{
            con_var = ate_data[i, 48]?.ToString();
            con_var_val = ate_data[i, 37]?.ToString();
            //}

            string parameta = ate_data[i, 8]?.ToString();

            string del_before = ate_data[i - 1, 5]?.ToString().ToUpper();
            string del_after = ate_data[i + 1, 5]?.ToString().ToUpper();

            string bira_env = "";

            bira_env_before = ate_data[i - 1, 6]?.ToString();
            if (del_before == "DEL") { bira_env_before = null; }
            bira_env = ate_data[i, 6]?.ToString();
            bira_env_after = ate_data[i + 1, 6]?.ToString();
            if (del_after == "DEL") { bira_env_after = null; }


            if (bira_env_before != bira_env && bira_env_end_3 == 1)
            {
                if (var_cnt_3 < 3)
                {
                    MessageBox.Show("이전 Bira Use Limit 3개 미만 : " + parameta + " 이전항목!! PGM 확인필요!!");
                }
            }

            if (bira_env_before != bira_env)
            {
                var_cnt_3 = 1;
            }

            if (bira_env_before == bira_env)
            {
                bira_env_end_3 = 0;
                var_cnt_3++;
            }

            if (var_cnt_3 > 3)
            {
                MessageBox.Show("Bira Use Limit 3개 초과 확인필요 : " + parameta);
            }

            string var = ate_data[i, 29]?.ToString();

            string G_FLAG_TRUE = "1";
            string G_VAL_TRUE = "1";


            if (ate_data[i, 30]?.ToString() != null)
            {
                if (ate_data[i, 30].ToString().Contains(" "))
                {
                    string[] listtoarray = new string[2];
                    string list_split;
                    list_split = ate_data[i, 30]?.ToString();
                    listtoarray = list_split.Split(new string[] { " " }, StringSplitOptions.None);
                    G_FLAG_TRUE = listtoarray[0];
                    G_VAL_TRUE = listtoarray[1];
                }
                else
                {
                    G_FLAG_TRUE = ate_data[i, 30].ToString();
                    G_VAL_TRUE = "1";
                }
            }


            //flow.WriteLine("/*bira_Use-Limit : {12} {10}*/ testnum++; /*{11}*/ FLAG_CHECK({0}, " + '"' + "{1}" + '"' + ", {2}, {3}, {4}, {5}, {6}, {7}, {8}({9}, {10})); FLAG_CHECK_OUT()", "testnum", test_name, HWBin, SWbin, fail_flag, con_flag, con_falg_val, con_var, con_var_val, con_var, var_cnt_3, testnum, parameta);
            //flow.WriteLine("testnum++; /*{9}*/ FLAG_CHECK({0}, " + '"' + "{1}" + '"' + ", {2}, {3}, {4}, {5}, {6}, {7}, {8});", "testnum", test_name, SWbin, HWBin, fail_flag, con_flag, con_falg_val, con_var, con_var_val, testnum);

            //test_name, HWBin, SWbin, fail_flag, con_flag, con_falg_val, con_var, con_var_val, con_var, var_cnt_3, testnum, parameta

            if (var_cnt_3 == 1)
            {
                flow.WriteLine();
                flow.WriteLine("TEST_STEP_IN(testnum, " + '"' + "{0}" + '"' + ", {1}, {2})", var, G_FLAG_TRUE, G_VAL_TRUE);
                flow.WriteLine("/*Use-Limit B3BIN*/ {0}(" + '"' + "{1}" + '"' + ", {2},", con_var_val, parameta, con_var);
            }
            if (var_cnt_3 < 3)
            {
                flow.WriteLine("\t\t"+'"' + "{0}" + '"' + ", {1},", test_name, fail_flag);
            }
            if (var_cnt_3 == 3)
            {
                flow.WriteLine("\t\t" + '"' + "{0}" + '"' + ", {1});", test_name, fail_flag);
                //flow.WriteLine("\t\t"+'"' + "{0}" + '"' + ");", test_name);
                flow.WriteLine("TEST_STEP_OUT()");

            }


            //flow.WriteLine('"' + "{0}" + '"' + ", {1},", test_name, con_flag);
            //flow.WriteLine("{0}(", con_var_val);
            //flow.WriteLine("{0}(", con_var_val);
            //flow.WriteLine("{0}(", con_var_val);




            if (bira_env != bira_env_after)
            {
                bira_env_end_3 = 1;
                flow.WriteLine();
            }

            if (bira_env != bira_env_after && bira_env_end_3 == 1)
            {
                if (var_cnt_3 < 3)
                {
                    MessageBox.Show("Bira Use Limit 3개 미만 : " + parameta + " 항목!! PGM 확인필요!!");
                    //Environment.Exit(0);
                    //System.Diagnostics.Process.GetCurrentProcess().Kill();
                    //this.Close();

                }
            }

            //before_var = con_var;
            //FLAG_CHECK(int i_tnum, string test_name, int SWbin, int HWBin, int * fail_flag, int con_flag, int con_falg_val, int con_var, int con_var_val)
        }


        public void MakeFlow_Txt_flagcheck_bira_bin_5(int w)
        {
            int i = w;
            flow_num++;

            int testnum = flow_num;

            int i_tnum = testnum;
            string test_name = ate_data[i, 9]?.ToString();
            string SWbin = "-1";
            string HWBin = "-1";

            string category_job = "";
            if (ate_data[i, 4]?.ToString() != null)
            {
                category_job = ate_data[i, 4]?.ToString().ToUpper();
            }

            if (ate_data[i, 19]?.ToString() != null)
            {
                SWbin = ate_data[i, 19]?.ToString();
                HWBin = ate_data[i, 17]?.ToString();
            }

            string fail_flag = "DUMMY_FAIL_FLAG";
            if (ate_data[i, 22]?.ToString() != null)
            {
                fail_flag = ate_data[i, 22]?.ToString();
            }

            string con_flag = "-1";
            string con_falg_val = "-1";

            //if (ate_data[i, 29]?.ToString() == "flag-true")
            //{
            //    con_flag = ate_data[i, 30]?.ToString();
            //    con_falg_val = "1";
            //}

            //if (ate_data[i, 29]?.ToString() == "flag-false")
            //{
            //    con_flag = ate_data[i, 30]?.ToString();
            //    con_falg_val = "0";
            //}


            string con_var = "STRING_ARG_DUMMY";
            string con_var_val = "0";

            //if (ate_data[i, 29]?.ToString() == "site-var=")
            //{
            con_var = ate_data[i, 49]?.ToString();
            con_var_val = ate_data[i, 37]?.ToString();
            //}

            string parameta = ate_data[i, 8]?.ToString();
            
            string del_before = ate_data[i - 1, 5]?.ToString().ToUpper();
            string del_after = ate_data[i + 1, 5]?.ToString().ToUpper();

            string bira_env = "";
           
            bira_env_before = ate_data[i - 1, 6]?.ToString();
            if (del_before == "DEL") { bira_env_before = null; }
            bira_env = ate_data[i, 6]?.ToString();
            bira_env_after = ate_data[i + 1, 6]?.ToString();
            if (del_after == "DEL") { bira_env_after = null; }


            if (bira_env_before != bira_env && bira_env_end == 1)
            {
                if (var_cnt < 5)
                {
                    MessageBox.Show("이전 Bira Use Limit 5개 미만 : " + parameta + " 이전항목!! PGM 확인필요!!");
                }
            }

            if (bira_env_before != bira_env)
            {
                var_cnt = 1;
            }

            if (bira_env_before == bira_env)
            {
                bira_env_end = 0;
                var_cnt++;
            }

            if (var_cnt > 5)
            {
                MessageBox.Show("Bira Use Limit 5개 초과 확인필요 : "+ parameta);
            }

            //flow.WriteLine("/*bira_Use-Limit : {12} {10}*/ testnum++; /*{11}*/ FLAG_CHECK({0}, " + '"' + "{1}" + '"' + ", {2}, {3}, {4}, {5}, {6}, {7}, {8}({9}, {10})); FLAG_CHECK_OUT()", "testnum", test_name, HWBin, SWbin, fail_flag, con_flag, con_falg_val, con_var, con_var_val, con_var, var_cnt, testnum, parameta);
            //flow.WriteLine("testnum++; /*{9}*/ FLAG_CHECK({0}, " + '"' + "{1}" + '"' + ", {2}, {3}, {4}, {5}, {6}, {7}, {8});", "testnum", test_name, SWbin, HWBin, fail_flag, con_flag, con_falg_val, con_var, con_var_val, testnum);

            //test_name, HWBin, SWbin, fail_flag, con_flag, con_falg_val, con_var, con_var_val, con_var, var_cnt, testnum, parameta


            string var = ate_data[i, 29]?.ToString();

            string G_FLAG_TRUE = "1";
            string G_VAL_TRUE = "1";


            if (ate_data[i, 30]?.ToString() != null)
            {
                if (ate_data[i, 30].ToString().Contains(" "))
                {
                    string[] listtoarray = new string[2];
                    string list_split;
                    list_split = ate_data[i, 30]?.ToString();
                    listtoarray = list_split.Split(new string[] { " " }, StringSplitOptions.None);
                    G_FLAG_TRUE = listtoarray[0];
                    G_VAL_TRUE = listtoarray[1];
                }
                else
                {
                    G_FLAG_TRUE = ate_data[i, 30].ToString();
                    G_VAL_TRUE = "1";
                }
            }


            if (var_cnt == 1)
            {
                flow.WriteLine();
                flow.WriteLine("TEST_STEP_IN(testnum, " + '"' + "{0}" + '"' + ", {1}, {2})", var, G_FLAG_TRUE, G_VAL_TRUE);
                flow.WriteLine("/*Use-Limit B5BIN*/ {0}(" + '"' + "{1}" + '"' + ", {2},", con_var_val, parameta, con_var);
            }
            if (var_cnt < 5)
            {
                flow.WriteLine("\t\t" + '"' + "{0}" + '"' + ", {1},", test_name, fail_flag);
            }
            if (var_cnt == 5)
            {
                //flow.WriteLine("\t\t" + '"' + "{0}" + '"' + ", {1});", test_name, fail_flag);
                flow.WriteLine("\t\t"+'"' + "{0}" + '"' + ");", test_name);
                flow.WriteLine("TEST_STEP_OUT()");

            }


            //flow.WriteLine('"' + "{0}" + '"' + ", {1},", test_name, con_flag);
            //flow.WriteLine("{0}(", con_var_val);
            //flow.WriteLine("{0}(", con_var_val);
            //flow.WriteLine("{0}(", con_var_val);




            if (bira_env != bira_env_after)
            {
                bira_env_end = 1;
                flow.WriteLine();
            }

            if (bira_env != bira_env_after && bira_env_end == 1)
            {
                if (var_cnt < 5)
                {
                    MessageBox.Show("Bira Use Limit 5개 미만 : " + parameta + " 항목!! PGM 확인필요!!");
                    //Environment.Exit(0);
                    //System.Diagnostics.Process.GetCurrentProcess().Kill();
                    //this.Close();

                }
            }

            //before_var = con_var;
            //FLAG_CHECK(int i_tnum, string test_name, int SWbin, int HWBin, int * fail_flag, int con_flag, int con_falg_val, int con_var, int con_var_val)
        }


        public void MakeFlow_Txt_flagcheck_bira_bin_old(int w)
        {
            int i = w;
            flow_num++;

            int testnum = flow_num;

            int i_tnum = testnum;
            string test_name = ate_data[i, 9]?.ToString();
            string SWbin = "-1";
            string HWBin = "-1";

            string category_job = "";
            if (ate_data[i, 4]?.ToString() != null)
            {
                category_job = ate_data[i, 4]?.ToString().ToUpper();
            }

            if (ate_data[i, 19]?.ToString() != null)
            {
                SWbin = ate_data[i, 19]?.ToString();
                HWBin = ate_data[i, 17]?.ToString();
            }

            string fail_flag = "DUMMY_FAIL_FLAG";
            if (ate_data[i, 22]?.ToString() != null)
            {
                fail_flag = ate_data[i, 22]?.ToString();
            }

            string con_flag = "-1";
            string con_falg_val = "-1";

            //if (ate_data[i, 29]?.ToString() == "flag-true")
            //{
            //    con_flag = ate_data[i, 30]?.ToString();
            //    con_falg_val = "1";
            //}

            //if (ate_data[i, 29]?.ToString() == "flag-false")
            //{
            //    con_flag = ate_data[i, 30]?.ToString();
            //    con_falg_val = "0";
            //}


            string con_var = "STRING_ARG_DUMMY";
            string con_var_val = "0";

            //if (ate_data[i, 29]?.ToString() == "site-var=")
            //{
                con_var = ate_data[i, 49]?.ToString();
                con_var_val = ate_data[i, 37]?.ToString();
            //}

            if (con_var == before_var)
            {
                var_cnt++;
            }
            else
            {
                var_cnt = 1;
            }

            string parameta = ate_data[i, 8]?.ToString();


            flow.WriteLine("/*bira_Use-Limit : {12} {10}*/ testnum++; /*{11}*/ FLAG_CHECK({0}, " + '"' + "{1}" + '"' + ", {2}, {3}, {4}, {5}, {6}, {7}, {8}({9}, {10})); FLAG_CHECK_OUT()", "testnum", test_name, HWBin, SWbin, fail_flag, con_flag, con_falg_val, con_var, con_var_val, con_var, var_cnt, testnum, parameta);
            //flow.WriteLine("testnum++; /*{9}*/ FLAG_CHECK({0}, " + '"' + "{1}" + '"' + ", {2}, {3}, {4}, {5}, {6}, {7}, {8});", "testnum", test_name, SWbin, HWBin, fail_flag, con_flag, con_falg_val, con_var, con_var_val, testnum);

            before_var = con_var;

            //FLAG_CHECK(int i_tnum, string test_name, int SWbin, int HWBin, int * fail_flag, int con_flag, int con_falg_val, int con_var, int con_var_val)

        }

        public void MakeFlow_Txt_setdevice_flagcheck(int w)
        {
            int i = w;
            flow_num++;
            
            int testnum = flow_num;

            int i_tnum = testnum;
            string test_name = ate_data[i, 7]?.ToString();
            string SWbin = "-1";
            string HWBin = "-1";

            string category_job = "";
            if (ate_data[i, 4]?.ToString() != null)
            {
                category_job = ate_data[i, 4]?.ToString().ToUpper();
            }

            if (ate_data[i, 19]?.ToString() != null)
            {
                SWbin = ate_data[i, 19]?.ToString();
                HWBin = ate_data[i, 17]?.ToString();
            }

            else if (ate_data[i, 18]?.ToString() != null)
            {
                SWbin = ate_data[i, 18]?.ToString();
                HWBin = ate_data[i, 16]?.ToString();
            }

            string fail_flag = "DUMMY_FAIL_FLAG";
            if (ate_data[i, 22]?.ToString() != null)
            {
                fail_flag = ate_data[i, 22]?.ToString();
            }

            string con_flag = "-1";
            string con_falg_val = "-1";

            if (ate_data[i, 29]?.ToString() == "flag-true")
            {
                con_flag = ate_data[i, 30]?.ToString();
                con_falg_val = "1";
            }

            if (ate_data[i, 29]?.ToString() == "flag-false")
            {
                con_flag = ate_data[i, 30]?.ToString();
                con_falg_val = "0";
            }

            string con_var = "-1";
            string con_var_val = "-1";

            if (ate_data[i, 29]?.ToString() == "site-var=")
            {
                con_var = ate_data[i, 30]?.ToString();
                con_var_val = ate_data[i, 31]?.ToString();
            }

            flow.WriteLine("testnum++; /*{9}*/ FLAG_CHECK({0}, " + '"' + "{1}" + '"' + ", {2}, {3}, {4}, {5}, {6}, {7}, {8}); FLAG_CHECK_OUT()", "testnum", test_name, HWBin, SWbin, fail_flag, con_flag, con_falg_val, con_var, con_var_val, testnum);
            //flow.WriteLine("testnum++; /*{9}*/ FLAG_CHECK({0}, " + '"' + "{1}" + '"' + ", {2}, {3}, {4}, {5}, {6}, {7}, {8});", "testnum", test_name, SWbin, HWBin, fail_flag, con_flag, con_falg_val, con_var, con_var_val, testnum);


            //FLAG_CHECK(int i_tnum, string test_name, int SWbin, int HWBin, int * fail_flag, int con_flag, int con_falg_val, int con_var, int con_var_val)

        }


        public void MakeFlow_Txt_flagcheck(int w)
        {
            int i = w;
            flow_num++;

            int testnum = flow_num;

            int i_tnum = testnum;
            string test_name = ate_data[i, 9]?.ToString();
            string SWbin = "-1";
            string HWBin = "-1";

            string category_job = "";
            if (ate_data[i, 4]?.ToString() != null)
            {
                category_job = ate_data[i, 4]?.ToString().ToUpper();
            }

            if (ate_data[i, 19]?.ToString() != null)
            {
                SWbin = ate_data[i, 19]?.ToString();
                HWBin = ate_data[i, 17]?.ToString();
            }

            string fail_flag = "DUMMY_FAIL_FLAG";
            if (ate_data[i, 22]?.ToString() != null)
            {
                fail_flag = ate_data[i, 22]?.ToString();
            }

            string con_flag = "-1";
            string con_falg_val = "-1";

            if (ate_data[i, 29]?.ToString() == "flag-true")
            {
                con_flag = ate_data[i, 30]?.ToString();
                con_falg_val = "1";
            }

            if (ate_data[i, 29]?.ToString() == "flag-false")
            {
                con_flag = ate_data[i, 30]?.ToString();
                con_falg_val = "0";
            }


            string con_var = "-1";
            string con_var_val = "-1";

            if (ate_data[i, 29]?.ToString() == "site-var=")
            {
                con_var = ate_data[i, 30]?.ToString();
                con_var_val = ate_data[i, 31]?.ToString();
            }

            flow.WriteLine("testnum++; /*{9}*/ FLAG_CHECK({0}, " + '"' + "{1}" + '"' + ", {2}, {3}, {4}, {5}, {6}, {7}, {8}); FLAG_CHECK_OUT()", "testnum", test_name, HWBin, SWbin, fail_flag, con_flag, con_falg_val, con_var, con_var_val, testnum);
            //flow.WriteLine("testnum++; /*{9}*/ FLAG_CHECK({0}, " + '"' + "{1}" + '"' + ", {2}, {3}, {4}, {5}, {6}, {7}, {8});", "testnum", test_name, SWbin, HWBin, fail_flag, con_flag, con_falg_val, con_var, con_var_val, testnum);


            //FLAG_CHECK(int i_tnum, string test_name, int SWbin, int HWBin, int * fail_flag, int con_flag, int con_falg_val, int con_var, int con_var_val)

        }

        int row_set = 0;

        public void MakeFlow_Txt_sub(int counter, string[] pat, int w)
        {
            int i = w;
            string timing = ate_data[i, 43]?.ToString() +"_"+ ate_data[i, 41]?.ToString() + "_" + ate_data[i, 42]?.ToString() + ".dat";

            int timing_cnt = 1;
            List<int> timing_point = new List<int>();

            for (int k=0; k < timing_speed?.GetLength(0);k++ )
            {
                if(timing_speed[k,1] == timing)
                {
                    timing_cnt++;
                    timing_point.Add(k);
                }
            }
            if (timing_cnt>2)
            {
                timing_cnt = timing_cnt - 1;
            }

            for (int g = 1; g <= timing_cnt; g++)
            {
                for (int j = 1; j <= counter; j++)
                {


                    //if (ate_data[i, 29]?.ToString() == "site - var =")
                    //{

                    //    string temp = ate_data[i, 30]?.ToString();
                    //    string temp_val = temp.Substring(temp.Length - 1);
                    //    temp = temp.Replace(" ", "");
                    //    temp = temp.Substring(0, temp.Length - 1);
                    //    string G_FLAG_TRUE = temp;
                    //    //string G_FLAG_TRUE = ate_data[i, 30]?.ToString();
                    //}



                    //a2 = ate_data[i, 8]?.ToString();
                    //a3 = ate_data[i, 11]?.ToString();
                    //a4 = ate_data[i, 12]?.ToString();

                    //a6 = ate_data[i, 22]?.ToString();
                    //a7 = ate_data[i, 22]?.ToString();
                    //a8 = ate_data[i, 22]?.ToString();
                    //a9 = ate_data[i, 22]?.ToString();
                    //a10 = ate_data[i, 22]?.ToString();
                    //a11 = ate_data[i, 22]?.ToString();
                    //a12 = ate_data[i, 22]?.ToString();
                    //a13 = ate_data[i, 22]?.ToString();
                    //a14 = ate_data[i, 22]?.ToString();
                    //a15 = ate_data[i, 22]?.ToString();
                    //a16 = ate_data[i, 22]?.ToString();
                    //a17 = ate_data[i, 22]?.ToString();

                    a5 = pat[j - 1];

                    if (pat[j - 1] != null)
                    {
                        pat_list.Add(a5);

                        string ww = '.' + "\\" + "PATTERN" + "\\";
                        a5 = a5.Replace(ww, "");
                        a5 = a5.Replace(".PAT.gz", ".atp.bin");
                        a5 = a5.Replace(".PAT", ".atp.bin");
                    }


                    if (ate_data[i, 4]?.ToString().ToUpper() == "COMP" || ate_data[i, 5]?.ToString().ToUpper() == "COMP")
                    {
                        pat_list.Add(a5);

                        //string ww = '.' + "\\" + "PATTERN" + "\\";
                        //a5 = a5.Replace(ww, "");
                        //a5 = a5.Replace(".PAT.gz", ".atp.bin");
                        //a5 = a5.Replace(".PAT", ".atp.bin");
                        a5 = a5.Replace("_Modify", "");
                        a5 = a5.Replace("_modi", "");
                        a5 = a5.Replace("_Modi", "");
                        a5 = a5.Replace("_mOdi", "");
                        a5 = a5.Replace("_moDi", "");
                        a5 = a5.Replace("_modI", "");
                        a5 = a5.Replace("_MODI", "");
                        a5 = a5.Replace("_mODI", "");
                        a5 = a5.Replace("_MoDI", "");
                        a5 = a5.Replace("_MOdI", "");
                        a5 = a5.Replace("_MODi", "");
                        a5 = a5.Replace("_moDI", "");
                        a5 = a5.Replace("_ModI", "");
                        a5 = a5.Replace("_MOdi", "");
                        a5 = a5.Replace("_mOdI", "");
                        a5 = a5.Replace("_mODi", "");
                        a5 = a5.Replace("_MoDi", "");
                    }


                    G_FLAG_TRUE = "1";
                    G_VAL_TRUE = "1";
                    var = "";

                    TEST_NAME = ate_data[i, 8]?.ToString();

                    if (timing_cnt>1)
                    {
                        TEST_NAME = ate_data[i, 8]?.ToString() +"_SPDTT"+ "_"+ timing_speed[timing_point[g-1],3];
                    }
                    
                    if (counter > 1)
                    {
                        TEST_NAME = ate_data[i, 8]?.ToString() + "_" + j;

                        if (timing_cnt > 1)
                        {
                            TEST_NAME = ate_data[i, 8]?.ToString() + "_SPDTT" + "_" + timing_speed[timing_point[g-1],3] + "_"+j;
                        }
                    }

                    string category_job = "";
                    if (ate_data[i, 4]?.ToString() != null)
                    {
                        category_job = ate_data[i, 4]?.ToString().ToUpper();
                    }

                    g_label_var = "G_LABEL_DUMMY";
                    g_result_flag_var = "G_RESULT_DUMMY";
                    g_pass_flag_var = "G_PASS_DUMMY";
                    g_fail_flag_var = "G_FAIL_DUMMY";
                    g_last_fail = "G_RESULT_DUMMY";
                    UTIL1_PINS = "";
                    UTIL0_PINS = "";

                    BIRA_EXEC = "BIRA_EXEC";
                    
                    HWBin = "BIN_NONE";
                    SWBin = "BIN_NONE";

                    tset = "";
                    pset = "";


                    if (ate_data[i, 43]?.ToString() != null)
                    {
                        tset = ate_data[i, 43]?.ToString() + "_" + ate_data[i, 41]?.ToString() + "_" + ate_data[i, 42]?.ToString() + '.' + "bin";
                        if (timing_cnt > 1)
                        {
                            timing_speed[timing_point[g - 1], 0] = timing_speed[timing_point[g - 1], 0].Replace(".dat", "");
                            tset = timing_speed[timing_point[g - 1], 0] + '.' + "bin";
                        }
                    }

                    if (ate_data[i, 45]?.ToString() != null)
                    {
                        pset = ate_data[i, 45]?.ToString() + "_" + ate_data[i, 39]?.ToString() + "_" + ate_data[i, 40]?.ToString() + '.' + "bin";
                    }

                    arg3 = "0";
                    arg3name = "";

                    if (ate_data[i, 51]?.ToString() != null)
                    {
                        arg3 = ate_data[i, 51]?.ToString();
                        arg3name = arg3;
                    }

                    //arg3 = ate_data[i, 51]?.ToString();

                    arg6 = "0";
                    arg6name = "";

                    if (ate_data[i, 54]?.ToString() != null)
                    {
                        arg6 = ate_data[i, 54]?.ToString();
                        arg6name = arg6;
                    }


                    StartOfBodyF = "0";
                    StartOfBodyF_name = "";

                    if (ate_data[i, 50]?.ToString() != null)
                    {
                        StartOfBodyF = ate_data[i, 50]?.ToString();
                        StartOfBodyF_name = StartOfBodyF;
                    }

                    PreTestF = "0";
                    PreTestF_name = "";

                    if (ate_data[i, 52]?.ToString() != null)
                    {
                        PreTestF = ate_data[i, 52]?.ToString();
                        PreTestF_name = PreTestF;
                    }

                    PostTestF = "0";
                    PostTestF_name = "";

                    if (ate_data[i, 53]?.ToString() != null)
                    {
                        PostTestF = ate_data[i, 53]?.ToString();
                        PostTestF_name = PostTestF;
                    }

                    EndOfBodyF = "0";
                    EndOfBodyF_name = "";

                    if (ate_data[i, 55]?.ToString() != null)
                    {
                        EndOfBodyF = ate_data[i, 55]?.ToString();
                        EndOfBodyF_name = EndOfBodyF;
                    }



                    arg16 = ate_data[i, 64]?.ToString();
                    arg19 = ate_data[i, 67]?.ToString();

                    arg51 = ate_data[i, 99]?.ToString();

                    arg52 = ate_data[i, 100]?.ToString();

                    arg53 = ate_data[i, 101]?.ToString();


                    StartOfBodyF_arg = ate_data[i, 63]?.ToString();
                    PreTestF_arg = ate_data[i, 65]?.ToString();
                    PostTestF_arg = ate_data[i, 66]?.ToString();
                    EndOfBodyF_arg = ate_data[i, 68]?.ToString();


                    List<string> arg53list = new List<string>();
                    List<string> arg52list = new List<string>();
                    List<string> arg51list = new List<string>();

                    if (arg53 != null)
                    {
                        string[] arg53array;
                        arg53array = arg53.Split(new char[] { '/' }, StringSplitOptions.None);


                        for (int d = 0; d < arg53array.GetLength(0); d++)
                        {
                            arg53list.Add(arg53array[d]);
                        }
                    }

                    if (arg52 != null)
                    {
                        string[] arg52array;
                        arg52array = arg52.Split(new char[] { '/' }, StringSplitOptions.None);


                        for (int d = 0; d < arg52array.GetLength(0); d++)
                        {
                            arg52list.Add(arg52array[d]);
                        }
                    }

                    if (arg51 != null)
                    {
                        string[] arg51array;
                        arg51array = arg51.Split(new char[] { '/' }, StringSplitOptions.None);


                        for (int d = 0; d < arg51array.GetLength(0); d++)
                        {
                            arg51list.Add(arg51array[d]);
                        }
                    }


                    if (arg52list.Count != arg53list.Count || arg51list.Count != arg53list.Count || arg52list.Count != arg51list.Count)
                    {
                        string temp876 = TEST_NAME + "\t\t" + arg51list.Count + ", " + arg52list.Count + ", " + arg53list.Count + "\t\tSITEVAR 갯수 틀림 존재";
                        sitevardiff.Add(temp876);
                        //MessageBox.Show("{0}  SITEVAR 갯수 틀림 존재", TEST_NAME);
                    }


                    if (ate_data[i, 5]?.ToString().ToUpper() == "BLOCK" || ate_data[i, 6]?.ToString().ToUpper() == "BLOCK")
                    {

                        string temp876 = TEST_NAME + "\t\t" + "SUB_BLOCK : " + arg51 + ", " + "SUB_PINS : " + arg52 + "삭제";
                        arg51 = "";
                        arg52 = "";
                        sitevardiff.Add(temp876);
                    }



                    string[] argarraytxt = new string[arg53count];

                    for (int s = 0; s < arg53count; s++)
                    {
                        if (s + 1 <= arg53list.Count)
                        {
                            argarraytxt[s] = arg53list[s];
                        }
                        else
                        {
                            argarraytxt[s] = emptyarg53;
                        }
                    }



                    powerset = 1;

                    if ((ate_data[i, 4]?.ToString().ToUpper() != "COMP" && ate_data[i, 5]?.ToString().ToUpper() != "COMP") && arg6 != null)
                    {
                        if (arg6 != "0")
                        {
                            string temp21 = a5 + "_____" + arg6;
                            comp_pat.Add(temp21);
                        }
                    }


                    if ((ate_data[i, 4]?.ToString().ToUpper() == "COMP" || ate_data[i, 5]?.ToString().ToUpper() == "COMP") && ate_data[i, 54]?.ToString() == null)
                    {
                        comp_pat = comp_pat.Distinct().ToList();
                        arg19 = "COMP";

                        for (int m = 0; m < comp_pat.Count; m++)
                        {
                            string[] comp_pat_arr;
                            string temp77 = comp_pat[m];

                            comp_pat_arr = temp77.Split(new string[] { "_____" }, StringSplitOptions.None);
                            //split_count = pat_split.Length;

                            if (comp_pat_arr[0] == a5)
                            {
                                arg6 = comp_pat_arr[1];
                            }


                        }

                        if (arg6 != "0")
                        {
                            arg6name = arg6;
                        }


                    }

                    //if (ate_data[i, 30]?.ToString() != null)
                    //{
                    //    G_FLAG_TRUE = ate_data[i, 30]?.ToString();
                    //}


                    if (ate_data[i, 29]?.ToString() == "flag-true")
                    {
                        if (ate_data[i, 28]?.ToString().ToUpper() == "NOT")
                        {
                            var = "not flag-true";
                            G_FLAG_TRUE = ate_data[i, 30]?.ToString();
                            G_VAL_TRUE = "0";
                        }
                        else
                        {
                            var = ate_data[i, 29]?.ToString();
                            G_FLAG_TRUE = ate_data[i, 30]?.ToString();
                            G_VAL_TRUE = "1";
                        }
                    }

                    if (ate_data[i, 29]?.ToString() == "site-var=")
                    {
                        var = ate_data[i, 29]?.ToString();
                        G_FLAG_TRUE = ate_data[i, 30]?.ToString();
                        G_VAL_TRUE = ate_data[i, 31]?.ToString();
                    }

                    if (ate_data[i, 29]?.ToString() == "step-fail")
                    {
                        var = ate_data[i, 29]?.ToString();
                        G_FLAG_TRUE = ate_data[i, 30]?.ToString();
                        G_VAL_TRUE = "1";

                        if (ate_data[i, 28]?.ToString().ToUpper() == "NOT")
                        {
                            var = "flag-false";
                            G_VAL_TRUE = "0";
                        }
                    }

                    //if (ate_data[i, 29]?.ToString() == "last-fail") //항목이 여러개로 쪼개지면??
                    //{
                    //    var = ate_data[i, 29]?.ToString();
                    //    G_FLAG_TRUE = g_result_flag_var;
                    //    G_VAL_TRUE = "1";
                    //}

                    if (ate_data[i, 21]?.ToString() != null)
                    {
                        g_pass_flag_var = ate_data[i, 21]?.ToString();

                        if (ate_data[i, 4]?.ToString().ToUpper() == "COMP" || ate_data[i, 5]?.ToString().ToUpper() == "COMP")
                        {
                            string temp22 = ate_data[i, 21]?.ToString();
                            string temp25 = "G_PASS_DUMMY" + " /* " + temp22 + "  need check!! */";

                            g_pass_flag_var = temp25;
                        }
                    }

                    if (ate_data[i, 22]?.ToString() != null)
                    {
                        g_fail_flag_var = ate_data[i, 22]?.ToString();

                        if (ate_data[i, 4]?.ToString().ToUpper() == "COMP" || ate_data[i, 5]?.ToString().ToUpper() == "COMP")
                        {
                            string temp12 = ate_data[i, 22]?.ToString();
                            string temp15 = "G_FAIL_DUMMY" + " /* " + temp12 + "  need check!! */";

                            g_fail_flag_var = temp15;
                        }
                    }

                    if (ate_data[i, 2]?.ToString() != null) // label 
                    {
                        g_label_var = ate_data[i, 2]?.ToString();

                        if (ate_data[i, 4]?.ToString().ToUpper() == "COMP" || ate_data[i, 5]?.ToString().ToUpper() == "COMP")
                        {
                            string temp12 = ate_data[i, 2]?.ToString();
                            string temp15 = "G_LABEL_DUMMY" + " /* " + temp12 + "  need check!! */";

                            g_label_var = temp15;
                        }
                    }

                    if (ate_data[i, 17]?.ToString() != null)
                    {
                        HWBin = ate_data[i, 17]?.ToString();
                    }

                    if (ate_data[i, 19]?.ToString() != null)
                    {
                        SWBin = ate_data[i, 19]?.ToString();
                    }

                    type_name = "";
                    if (ate_data[i, 37]?.ToString() != null)
                    {
                        type_name = ate_data[i, 37]?.ToString();
                    }

                    if (ate_data[i, 69]?.ToString() != null)
                    {
                        UTIL1_PINS = ate_data[i, 69]?.ToString();
                        UTIL1_PINS = UTIL1_PINS.Replace(',', '/');
                    }

                    if (ate_data[i, 70]?.ToString() != null)
                    {
                        UTIL0_PINS = ate_data[i, 70]?.ToString();
                        UTIL0_PINS = UTIL0_PINS.Replace(',', '/');
                    }


                    //flow.WriteLine("TEST_STEP_IN({0}, {1}, {2}", a0, j, ate_data[i, 22]?.ToString());
                    //flow.WriteLine("pf_result = Pat_Test_Func({0}, (char *){1}, (char *){2}, {3}, {4}, (char *)" +
                    //    "{5}, (char*){6}, (char*){7}, {8}, {9}, {10}, {11}, {12}, {13}, {14}, {15}, {16}, {17});",
                    //    a0, a1, a2, a3, a4, a5, a6, a7, a8, a9, a10, a11, a12, a13, a14, a15, a16, a17);
                    //flow.WriteLine("TEST_STEP_OUT({0}, {1}, {2}", a0, "", ate_data[i, 22]?.ToString());
                    //endifcheck = ate_data[i, 1].ToString();

                    //string before = ate_data[i - 1, 1]?.ToString();
                    //string after = ate_data[i, 1]?.ToString();
                    

                    //if (i > 4 && (before != after))
                    //{
                    //    flow_first_check++;
                    //    temp20 = ate_data[i, 1].ToString();
                    //    if (flow_first_check != 1)
                    //    {
                    //        flow.WriteLine("#endif // {0}", endifcheck);
                    //    }
                    //    flow.WriteLine("\n // Flow : {0}", temp20);
                    //    flow.WriteLine("#ifndef {0}", temp20);
                    //    endifcheck = ate_data[i, 1].ToString();
                    //}

                    if (ate_data[i, 5]?.ToString().ToUpper() == "DELF" || ate_data[i, 6]?.ToString().ToUpper() == "DELF")
                    {
                        ONLY_FLAG();
                        continue;

                    }




                    ///////////////// 2020 BIRA 전용 /////////////////
                    if (ate_data[i, 37]?.ToString().ToUpper() == "MENTORBIRA_SOC_MERGE_TEST_VBT" || ate_data[i, 37]?.ToString().ToUpper() == "MENTORBIRA_FRC_LOGIC_VBT")
                    {
                        BIRA_FUNC_2020_TYPE1(i, argarraytxt);
                        continue;
                    }

                    if (ate_data[i, 37]?.ToString().ToUpper() == "MENTORBIRA_LOGIC_VBT")
                    {
                        BIRA_FUNC_2020_TYPE2(i, argarraytxt);
                        continue;
                    }

                    if (ate_data[i, 37]?.ToString().ToUpper() == "CORE_BIRA_PATTERN_MODIFY_AND_BLOW")
                    {
                        CORE_BIRA_PATTERN_MODIFY_AND_BLOW(i, argarraytxt);
                        continue;
                    }

                    if (ate_data[i, 37]?.ToString().ToUpper() == "FRC_BIRA_PATTERN_MODIFY_AND_BLOW")
                    {
                        FRC_BIRA_PATTERN_MODIFY_AND_BLOW(i, argarraytxt);
                        continue;
                    }
                    ///////////////// 2020 BIRA 전용 /////////////////


                    if (ate_data[i, 5]?.ToString().ToUpper() == "FUNC" || ate_data[i, 6]?.ToString().ToUpper() == "FUNC" || ate_data[i, 37]?.ToString().ToUpper() == "MFUNCTIONAL_T" || ate_data[i, 37]?.ToString().ToUpper() == "FUNCTIONAL_T" || ate_data[i, 37]?.ToString().ToUpper() == "FFUNCTIONAL_T")
                    {
                        MFunctional_T(i, argarraytxt);
                    }




                    //else if (ate_data[i, 37]?.ToString() == "PATTERN_START_FUNC" )
                    //{

                    //    for (int t=1; t<=ate_data.GetLength(0); t++)
                    //    {

                    //        if(ate_data[i, 22] != null && (ate_data[i, 22]?.ToString() == ate_data[t, 30]?.ToString()))
                    //        {
                    //            row_set = t;
                    //            break;
                    //        }
                    //    }

                    //    for (int u = 34; u <= ate_data.GetLength(1); u++)
                    //    {
                    //        ate_data[i, u] = ate_data[row_set, u];
                    //    }

                    //        MFunctional_T(i);

                    //    row_set = 0;

                    //}


                    else if (ate_data[i, 37]?.ToString().ToUpper() == "TMU_SENSE_DEFAULT_HOT")
                    {
                        TMU_SENSE_DEFAULT_HOT(i, argarraytxt);
                    }


                    else if (ate_data[i, 5]?.ToString().ToUpper() == "VBT" || ate_data[i, 6]?.ToString().ToUpper() == "VBT")
                    {
                        MakeVBT();
                        break;
                    }

                    else
                    {
                        flow_ETC();
                    }


                    //"S5E9820_pp_OTP_FUNC_test_CHIP_ID_read_all_vrda_trim_V000_18012517.atp.bin",//	string pat_filename,	// = NULL,


                    //flow.WriteLine("TEST_STEP_IN(testoffset + {0}, {1}, {2}", a0, i, g_Flag_Variable[testnum]);
                    //    pf_result = Pat_Test_Func(testoffset + testnum,
                    //    (char*)"BN9DD0_SA_99P_HV", (char*)"BN9DD0_SA_99P_HV", LOLIM_PAT, HILIM_PAT,
                    //        (char*)"S5E9820_pp_GPU_BN9DD_EVT1_SA_COMP_SUB0_6_V000_18061810.atp.bin", (char*)"TSET_E_BN9DD_SA_T_10MHz_SEL0.bin", (char*)"PSET_Level_DEF_SCAN_VDD_SCAN_SEL2.bin",
                    //        PBIN_SKIP, 11, SBIN_SKIP, 111, DC_SETON, g_Flag_Variable[testnum], S_FLAG_PATTEST, g_Flag_Variable[testnum], g_FlagP_Variable[testnum], g_FlagF_Variable[testnum], G_BN9DD0_99P_PINS);
                    //TEST_STEP_OUT(testoffset + testnum, "", g_Flag_Variable[testnum])

                }
            }

        }

        public void BIRA_FUNC_2020_TYPE1(int i, string[] argarraytxt)
        {
            flow_num++;
            testnum = flow_num;

            string PROCEDURE_NAME = "";
            string OutputPins = "";
            string LVCC_HVCC = "";
            string CORE_NAME = "";

            if (ate_data[i, 37]?.ToString() != null)
            {
                PROCEDURE_NAME = ate_data[i, 37]?.ToString();
            }

            if (ate_data[i, 50]?.ToString() != null)
            {
                OutputPins = ate_data[i, 50]?.ToString();
            }

            if (ate_data[i, 52]?.ToString() != null)
            {
                LVCC_HVCC = ate_data[i, 52]?.ToString();
            }

            if (ate_data[i, 55]?.ToString() != null)
            {
                CORE_NAME = ate_data[i, 55]?.ToString();
            }

            if (ate_data[i, 6]?.ToString() == null && ate_data[i, 5]?.ToString().ToUpper() == "SKIP")
            {
                flow.WriteLine();
                flow.WriteLine("if (!FAILITEM_SKIP)");
                flow.WriteLine("{");
            }

            else if (ate_data[i, 6]?.ToString() != null && ate_data[i, 5]?.ToString().ToUpper() == "SKIP")
            {

                string endcnt = ate_data[i, 6]?.ToString();
                MatchCollection matches = Regex.Matches(endcnt, ",");
                int cnt = matches.Count;

                if (cnt == 0)
                {
                    string temp_val = TEST_NAME.Substring(TEST_NAME.Length - 1);

                    if (endcnt == temp_val)
                    {
                        flow.WriteLine();
                        flow.WriteLine("if (!FAILITEM_SKIP)");
                        flow.WriteLine("{");
                    }
                }

                else if (cnt != 0)
                {
                    string[] cntarr;
                    cntarr = endcnt.Split(new char[] { ',' }, StringSplitOptions.None);


                    for (int x = 0; x < cntarr.GetLength(0); x++)
                    {
                        string temp_val = TEST_NAME.Substring(TEST_NAME.Length - 1);

                        if (cntarr[x] == temp_val)
                        {
                            flow.WriteLine();
                            flow.WriteLine("if (!FAILITEM_SKIP)");
                            flow.WriteLine("{");
                        }

                    }
                }
            }


            flow.WriteLine();
            flow.WriteLine("testnum++; /*{0}*/;", testnum);
            //flow.WriteLine("tl_pcie_reg_write(0, 0x00140000, 0x0000);   //Set MCG CLK OUT");
            flow.WriteLine("TEST_STEP_IN(testnum, " + '"' + "{0}" + '"' + ", {1}, {2})", var, G_FLAG_TRUE, G_VAL_TRUE);
            //flow.WriteLine("\tMFunctional_T(");
            flow.WriteLine("\t{0}(", PROCEDURE_NAME);
            flow.WriteLine("\t\ttestnum,");
            //flow.WriteLine("\t\t" + '"' + "{0}" + '"' + ',' + " //category_job", category_job);
            flow.WriteLine("\t\t" + '"' + "{0}" + '"' + ',' + " //test_name", TEST_NAME);
            //flow.WriteLine("\t\t{0},//	int g_exec_flag_var,	// = -1,	// Exec(1), Skip(0)", G_FLAG_TRUE);
            //flow.WriteLine("\t\t{0},//	int &g_label_var,	// = 0,	", g_label_var);
            flow.WriteLine("\t\t{0},//	int &g_result_flag_var,	// = 0,	", g_result_flag_var);
            flow.WriteLine("\t\t{0},//	int &g_pass_flag_var,	// = 0, ", g_pass_flag_var);
            flow.WriteLine("\t\t{0},//	int &g_fail_flag_var,	// = 0, ", g_fail_flag_var);
            flow.WriteLine("\t\t{0},//	int HWBin,			// = 0, ", HWBin);
            flow.WriteLine("\t\t{0},//	int SWBin,			// = 0, ", SWBin);
            flow.WriteLine("\t\t" + '"' + "{0}" + '"' + ",//	string pat_filename,	// = NULL,", a5);
            flow.WriteLine("\t\t" + '"' + "{0}" + '"' + ",//	string tset_filename,	// = NULL,", tset);
            flow.WriteLine("\t\t" + '"' + "{0}" + '"' + ",//	string pwrset_filename,	// = NULL,", pset);
            //flow.WriteLine("\t\t" + '"' + "{0}" + '"' + ",//	string PrePatF = " + '"' + '"' + ",//arg3", arg3);
            //flow.WriteLine("\t\t{0}, " + '"' + "{1}" + '"' + ", " + '"' + "{2}" + '"' + ", //	string StartOfBodyF = 0, string StartOfBodyF_name = " + '"' + '"' + ", string StartOfBodyF_arg = " + '"' + '"', StartOfBodyF, StartOfBodyF_name, StartOfBodyF_arg);
            //flow.WriteLine("\t\t{0}, " + '"' + "{1}" + '"' + ", //	string PrePatF = 0,//arg3, string PrePatFname = " + '"' + '"', arg3, arg3name);
            //flow.WriteLine("\t\t" + '"' + "{0}" + '"' + ",//	string PrePatFArgs = " + '"' + '"' + ",//arg16", arg16);
            //flow.WriteLine("\t\t{0}, " + '"' + "{1}" + '"' + ", " + '"' + "{2}" + '"' + ", //	string PrePatF = 0, string PrePatFname = " + '"' + '"' + ", string PrePatFArgs = " + '"' + '"', arg3, arg3name, arg16);
            //flow.WriteLine("\t\t{0}, " + '"' + "{1}" + '"' + ", " + '"' + "{2}" + '"' + ", //	string PreTestF = 0, string PreTestF_name = " + '"' + '"' + ", string PreTestF_arg = " + '"' + '"', PreTestF, PreTestF_name, PreTestF_arg);
            //flow.WriteLine("\t\t" + '"' + "{0}" + '"' + ",//	string PostPatF = " + '"' + '"' + ",//arg6", arg6);
            //flow.WriteLine("\t\t{0}, " + '"' + "{1}" + '"' + ", " + '"' + "{2}" + '"' + ", //	string PostTestF = 0, string PostTestF_name = " + '"' + '"' + ", string PostTestF_arg = " + '"' + '"', PostTestF, PostTestF_name, PostTestF_arg);
            //flow.WriteLine("\t\t{0}, " + '"' + "{1}" + '"' + ", //	string PostPatF = 0,//arg6, string PostPatFname = "+'"'+'"', arg6, arg6name);
            //flow.WriteLine("\t\t" + '"' + "{0}" + '"' + ",//	string PostPatFArg = " + '"' + '"' + ",//arg19", arg19);
            //flow.WriteLine("\t\t{0}, " + '"' + "{1}" + '"' + ", " + '"' + "{2}" + '"' + ", //	string PostPatF = 0, string PostPatFname = " + '"' + '"' + ", string PostPatFArg = " + '"' + '"', arg6, arg6name, arg19);
            //flow.WriteLine("\t\t{0}, " + '"' + "{1}" + '"' + ", " + '"' + "{2}" + '"' + ", //	string EndOfBodyF = 0, string EndOfBodyF_name = " + '"' + '"' + ", string EndOfBodyF_arg = " + '"' + '"', EndOfBodyF, EndOfBodyF_name, EndOfBodyF_arg);
            //flow.WriteLine("\t\t" + '"' + "{0}" + '"' + ",//	string SUB_BLOCK = " + '"' + '"' + ",//arg51", arg51);
            //flow.WriteLine("\t\t" + '"' + "{0}" + '"' + ",//	string SUB_PINS = " + '"' + '"' + ",//arg52", arg52);
            //flow.WriteLine("\t\t" + '"' + "{0}" + '"' + ",//	string SITEVAR = " + '"' + '"' + ",//arg53", arg53);
            //flow.Write("\t\t");
            //for (int b = 0; b < arg53count; b++)
            //{
                //flow.Write("{0}, ", argarraytxt[b]); //	string SITEVAR = " + '"' + '"' + ",//arg53", arg53);
            //}
            //flow.Write(" //SITEVAR //arg53");
            //flow.WriteLine();
            flow.WriteLine("\t\t{0}, //	int g_dcon_flag_var = 1;	//1:powerset, 0:powerset skip", powerset);
            //flow.WriteLine("\t\t" + '"' + "{0}" + '"' + ", //	string UTIL1_PINS = " + '"' + '"' + ',', UTIL1_PINS);
            //flow.WriteLine("\t\t" + '"' + "{0}" + '"' + ", //	string UTIL0_PINS = " + '"' + '"' + ',', UTIL0_PINS);
            flow.WriteLine("\t\t{0},  //	int &g_label_var = 0,", g_label_var);

            //flow.WriteLine("\t\t{0}, " + '"' + "{1}" + '"' + ", " + '"' + "{2}" + '"' + ", //	string StartOfBodyF = 0, string StartOfBodyF_name = " + '"' + '"' + ", string StartOfBodyF_arg = "+'"'+'"' , StartOfBodyF, StartOfBodyF_name, StartOfBodyF_arg);
            //flow.WriteLine("\t\t{0}, " + '"' + "{1}" + '"' + ", " + '"' + "{2}" + '"' + ", //	string PreTestF = 0, string PreTestF_name = " + '"' + '"' + ", string PreTestF_arg = " + '"' + '"', PreTestF, PreTestF_name, PreTestF_arg);
            //flow.WriteLine("\t\t{0}, " + '"' + "{1}" + '"' + ", " + '"' + "{2}" + '"' + ", //	string PostTestF = 0, string PostTestF_name = " + '"' + '"' + ", string PostTestF_arg = " + '"' + '"', PostTestF, PostTestF_name, PostTestF_arg);
            //flow.WriteLine("\t\t{0}, " + '"' + "{1}" + '"' + ", " + '"' + "{2}" + '"' + " //	string EndOfBodyF = 0, string EndOfBodyF_name = " + '"' + '"' + ", string EndOfBodyF_arg = " + '"' + '"', EndOfBodyF, EndOfBodyF_name, EndOfBodyF_arg);

            flow.WriteLine("\t\t{0}, //int bira_exec_flag, ", BIRA_EXEC);
            flow.WriteLine("\t\t" + '"' + "{0}" + '"' + ", //string OutputPins ", OutputPins);
            flow.WriteLine("\t\t" + '"' + "{0}" + '"' + ", //string LVCC_HVCC ", LVCC_HVCC);
            flow.WriteLine("\t\t" + '"' + "{0}" + '"' + " //string CORE_NAME ", CORE_NAME);


            flow.WriteLine("\t);");
            flow.WriteLine("TEST_STEP_OUT()");
            //flow.WriteLine("TEST_STEP_OUT(testnum, " + '"' + "{0}" + '"' + ", {1}, {2})", var, G_FLAG_TRUE, G_VAL_TRUE);
            flow.WriteLine();

            if (ate_data[i, 6]?.ToString() == null && ate_data[i, 5]?.ToString().ToUpper() == "SKIP")
            {
                flow.WriteLine("}");
                flow.WriteLine();
            }


            else if (ate_data[i, 6]?.ToString() != null && ate_data[i, 5]?.ToString().ToUpper() == "SKIP")
            {

                string endcnt = ate_data[i, 6]?.ToString();
                MatchCollection matches = Regex.Matches(endcnt, ",");
                int cnt = matches.Count;

                if (cnt == 0)
                {
                    string temp_val = TEST_NAME.Substring(TEST_NAME.Length - 1);

                    if (endcnt == temp_val)
                    {
                        flow.WriteLine("}");
                    }
                }

                else if (cnt != 0)
                {
                    string[] cntarr;
                    cntarr = endcnt.Split(new char[] { ',' }, StringSplitOptions.None);


                    for (int x = 0; x < cntarr.GetLength(0); x++)
                    {
                        string temp_val = TEST_NAME.Substring(TEST_NAME.Length - 1);

                        if (cntarr[x] == temp_val)
                        {
                            flow.WriteLine("}");
                        }

                    }
                }
            }
        }

        public void BIRA_FUNC_2020_TYPE2(int i, string[] argarraytxt)
        {
            flow_num++;
            testnum = flow_num;

            string PROCEDURE_NAME = "";
            string INFO_File = "";
            string OutputPins = "";
            string First_Compare_Cycle = "";
            string PreTestBitCount = "";
            string FirstRepairCycle = "";
            string LastRepairCycle = "";
            string ErrorDataStartCycle = "";
            string ErrorDataBitCount = "";
            string TotalFailBitCount = "";
            string LVCC_HVCC = "";
            string CORE_Name = "";
            string CORE_NUM = "";
            string RIP_Start_Line = "";

            if (ate_data[i, 37]?.ToString() != null)
            {
                PROCEDURE_NAME = ate_data[i, 37]?.ToString();
            }

            if (ate_data[i, 50]?.ToString() != null)
            {
                INFO_File = ate_data[i, 50]?.ToString();
            }

            if (ate_data[i, 51]?.ToString() != null)
            {
                OutputPins = ate_data[i, 51]?.ToString();
            }

            if (ate_data[i, 52]?.ToString() != null)
            {
                First_Compare_Cycle = ate_data[i, 52]?.ToString();
            }

            if (ate_data[i, 53]?.ToString() != null)
            {
                PreTestBitCount = ate_data[i, 53]?.ToString();
            }

            if (ate_data[i, 54]?.ToString() != null)
            {
                FirstRepairCycle = ate_data[i, 54]?.ToString();
            }

            if (ate_data[i, 55]?.ToString() != null)
            {
                LastRepairCycle = ate_data[i, 55]?.ToString();
            }

            if (ate_data[i, 56]?.ToString() != null)
            {
                ErrorDataStartCycle = ate_data[i, 56]?.ToString();
            }

            if (ate_data[i, 57]?.ToString() != null)
            {
                ErrorDataBitCount = ate_data[i, 57]?.ToString();
            }

            if (ate_data[i, 58]?.ToString() != null)
            {
                TotalFailBitCount = ate_data[i, 58]?.ToString();
            }

            if (ate_data[i, 59]?.ToString() != null)
            {
                LVCC_HVCC = ate_data[i, 59]?.ToString();
            }

            if (ate_data[i, 62]?.ToString() != null)
            {
                CORE_Name = ate_data[i, 62]?.ToString();
            }

            if (ate_data[i, 63]?.ToString() != null)
            {
                CORE_NUM = ate_data[i, 63]?.ToString();
            }

            if (ate_data[i, 64]?.ToString() != null)
            {
                RIP_Start_Line = ate_data[i, 64]?.ToString();
            }


            if (ate_data[i, 6]?.ToString() == null && ate_data[i, 5]?.ToString().ToUpper() == "SKIP")
            {
                flow.WriteLine();
                flow.WriteLine("if (!FAILITEM_SKIP)");
                flow.WriteLine("{");
            }

            else if (ate_data[i, 6]?.ToString() != null && ate_data[i, 5]?.ToString().ToUpper() == "SKIP")
            {

                string endcnt = ate_data[i, 6]?.ToString();
                MatchCollection matches = Regex.Matches(endcnt, ",");
                int cnt = matches.Count;

                if (cnt == 0)
                {
                    string temp_val = TEST_NAME.Substring(TEST_NAME.Length - 1);

                    if (endcnt == temp_val)
                    {
                        flow.WriteLine();
                        flow.WriteLine("if (!FAILITEM_SKIP)");
                        flow.WriteLine("{");
                    }
                }

                else if (cnt != 0)
                {
                    string[] cntarr;
                    cntarr = endcnt.Split(new char[] { ',' }, StringSplitOptions.None);


                    for (int x = 0; x < cntarr.GetLength(0); x++)
                    {
                        string temp_val = TEST_NAME.Substring(TEST_NAME.Length - 1);

                        if (cntarr[x] == temp_val)
                        {
                            flow.WriteLine();
                            flow.WriteLine("if (!FAILITEM_SKIP)");
                            flow.WriteLine("{");
                        }

                    }
                }
            }


            flow.WriteLine();
            flow.WriteLine("testnum++; /*{0}*/;", testnum);
            //flow.WriteLine("tl_pcie_reg_write(0, 0x00140000, 0x0000);   //Set MCG CLK OUT");
            flow.WriteLine("TEST_STEP_IN(testnum, " + '"' + "{0}" + '"' + ", {1}, {2})", var, G_FLAG_TRUE, G_VAL_TRUE);
            //flow.WriteLine("\tMFunctional_T(");
            flow.WriteLine("\t{0}(", PROCEDURE_NAME);
            flow.WriteLine("\t\ttestnum,");
            //flow.WriteLine("\t\t" + '"' + "{0}" + '"' + ',' + " //category_job", category_job);
            flow.WriteLine("\t\t" + '"' + "{0}" + '"' + ',' + " //test_name", TEST_NAME);
            //flow.WriteLine("\t\t{0},//	int g_exec_flag_var,	// = -1,	// Exec(1), Skip(0)", G_FLAG_TRUE);
            //flow.WriteLine("\t\t{0},//	int &g_label_var,	// = 0,	", g_label_var);
            flow.WriteLine("\t\t{0},//	int &g_result_flag_var,	// = 0,	", g_result_flag_var);
            flow.WriteLine("\t\t{0},//	int &g_pass_flag_var,	// = 0, ", g_pass_flag_var);
            flow.WriteLine("\t\t{0},//	int &g_fail_flag_var,	// = 0, ", g_fail_flag_var);
            flow.WriteLine("\t\t{0},//	int HWBin,			// = 0, ", HWBin);
            flow.WriteLine("\t\t{0},//	int SWBin,			// = 0, ", SWBin);
            flow.WriteLine("\t\t" + '"' + "{0}" + '"' + ",//	string pat_filename,	// = NULL,", a5);
            flow.WriteLine("\t\t" + '"' + "{0}" + '"' + ",//	string tset_filename,	// = NULL,", tset);
            flow.WriteLine("\t\t" + '"' + "{0}" + '"' + ",//	string pwrset_filename,	// = NULL,", pset);
            //flow.WriteLine("\t\t" + '"' + "{0}" + '"' + ",//	string PrePatF = " + '"' + '"' + ",//arg3", arg3);
            //flow.WriteLine("\t\t{0}, " + '"' + "{1}" + '"' + ", " + '"' + "{2}" + '"' + ", //	string StartOfBodyF = 0, string StartOfBodyF_name = " + '"' + '"' + ", string StartOfBodyF_arg = " + '"' + '"', StartOfBodyF, StartOfBodyF_name, StartOfBodyF_arg);
            //flow.WriteLine("\t\t{0}, " + '"' + "{1}" + '"' + ", //	string PrePatF = 0,//arg3, string PrePatFname = " + '"' + '"', arg3, arg3name);
            //flow.WriteLine("\t\t" + '"' + "{0}" + '"' + ",//	string PrePatFArgs = " + '"' + '"' + ",//arg16", arg16);
            //flow.WriteLine("\t\t{0}, " + '"' + "{1}" + '"' + ", " + '"' + "{2}" + '"' + ", //	string PrePatF = 0, string PrePatFname = " + '"' + '"' + ", string PrePatFArgs = " + '"' + '"', arg3, arg3name, arg16);
            //flow.WriteLine("\t\t{0}, " + '"' + "{1}" + '"' + ", " + '"' + "{2}" + '"' + ", //	string PreTestF = 0, string PreTestF_name = " + '"' + '"' + ", string PreTestF_arg = " + '"' + '"', PreTestF, PreTestF_name, PreTestF_arg);
            //flow.WriteLine("\t\t" + '"' + "{0}" + '"' + ",//	string PostPatF = " + '"' + '"' + ",//arg6", arg6);
            //flow.WriteLine("\t\t{0}, " + '"' + "{1}" + '"' + ", " + '"' + "{2}" + '"' + ", //	string PostTestF = 0, string PostTestF_name = " + '"' + '"' + ", string PostTestF_arg = " + '"' + '"', PostTestF, PostTestF_name, PostTestF_arg);
            //flow.WriteLine("\t\t{0}, " + '"' + "{1}" + '"' + ", //	string PostPatF = 0,//arg6, string PostPatFname = "+'"'+'"', arg6, arg6name);
            //flow.WriteLine("\t\t" + '"' + "{0}" + '"' + ",//	string PostPatFArg = " + '"' + '"' + ",//arg19", arg19);
            //flow.WriteLine("\t\t{0}, " + '"' + "{1}" + '"' + ", " + '"' + "{2}" + '"' + ", //	string PostPatF = 0, string PostPatFname = " + '"' + '"' + ", string PostPatFArg = " + '"' + '"', arg6, arg6name, arg19);
            //flow.WriteLine("\t\t{0}, " + '"' + "{1}" + '"' + ", " + '"' + "{2}" + '"' + ", //	string EndOfBodyF = 0, string EndOfBodyF_name = " + '"' + '"' + ", string EndOfBodyF_arg = " + '"' + '"', EndOfBodyF, EndOfBodyF_name, EndOfBodyF_arg);
            //flow.WriteLine("\t\t" + '"' + "{0}" + '"' + ",//	string SUB_BLOCK = " + '"' + '"' + ",//arg51", arg51);
            //flow.WriteLine("\t\t" + '"' + "{0}" + '"' + ",//	string SUB_PINS = " + '"' + '"' + ",//arg52", arg52);
            //flow.WriteLine("\t\t" + '"' + "{0}" + '"' + ",//	string SITEVAR = " + '"' + '"' + ",//arg53", arg53);
            //flow.Write("\t\t");
            //for (int b = 0; b < arg53count; b++)
            //{
            //flow.Write("{0}, ", argarraytxt[b]); //	string SITEVAR = " + '"' + '"' + ",//arg53", arg53);
            //}
            //flow.Write(" //SITEVAR //arg53");
            //flow.WriteLine();
            flow.WriteLine("\t\t{0}, //	int g_dcon_flag_var = 1;	//1:powerset, 0:powerset skip", powerset);
            //flow.WriteLine("\t\t" + '"' + "{0}" + '"' + ", //	string UTIL1_PINS = " + '"' + '"' + ',', UTIL1_PINS);
            //flow.WriteLine("\t\t" + '"' + "{0}" + '"' + ", //	string UTIL0_PINS = " + '"' + '"' + ',', UTIL0_PINS);
            flow.WriteLine("\t\t{0},  //	int &g_label_var = 0,", g_label_var);

            //flow.WriteLine("\t\t{0}, " + '"' + "{1}" + '"' + ", " + '"' + "{2}" + '"' + ", //	string StartOfBodyF = 0, string StartOfBodyF_name = " + '"' + '"' + ", string StartOfBodyF_arg = "+'"'+'"' , StartOfBodyF, StartOfBodyF_name, StartOfBodyF_arg);
            //flow.WriteLine("\t\t{0}, " + '"' + "{1}" + '"' + ", " + '"' + "{2}" + '"' + ", //	string PreTestF = 0, string PreTestF_name = " + '"' + '"' + ", string PreTestF_arg = " + '"' + '"', PreTestF, PreTestF_name, PreTestF_arg);
            //flow.WriteLine("\t\t{0}, " + '"' + "{1}" + '"' + ", " + '"' + "{2}" + '"' + ", //	string PostTestF = 0, string PostTestF_name = " + '"' + '"' + ", string PostTestF_arg = " + '"' + '"', PostTestF, PostTestF_name, PostTestF_arg);
            //flow.WriteLine("\t\t{0}, " + '"' + "{1}" + '"' + ", " + '"' + "{2}" + '"' + " //	string EndOfBodyF = 0, string EndOfBodyF_name = " + '"' + '"' + ", string EndOfBodyF_arg = " + '"' + '"', EndOfBodyF, EndOfBodyF_name, EndOfBodyF_arg);

            flow.WriteLine("\t\t{0}, //int bira_exec_flag, ", BIRA_EXEC);
            flow.WriteLine("\t\t" + '"' + "{0}" + '"' + ", //string INFO_File ", INFO_File);
            flow.WriteLine("\t\t" + '"' + "{0}" + '"' + ", //string OutputPins ", OutputPins);
            flow.WriteLine("\t\t{0}, //unsigned int First_Compare_Cycle ", First_Compare_Cycle);
            flow.WriteLine("\t\t{0}, //unsigned int PreTestBitCount ", PreTestBitCount);
            flow.WriteLine("\t\t{0}, //unsigned int FirstRepairCycle ", FirstRepairCycle);
            flow.WriteLine("\t\t{0}, //unsigned int LastRepairCycle ", LastRepairCycle);
            flow.WriteLine("\t\t{0}, //unsigned int ErrorDataStartCycle ", ErrorDataStartCycle);
            flow.WriteLine("\t\t{0}, //unsigned int ErrorDataBitCount ", ErrorDataBitCount);
            flow.WriteLine("\t\t{0}, //unsigned int TotalFailBitCount ", TotalFailBitCount);
            flow.WriteLine("\t\t" + '"' + "{0}" + '"' + ", //string LVCC_HVCC ", LVCC_HVCC);
            flow.WriteLine("\t\t" + '"' + "{0}" + '"' + ", //string CORE_Name ", CORE_Name);
            flow.WriteLine("\t\t{0}, //unsigned int CORE_NUM ", CORE_NUM);
            flow.WriteLine("\t\t{0} //unsigned int RIP_Start_Line ", RIP_Start_Line);


            flow.WriteLine("\t);");
            flow.WriteLine("TEST_STEP_OUT()");
            //flow.WriteLine("TEST_STEP_OUT(testnum, " + '"' + "{0}" + '"' + ", {1}, {2})", var, G_FLAG_TRUE, G_VAL_TRUE);
            flow.WriteLine();

            if (ate_data[i, 6]?.ToString() == null && ate_data[i, 5]?.ToString().ToUpper() == "SKIP")
            {
                flow.WriteLine("}");
                flow.WriteLine();
            }


            else if (ate_data[i, 6]?.ToString() != null && ate_data[i, 5]?.ToString().ToUpper() == "SKIP")
            {

                string endcnt = ate_data[i, 6]?.ToString();
                MatchCollection matches = Regex.Matches(endcnt, ",");
                int cnt = matches.Count;

                if (cnt == 0)
                {
                    string temp_val = TEST_NAME.Substring(TEST_NAME.Length - 1);

                    if (endcnt == temp_val)
                    {
                        flow.WriteLine("}");
                    }
                }

                else if (cnt != 0)
                {
                    string[] cntarr;
                    cntarr = endcnt.Split(new char[] { ',' }, StringSplitOptions.None);


                    for (int x = 0; x < cntarr.GetLength(0); x++)
                    {
                        string temp_val = TEST_NAME.Substring(TEST_NAME.Length - 1);

                        if (cntarr[x] == temp_val)
                        {
                            flow.WriteLine("}");
                        }

                    }
                }
            }
        }

        public void CORE_BIRA_PATTERN_MODIFY_AND_BLOW(int i, string[] argarraytxt)
        {
            flow_num++;
            testnum = flow_num;

            string PROCEDURE_NAME = "";
            string Blowing_Pat = "";
            string ProgramPin = "";
            string FuseArrStart = "";
            string FuseBitCount = "";
            string BlowStartCycle = "";
            string FSource_Relay = "";

            if (ate_data[i, 37]?.ToString() != null)
            {
                PROCEDURE_NAME = ate_data[i, 37]?.ToString();
            }

            if (ate_data[i, 49]?.ToString() != null)
            {
                Blowing_Pat = ate_data[i, 49]?.ToString();
            }

            if (ate_data[i, 50]?.ToString() != null)
            {
                ProgramPin = ate_data[i, 50]?.ToString();
            }

            if (ate_data[i, 51]?.ToString() != null)
            {
                FuseArrStart = ate_data[i, 51]?.ToString();
            }

            if (ate_data[i, 52]?.ToString() != null)
            {
                FuseBitCount = ate_data[i, 52]?.ToString();
            }

            if (ate_data[i, 53]?.ToString() != null)
            {
                BlowStartCycle = ate_data[i, 53]?.ToString();
            }

            if (ate_data[i, 54]?.ToString() != null)
            {
                FSource_Relay = ate_data[i, 54]?.ToString();
            }

            if (ate_data[i, 6]?.ToString() == null && ate_data[i, 5]?.ToString().ToUpper() == "SKIP")
            {
                flow.WriteLine();
                flow.WriteLine("if (!FAILITEM_SKIP)");
                flow.WriteLine("{");
            }

            else if (ate_data[i, 6]?.ToString() != null && ate_data[i, 5]?.ToString().ToUpper() == "SKIP")
            {

                string endcnt = ate_data[i, 6]?.ToString();
                MatchCollection matches = Regex.Matches(endcnt, ",");
                int cnt = matches.Count;

                if (cnt == 0)
                {
                    string temp_val = TEST_NAME.Substring(TEST_NAME.Length - 1);

                    if (endcnt == temp_val)
                    {
                        flow.WriteLine();
                        flow.WriteLine("if (!FAILITEM_SKIP)");
                        flow.WriteLine("{");
                    }
                }

                else if (cnt != 0)
                {
                    string[] cntarr;
                    cntarr = endcnt.Split(new char[] { ',' }, StringSplitOptions.None);


                    for (int x = 0; x < cntarr.GetLength(0); x++)
                    {
                        string temp_val = TEST_NAME.Substring(TEST_NAME.Length - 1);

                        if (cntarr[x] == temp_val)
                        {
                            flow.WriteLine();
                            flow.WriteLine("if (!FAILITEM_SKIP)");
                            flow.WriteLine("{");
                        }

                    }
                }
            }


            string ww = '.' + "\\" + "PATTERN" + "\\";
            Blowing_Pat = Blowing_Pat.Replace(ww, "");
            Blowing_Pat = Blowing_Pat.Replace(".PAT.gz", ".atp.bin");
            Blowing_Pat = Blowing_Pat.Replace(".PAT", ".atp.bin");


            flow.WriteLine();
            flow.WriteLine("testnum++; /*{0}*/;", testnum);
            //flow.WriteLine("tl_pcie_reg_write(0, 0x00140000, 0x0000);   //Set MCG CLK OUT");
            flow.WriteLine("TEST_STEP_IN(testnum, " + '"' + "{0}" + '"' + ", {1}, {2})", var, G_FLAG_TRUE, G_VAL_TRUE);
            //flow.WriteLine("\tMFunctional_T(");
            flow.WriteLine("\t{0}(", PROCEDURE_NAME);
            flow.WriteLine("\t\ttestnum,");
            //flow.WriteLine("\t\t" + '"' + "{0}" + '"' + ',' + " //category_job", category_job);
            flow.WriteLine("\t\t" + '"' + "{0}" + '"' + ',' + " //test_name", TEST_NAME);
            //flow.WriteLine("\t\t{0},//	int g_exec_flag_var,	// = -1,	// Exec(1), Skip(0)", G_FLAG_TRUE);
            //flow.WriteLine("\t\t{0},//	int &g_label_var,	// = 0,	", g_label_var);
            flow.WriteLine("\t\t{0},//	int &g_result_flag_var,	// = 0,	", g_result_flag_var);
            flow.WriteLine("\t\t{0},//	int &g_pass_flag_var,	// = 0, ", g_pass_flag_var);
            flow.WriteLine("\t\t{0},//	int &g_fail_flag_var,	// = 0, ", g_fail_flag_var);
            flow.WriteLine("\t\t{0},//	int HWBin,			// = 0, ", HWBin);
            flow.WriteLine("\t\t{0},//	int SWBin,			// = 0, ", SWBin);
            flow.WriteLine("\t\t" + '"' + "{0}" + '"' + ",//	string pat_filename,	// = NULL,", a5);
            flow.WriteLine("\t\t" + '"' + "{0}" + '"' + ",//	string tset_filename,	// = NULL,", tset);
            flow.WriteLine("\t\t" + '"' + "{0}" + '"' + ",//	string pwrset_filename,	// = NULL,", pset);
            //flow.WriteLine("\t\t" + '"' + "{0}" + '"' + ",//	string PrePatF = " + '"' + '"' + ",//arg3", arg3);
            //flow.WriteLine("\t\t{0}, " + '"' + "{1}" + '"' + ", " + '"' + "{2}" + '"' + ", //	string StartOfBodyF = 0, string StartOfBodyF_name = " + '"' + '"' + ", string StartOfBodyF_arg = " + '"' + '"', StartOfBodyF, StartOfBodyF_name, StartOfBodyF_arg);
            //flow.WriteLine("\t\t{0}, " + '"' + "{1}" + '"' + ", //	string PrePatF = 0,//arg3, string PrePatFname = " + '"' + '"', arg3, arg3name);
            //flow.WriteLine("\t\t" + '"' + "{0}" + '"' + ",//	string PrePatFArgs = " + '"' + '"' + ",//arg16", arg16);
            //flow.WriteLine("\t\t{0}, " + '"' + "{1}" + '"' + ", " + '"' + "{2}" + '"' + ", //	string PrePatF = 0, string PrePatFname = " + '"' + '"' + ", string PrePatFArgs = " + '"' + '"', arg3, arg3name, arg16);
            //flow.WriteLine("\t\t{0}, " + '"' + "{1}" + '"' + ", " + '"' + "{2}" + '"' + ", //	string PreTestF = 0, string PreTestF_name = " + '"' + '"' + ", string PreTestF_arg = " + '"' + '"', PreTestF, PreTestF_name, PreTestF_arg);
            //flow.WriteLine("\t\t" + '"' + "{0}" + '"' + ",//	string PostPatF = " + '"' + '"' + ",//arg6", arg6);
            //flow.WriteLine("\t\t{0}, " + '"' + "{1}" + '"' + ", " + '"' + "{2}" + '"' + ", //	string PostTestF = 0, string PostTestF_name = " + '"' + '"' + ", string PostTestF_arg = " + '"' + '"', PostTestF, PostTestF_name, PostTestF_arg);
            //flow.WriteLine("\t\t{0}, " + '"' + "{1}" + '"' + ", //	string PostPatF = 0,//arg6, string PostPatFname = "+'"'+'"', arg6, arg6name);
            //flow.WriteLine("\t\t" + '"' + "{0}" + '"' + ",//	string PostPatFArg = " + '"' + '"' + ",//arg19", arg19);
            //flow.WriteLine("\t\t{0}, " + '"' + "{1}" + '"' + ", " + '"' + "{2}" + '"' + ", //	string PostPatF = 0, string PostPatFname = " + '"' + '"' + ", string PostPatFArg = " + '"' + '"', arg6, arg6name, arg19);
            //flow.WriteLine("\t\t{0}, " + '"' + "{1}" + '"' + ", " + '"' + "{2}" + '"' + ", //	string EndOfBodyF = 0, string EndOfBodyF_name = " + '"' + '"' + ", string EndOfBodyF_arg = " + '"' + '"', EndOfBodyF, EndOfBodyF_name, EndOfBodyF_arg);
            //flow.WriteLine("\t\t" + '"' + "{0}" + '"' + ",//	string SUB_BLOCK = " + '"' + '"' + ",//arg51", arg51);
            //flow.WriteLine("\t\t" + '"' + "{0}" + '"' + ",//	string SUB_PINS = " + '"' + '"' + ",//arg52", arg52);
            //flow.WriteLine("\t\t" + '"' + "{0}" + '"' + ",//	string SITEVAR = " + '"' + '"' + ",//arg53", arg53);
            //flow.Write("\t\t");
            //for (int b = 0; b < arg53count; b++)
            //{
            //flow.Write("{0}, ", argarraytxt[b]); //	string SITEVAR = " + '"' + '"' + ",//arg53", arg53);
            //}
            //flow.Write(" //SITEVAR //arg53");
            //flow.WriteLine();
            flow.WriteLine("\t\t{0}, //	int g_dcon_flag_var = 1;	//1:powerset, 0:powerset skip", powerset);
            //flow.WriteLine("\t\t" + '"' + "{0}" + '"' + ", //	string UTIL1_PINS = " + '"' + '"' + ',', UTIL1_PINS);
            //flow.WriteLine("\t\t" + '"' + "{0}" + '"' + ", //	string UTIL0_PINS = " + '"' + '"' + ',', UTIL0_PINS);
            flow.WriteLine("\t\t{0},  //	int &g_label_var = 0,", g_label_var);

            //flow.WriteLine("\t\t{0}, " + '"' + "{1}" + '"' + ", " + '"' + "{2}" + '"' + ", //	string StartOfBodyF = 0, string StartOfBodyF_name = " + '"' + '"' + ", string StartOfBodyF_arg = "+'"'+'"' , StartOfBodyF, StartOfBodyF_name, StartOfBodyF_arg);
            //flow.WriteLine("\t\t{0}, " + '"' + "{1}" + '"' + ", " + '"' + "{2}" + '"' + ", //	string PreTestF = 0, string PreTestF_name = " + '"' + '"' + ", string PreTestF_arg = " + '"' + '"', PreTestF, PreTestF_name, PreTestF_arg);
            //flow.WriteLine("\t\t{0}, " + '"' + "{1}" + '"' + ", " + '"' + "{2}" + '"' + ", //	string PostTestF = 0, string PostTestF_name = " + '"' + '"' + ", string PostTestF_arg = " + '"' + '"', PostTestF, PostTestF_name, PostTestF_arg);
            //flow.WriteLine("\t\t{0}, " + '"' + "{1}" + '"' + ", " + '"' + "{2}" + '"' + " //	string EndOfBodyF = 0, string EndOfBodyF_name = " + '"' + '"' + ", string EndOfBodyF_arg = " + '"' + '"', EndOfBodyF, EndOfBodyF_name, EndOfBodyF_arg);

            flow.WriteLine("\t\t{0}, //int bira_exec_flag, ", BIRA_EXEC);

            flow.WriteLine("\t\t" + '"' + "{0}" + '"' + ", //string Blowing_Pat, ", Blowing_Pat);
            flow.WriteLine("\t\t" + '"' + "{0}" + '"' + ", //string ProgramPin, ", ProgramPin);
            flow.WriteLine("\t\t{0}, //unsigned int FuseArrStart, ", FuseArrStart);
            flow.WriteLine("\t\t{0}, //unsigned int FuseBitCount, ", FuseBitCount);
            flow.WriteLine("\t\t{0}, //unsigned int BlowStartCycle, ", BlowStartCycle);
            flow.WriteLine("\t\t" + '"' + "{0}" + '"' + " //string FSource_Relay ", FSource_Relay);

            //string Blowing_Pat,
            //string ProgramPin,
            //unsigned int FuseArrStart,
            //unsigned int FuseBitCount,
            //unsigned int BlowStartCycle,
            //string FSource_Relay


            flow.WriteLine("\t);");
            flow.WriteLine("TEST_STEP_OUT()");
            //flow.WriteLine("TEST_STEP_OUT(testnum, " + '"' + "{0}" + '"' + ", {1}, {2})", var, G_FLAG_TRUE, G_VAL_TRUE);
            flow.WriteLine();

            if (ate_data[i, 6]?.ToString() == null && ate_data[i, 5]?.ToString().ToUpper() == "SKIP")
            {
                flow.WriteLine("}");
                flow.WriteLine();
            }


            else if (ate_data[i, 6]?.ToString() != null && ate_data[i, 5]?.ToString().ToUpper() == "SKIP")
            {

                string endcnt = ate_data[i, 6]?.ToString();
                MatchCollection matches = Regex.Matches(endcnt, ",");
                int cnt = matches.Count;

                if (cnt == 0)
                {
                    string temp_val = TEST_NAME.Substring(TEST_NAME.Length - 1);

                    if (endcnt == temp_val)
                    {
                        flow.WriteLine("}");
                    }
                }

                else if (cnt != 0)
                {
                    string[] cntarr;
                    cntarr = endcnt.Split(new char[] { ',' }, StringSplitOptions.None);


                    for (int x = 0; x < cntarr.GetLength(0); x++)
                    {
                        string temp_val = TEST_NAME.Substring(TEST_NAME.Length - 1);

                        if (cntarr[x] == temp_val)
                        {
                            flow.WriteLine("}");
                        }

                    }
                }
            }
        }

        public void FRC_BIRA_PATTERN_MODIFY_AND_BLOW(int i, string[] argarraytxt)
        {
            flow_num++;
            testnum = flow_num;

            string PROCEDURE_NAME = "";
            string Blowing_Pat = "";
            string ProgramPin = "";
            string FuseBitCount = "";
            string BlowStartCycle = "";
            string FSource_Relay = "";
            string UNIT_SIZE = "";

            if (ate_data[i, 37]?.ToString() != null)
            {
                PROCEDURE_NAME = ate_data[i, 37]?.ToString();
            }

            if (ate_data[i, 49]?.ToString() != null)
            {
                Blowing_Pat = ate_data[i, 49]?.ToString();
            }

            if (ate_data[i, 50]?.ToString() != null)
            {
                ProgramPin = ate_data[i, 50]?.ToString();
            }

            if (ate_data[i, 51]?.ToString() != null)
            {
                FuseBitCount = ate_data[i, 51]?.ToString();
            }

            if (ate_data[i, 52]?.ToString() != null)
            {
                BlowStartCycle = ate_data[i, 52]?.ToString();
            }

            if (ate_data[i, 53]?.ToString() != null)
            {
                FSource_Relay = ate_data[i, 53]?.ToString();
            }

            if (ate_data[i, 54]?.ToString() != null)
            {
                UNIT_SIZE = ate_data[i, 54]?.ToString();
            }


            if (ate_data[i, 6]?.ToString() == null && ate_data[i, 5]?.ToString().ToUpper() == "SKIP")
            {
                flow.WriteLine();
                flow.WriteLine("if (!FAILITEM_SKIP)");
                flow.WriteLine("{");
            }

            else if (ate_data[i, 6]?.ToString() != null && ate_data[i, 5]?.ToString().ToUpper() == "SKIP")
            {

                string endcnt = ate_data[i, 6]?.ToString();
                MatchCollection matches = Regex.Matches(endcnt, ",");
                int cnt = matches.Count;

                if (cnt == 0)
                {
                    string temp_val = TEST_NAME.Substring(TEST_NAME.Length - 1);

                    if (endcnt == temp_val)
                    {
                        flow.WriteLine();
                        flow.WriteLine("if (!FAILITEM_SKIP)");
                        flow.WriteLine("{");
                    }
                }

                else if (cnt != 0)
                {
                    string[] cntarr;
                    cntarr = endcnt.Split(new char[] { ',' }, StringSplitOptions.None);


                    for (int x = 0; x < cntarr.GetLength(0); x++)
                    {
                        string temp_val = TEST_NAME.Substring(TEST_NAME.Length - 1);

                        if (cntarr[x] == temp_val)
                        {
                            flow.WriteLine();
                            flow.WriteLine("if (!FAILITEM_SKIP)");
                            flow.WriteLine("{");
                        }

                    }
                }
            }


            string ww = '.' + "\\" + "PATTERN" + "\\";
            Blowing_Pat = Blowing_Pat.Replace(ww, "");
            Blowing_Pat = Blowing_Pat.Replace(".PAT.gz", ".atp.bin");
            Blowing_Pat = Blowing_Pat.Replace(".PAT", ".atp.bin");


            flow.WriteLine();
            flow.WriteLine("testnum++; /*{0}*/;", testnum);
            //flow.WriteLine("tl_pcie_reg_write(0, 0x00140000, 0x0000);   //Set MCG CLK OUT");
            flow.WriteLine("TEST_STEP_IN(testnum, " + '"' + "{0}" + '"' + ", {1}, {2})", var, G_FLAG_TRUE, G_VAL_TRUE);
            //flow.WriteLine("\tMFunctional_T(");
            flow.WriteLine("\t{0}(", PROCEDURE_NAME);
            flow.WriteLine("\t\ttestnum,");
            //flow.WriteLine("\t\t" + '"' + "{0}" + '"' + ',' + " //category_job", category_job);
            flow.WriteLine("\t\t" + '"' + "{0}" + '"' + ',' + " //test_name", TEST_NAME);
            //flow.WriteLine("\t\t{0},//	int g_exec_flag_var,	// = -1,	// Exec(1), Skip(0)", G_FLAG_TRUE);
            //flow.WriteLine("\t\t{0},//	int &g_label_var,	// = 0,	", g_label_var);
            flow.WriteLine("\t\t{0},//	int &g_result_flag_var,	// = 0,	", g_result_flag_var);
            flow.WriteLine("\t\t{0},//	int &g_pass_flag_var,	// = 0, ", g_pass_flag_var);
            flow.WriteLine("\t\t{0},//	int &g_fail_flag_var,	// = 0, ", g_fail_flag_var);
            flow.WriteLine("\t\t{0},//	int HWBin,			// = 0, ", HWBin);
            flow.WriteLine("\t\t{0},//	int SWBin,			// = 0, ", SWBin);
            flow.WriteLine("\t\t" + '"' + "{0}" + '"' + ",//	string pat_filename,	// = NULL,", a5);
            flow.WriteLine("\t\t" + '"' + "{0}" + '"' + ",//	string tset_filename,	// = NULL,", tset);
            flow.WriteLine("\t\t" + '"' + "{0}" + '"' + ",//	string pwrset_filename,	// = NULL,", pset);
            //flow.WriteLine("\t\t" + '"' + "{0}" + '"' + ",//	string PrePatF = " + '"' + '"' + ",//arg3", arg3);
            //flow.WriteLine("\t\t{0}, " + '"' + "{1}" + '"' + ", " + '"' + "{2}" + '"' + ", //	string StartOfBodyF = 0, string StartOfBodyF_name = " + '"' + '"' + ", string StartOfBodyF_arg = " + '"' + '"', StartOfBodyF, StartOfBodyF_name, StartOfBodyF_arg);
            //flow.WriteLine("\t\t{0}, " + '"' + "{1}" + '"' + ", //	string PrePatF = 0,//arg3, string PrePatFname = " + '"' + '"', arg3, arg3name);
            //flow.WriteLine("\t\t" + '"' + "{0}" + '"' + ",//	string PrePatFArgs = " + '"' + '"' + ",//arg16", arg16);
            //flow.WriteLine("\t\t{0}, " + '"' + "{1}" + '"' + ", " + '"' + "{2}" + '"' + ", //	string PrePatF = 0, string PrePatFname = " + '"' + '"' + ", string PrePatFArgs = " + '"' + '"', arg3, arg3name, arg16);
            //flow.WriteLine("\t\t{0}, " + '"' + "{1}" + '"' + ", " + '"' + "{2}" + '"' + ", //	string PreTestF = 0, string PreTestF_name = " + '"' + '"' + ", string PreTestF_arg = " + '"' + '"', PreTestF, PreTestF_name, PreTestF_arg);
            //flow.WriteLine("\t\t" + '"' + "{0}" + '"' + ",//	string PostPatF = " + '"' + '"' + ",//arg6", arg6);
            //flow.WriteLine("\t\t{0}, " + '"' + "{1}" + '"' + ", " + '"' + "{2}" + '"' + ", //	string PostTestF = 0, string PostTestF_name = " + '"' + '"' + ", string PostTestF_arg = " + '"' + '"', PostTestF, PostTestF_name, PostTestF_arg);
            //flow.WriteLine("\t\t{0}, " + '"' + "{1}" + '"' + ", //	string PostPatF = 0,//arg6, string PostPatFname = "+'"'+'"', arg6, arg6name);
            //flow.WriteLine("\t\t" + '"' + "{0}" + '"' + ",//	string PostPatFArg = " + '"' + '"' + ",//arg19", arg19);
            //flow.WriteLine("\t\t{0}, " + '"' + "{1}" + '"' + ", " + '"' + "{2}" + '"' + ", //	string PostPatF = 0, string PostPatFname = " + '"' + '"' + ", string PostPatFArg = " + '"' + '"', arg6, arg6name, arg19);
            //flow.WriteLine("\t\t{0}, " + '"' + "{1}" + '"' + ", " + '"' + "{2}" + '"' + ", //	string EndOfBodyF = 0, string EndOfBodyF_name = " + '"' + '"' + ", string EndOfBodyF_arg = " + '"' + '"', EndOfBodyF, EndOfBodyF_name, EndOfBodyF_arg);
            //flow.WriteLine("\t\t" + '"' + "{0}" + '"' + ",//	string SUB_BLOCK = " + '"' + '"' + ",//arg51", arg51);
            //flow.WriteLine("\t\t" + '"' + "{0}" + '"' + ",//	string SUB_PINS = " + '"' + '"' + ",//arg52", arg52);
            //flow.WriteLine("\t\t" + '"' + "{0}" + '"' + ",//	string SITEVAR = " + '"' + '"' + ",//arg53", arg53);
            //flow.Write("\t\t");
            //for (int b = 0; b < arg53count; b++)
            //{
            //flow.Write("{0}, ", argarraytxt[b]); //	string SITEVAR = " + '"' + '"' + ",//arg53", arg53);
            //}
            //flow.Write(" //SITEVAR //arg53");
            //flow.WriteLine();
            flow.WriteLine("\t\t{0}, //	int g_dcon_flag_var = 1;	//1:powerset, 0:powerset skip", powerset);
            //flow.WriteLine("\t\t" + '"' + "{0}" + '"' + ", //	string UTIL1_PINS = " + '"' + '"' + ',', UTIL1_PINS);
            //flow.WriteLine("\t\t" + '"' + "{0}" + '"' + ", //	string UTIL0_PINS = " + '"' + '"' + ',', UTIL0_PINS);
            flow.WriteLine("\t\t{0},  //	int &g_label_var = 0,", g_label_var);

            //flow.WriteLine("\t\t{0}, " + '"' + "{1}" + '"' + ", " + '"' + "{2}" + '"' + ", //	string StartOfBodyF = 0, string StartOfBodyF_name = " + '"' + '"' + ", string StartOfBodyF_arg = "+'"'+'"' , StartOfBodyF, StartOfBodyF_name, StartOfBodyF_arg);
            //flow.WriteLine("\t\t{0}, " + '"' + "{1}" + '"' + ", " + '"' + "{2}" + '"' + ", //	string PreTestF = 0, string PreTestF_name = " + '"' + '"' + ", string PreTestF_arg = " + '"' + '"', PreTestF, PreTestF_name, PreTestF_arg);
            //flow.WriteLine("\t\t{0}, " + '"' + "{1}" + '"' + ", " + '"' + "{2}" + '"' + ", //	string PostTestF = 0, string PostTestF_name = " + '"' + '"' + ", string PostTestF_arg = " + '"' + '"', PostTestF, PostTestF_name, PostTestF_arg);
            //flow.WriteLine("\t\t{0}, " + '"' + "{1}" + '"' + ", " + '"' + "{2}" + '"' + " //	string EndOfBodyF = 0, string EndOfBodyF_name = " + '"' + '"' + ", string EndOfBodyF_arg = " + '"' + '"', EndOfBodyF, EndOfBodyF_name, EndOfBodyF_arg);

            flow.WriteLine("\t\t{0}, //int bira_exec_flag, ", BIRA_EXEC);

            flow.WriteLine("\t\t" + '"' + "{0}" + '"' + ", //string Blowing_Pat, ", Blowing_Pat);
            flow.WriteLine("\t\t" + '"' + "{0}" + '"' + ", //string ProgramPin, ", ProgramPin);
            flow.WriteLine("\t\t{0}, //unsigned int FuseBitCount, ", FuseBitCount);
            flow.WriteLine("\t\t{0}, //unsigned int BlowStartCycle, ", BlowStartCycle);
            flow.WriteLine("\t\t" + '"' + "{0}" + '"' + ", //string FSource_Relay ", FSource_Relay);
            flow.WriteLine("\t\t{0} //unsigned int UNIT_SIZE, ", UNIT_SIZE);


            flow.WriteLine("\t);");
            flow.WriteLine("TEST_STEP_OUT()");
            //flow.WriteLine("TEST_STEP_OUT(testnum, " + '"' + "{0}" + '"' + ", {1}, {2})", var, G_FLAG_TRUE, G_VAL_TRUE);
            flow.WriteLine();

            if (ate_data[i, 6]?.ToString() == null && ate_data[i, 5]?.ToString().ToUpper() == "SKIP")
            {
                flow.WriteLine("}");
                flow.WriteLine();
            }


            else if (ate_data[i, 6]?.ToString() != null && ate_data[i, 5]?.ToString().ToUpper() == "SKIP")
            {

                string endcnt = ate_data[i, 6]?.ToString();
                MatchCollection matches = Regex.Matches(endcnt, ",");
                int cnt = matches.Count;

                if (cnt == 0)
                {
                    string temp_val = TEST_NAME.Substring(TEST_NAME.Length - 1);
                    
                    if (endcnt == temp_val)
                    {
                        flow.WriteLine("}");
                    }
                }

                else if (cnt != 0)
                {
                    string[] cntarr;
                    cntarr = endcnt.Split(new char[] { ',' }, StringSplitOptions.None);


                    for (int x = 0; x < cntarr.GetLength(0); x++)
                    {
                        string temp_val = TEST_NAME.Substring(TEST_NAME.Length - 1);

                        if (cntarr[x] == temp_val)
                        {
                            flow.WriteLine("}");
                        }

                    }
                }
            }
        }


        public void ONLY_FLAG()
        {
            //flow.WriteLine();
            flow.WriteLine("\t\t{0} = 1; // item skip, fail flag/var on", g_fail_flag_var);
            //flow.WriteLine();
        }

        public void MakeVBT()
        {
            flow_num++;
            testnum = flow_num;

            flow.WriteLine();
            flow.WriteLine("// VBT : {0};", TEST_NAME);
            flow.WriteLine("testnum++; /*{0}*/;", testnum);
            //flow.WriteLine("tl_pcie_reg_write(0, 0x00140000, 0x0000);   //Set MCG CLK OUT");
            flow.WriteLine("TEST_STEP_IN(testnum, " + '"' + "{0}" + '"' + ", {1}, {2})", var, G_FLAG_TRUE, G_VAL_TRUE);
            flow.WriteLine("\t{0}();", type_name);
            //flow.WriteLine("\t//" + '"' + "{0}" + '"' + ", " + '"' + "{1}" + '"', TEST_NAME, type_name);
            //flow.WriteLine("\t// need new function or VBT");
            flow.WriteLine("TEST_STEP_OUT()");
            //flow.WriteLine("TEST_STEP_OUT(testnum, " + '"' + "{0}" + '"' + ", {1}, {2})", var, G_FLAG_TRUE, G_VAL_TRUE);
            flow.WriteLine();
        }



        public void flow_ETC()
        {
            flow_num++;
            testnum = flow_num;

            flow.WriteLine();
            flow.WriteLine("testnum++; /*{0}*/;", testnum);
            //flow.WriteLine("tl_pcie_reg_write(0, 0x00140000, 0x0000);   //Set MCG CLK OUT");
            flow.WriteLine("TEST_STEP_IN(testnum, " + '"' + "{0}" + '"' + ", {1}, {2})", var, G_FLAG_TRUE, G_VAL_TRUE);
            flow.WriteLine("\t /*need new function or VBT*/ //" + '"' + "{0}" + '"' + ", " + '"' + "{1}" + '"', TEST_NAME, type_name);
            //flow.WriteLine("\t// need new function or VBT");
            flow.WriteLine("TEST_STEP_OUT()");
            //flow.WriteLine("TEST_STEP_OUT(testnum, " + '"' + "{0}" + '"' + ", {1}, {2})", var, G_FLAG_TRUE, G_VAL_TRUE);
            flow.WriteLine();

        }

        //FOR NEUS TMU
        public void TMU_SENSE_DEFAULT_HOT(int i, string[] argarraytxt)
        {
            flow_num++;
            testnum = flow_num;

            if (ate_data[i, 6]?.ToString() == null && ate_data[i, 5]?.ToString().ToUpper() == "SKIP")
            {
                flow.WriteLine();
                flow.WriteLine("if (!FAILITEM_SKIP)");
                flow.WriteLine("{");
            }

            else if (ate_data[i, 6]?.ToString() != null && ate_data[i, 5]?.ToString().ToUpper() == "SKIP")
            {

                string endcnt = ate_data[i, 6]?.ToString();
                MatchCollection matches = Regex.Matches(endcnt, ",");
                int cnt = matches.Count;

                if (cnt == 0)
                {
                    string temp_val = TEST_NAME.Substring(TEST_NAME.Length - 1);

                    if (endcnt == temp_val)
                    {
                        flow.WriteLine();
                        flow.WriteLine("if (!FAILITEM_SKIP)");
                        flow.WriteLine("{");
                    }
                }

                else if (cnt != 0)
                {
                    string[] cntarr;
                    cntarr = endcnt.Split(new char[] { ',' }, StringSplitOptions.None);


                    for (int x = 0; x < cntarr.GetLength(0); x++)
                    {
                        string temp_val = TEST_NAME.Substring(TEST_NAME.Length - 1);

                        if (cntarr[x] == temp_val)
                        {
                            flow.WriteLine();
                            flow.WriteLine("if (!FAILITEM_SKIP)");
                            flow.WriteLine("{");
                        }

                    }
                }
            }

            StartOfBodyF = "0";
            StartOfBodyF_name = "";
            StartOfBodyF_arg = "";
            arg3 = "0";
            arg3name = "";
            arg16 = "";
            PreTestF = "0";
            PreTestF_name = "";
            PreTestF_arg = "";
            PostTestF = "0";
            PostTestF_name = "";
            PostTestF_arg = "";
            arg6 = "TMU_SENSE_DEFAULT_HOT";
            arg6name = "TMU_SENSE_DEFAULT_HOT";
            arg19 = a5;
            EndOfBodyF = "0";
            EndOfBodyF_name = "";
            EndOfBodyF_arg = "";


            flow.WriteLine();
            flow.WriteLine("testnum++; /*{0}*/;", testnum);
            //flow.WriteLine("tl_pcie_reg_write(0, 0x00140000, 0x0000);   //Set MCG CLK OUT");
            flow.WriteLine("TEST_STEP_IN(testnum, " + '"' + "{0}" + '"' + ", {1}, {2})", var, G_FLAG_TRUE, G_VAL_TRUE);
            flow.WriteLine("\tMFunctional_T(");
            flow.WriteLine("\t\ttestnum,");
            //flow.WriteLine("\t\t" + '"' + "{0}" + '"' + ',' + " //category_job", category_job);
            flow.WriteLine("\t\t" + '"' + "{0}" + '"' + ',' + " //test_name", TEST_NAME);
            //flow.WriteLine("\t\t{0},//	int g_exec_flag_var,	// = -1,	// Exec(1), Skip(0)", G_FLAG_TRUE);
            //flow.WriteLine("\t\t{0},//	int &g_label_var,	// = 0,	", g_label_var);
            flow.WriteLine("\t\t{0},//	int &g_result_flag_var,	// = 0,	", g_result_flag_var);
            flow.WriteLine("\t\t{0},//	int &g_pass_flag_var,	// = 0, ", g_pass_flag_var);
            flow.WriteLine("\t\t{0},//	int &g_fail_flag_var,	// = 0, ", g_fail_flag_var);
            flow.WriteLine("\t\t{0},//	int HWBin,			// = 0, ", HWBin);
            flow.WriteLine("\t\t{0},//	int SWBin,			// = 0, ", SWBin);
            flow.WriteLine("\t\t" + '"' + "{0}" + '"' + ",//	string pat_filename,	// = NULL,", a5);
            flow.WriteLine("\t\t" + '"' + "{0}" + '"' + ",//	string tset_filename,	// = NULL,", tset);
            flow.WriteLine("\t\t" + '"' + "{0}" + '"' + ",//	string pwrset_filename,	// = NULL,", pset);
            //flow.WriteLine("\t\t" + '"' + "{0}" + '"' + ",//	string PrePatF = " + '"' + '"' + ",//arg3", arg3);
            flow.WriteLine("\t\t{0}, " + '"' + "{1}" + '"' + ", " + '"' + "{2}" + '"' + ", //	string StartOfBodyF = 0, string StartOfBodyF_name = " + '"' + '"' + ", string StartOfBodyF_arg = " + '"' + '"', StartOfBodyF, StartOfBodyF_name, StartOfBodyF_arg);
            //flow.WriteLine("\t\t{0}, " + '"' + "{1}" + '"' + ", //	string PrePatF = 0,//arg3, string PrePatFname = " + '"' + '"', arg3, arg3name);
            //flow.WriteLine("\t\t" + '"' + "{0}" + '"' + ",//	string PrePatFArgs = " + '"' + '"' + ",//arg16", arg16);
            flow.WriteLine("\t\t{0}, " + '"' + "{1}" + '"' + ", " + '"' + "{2}" + '"' + ", //	string PrePatF = 0, string PrePatFname = " + '"' + '"' + ", string PrePatFArgs = " + '"' + '"', arg3, arg3name, arg16);
            flow.WriteLine("\t\t{0}, " + '"' + "{1}" + '"' + ", " + '"' + "{2}" + '"' + ", //	string PreTestF = 0, string PreTestF_name = " + '"' + '"' + ", string PreTestF_arg = " + '"' + '"', PreTestF, PreTestF_name, PreTestF_arg);
            //flow.WriteLine("\t\t" + '"' + "{0}" + '"' + ",//	string PostPatF = " + '"' + '"' + ",//arg6", arg6);
            //flow.WriteLine("\t\t{0}, " + '"' + "{1}" + '"' + ", //	string PostPatF = 0,//arg6, string PostPatFname = "+'"'+'"', arg6, arg6name);
            //flow.WriteLine("\t\t" + '"' + "{0}" + '"' + ",//	string PostPatFArg = " + '"' + '"' + ",//arg19", arg19);
            flow.WriteLine("\t\t{0}, " + '"' + "{1}" + '"' + ", " + '"' + "{2}" + '"' + ", //	string PostTestF = 0, string PostTestF_name = " + '"' + '"' + ", string PostTestF_arg = " + '"' + '"', PostTestF, PostTestF_name, PostTestF_arg);
            flow.WriteLine("\t\t{0}, " + '"' + "{1}" + '"' + ", " + '"' + "{2}" + '"' + ", //	string PostPatF = 0, string PostPatFname = " + '"' + '"' + ", string PostPatFArg = " + '"' + '"', arg6, arg6name, arg19);
            flow.WriteLine("\t\t{0}, " + '"' + "{1}" + '"' + ", " + '"' + "{2}" + '"' + ", //	string EndOfBodyF = 0, string EndOfBodyF_name = " + '"' + '"' + ", string EndOfBodyF_arg = " + '"' + '"', EndOfBodyF, EndOfBodyF_name, EndOfBodyF_arg);
            flow.WriteLine("\t\t" + '"' +       "{0}" + '"' + ",//	string SUB_BLOCK = " + '"' + '"' + ",//arg51", arg51);
            flow.WriteLine("\t\t" + '"' + "{0}" + '"' + ",//	string SUB_PINS = " + '"' + '"' + ",//arg52", arg52);
            //flow.WriteLine("\t\t" + '"' + "{0}" + '"' + ",//	string SITEVAR = " + '"' + '"' + ",//arg53", arg53);
            flow.Write("\t\t");
            for (int b = 0; b < arg53count; b++)
            {
                flow.Write("{0}, ", argarraytxt[b]); //	string SITEVAR = " + '"' + '"' + ",//arg53", arg53);
            }
            flow.Write(" //SITEVAR //arg53");
            flow.WriteLine();
            flow.WriteLine("\t\t{0}, //	int g_dcon_flag_var = 1;	//1:powerset, 0:powerset skip", powerset);
            flow.WriteLine("\t\t" + '"' + "{0}" + '"' + ", //	string UTIL1_PINS = " + '"' + '"' + ',', UTIL1_PINS);
            flow.WriteLine("\t\t" + '"' + "{0}" + '"' + ", //	string UTIL0_PINS = " + '"' + '"' + ',', UTIL0_PINS);
            flow.WriteLine("\t\t{0}  //	int &g_label_var = 0,", g_label_var);

            //flow.WriteLine("\t\t{0}, " + '"' + "{1}" + '"' + ", " + '"' + "{2}" + '"' + ", //	string StartOfBodyF = 0, string StartOfBodyF_name = " + '"' + '"' + ", string StartOfBodyF_arg = "+'"'+'"' , StartOfBodyF, StartOfBodyF_name, StartOfBodyF_arg);
            //flow.WriteLine("\t\t{0}, " + '"' + "{1}" + '"' + ", " + '"' + "{2}" + '"' + ", //	string PreTestF = 0, string PreTestF_name = " + '"' + '"' + ", string PreTestF_arg = " + '"' + '"', PreTestF, PreTestF_name, PreTestF_arg);
            //flow.WriteLine("\t\t{0}, " + '"' + "{1}" + '"' + ", " + '"' + "{2}" + '"' + ", //	string PostTestF = 0, string PostTestF_name = " + '"' + '"' + ", string PostTestF_arg = " + '"' + '"', PostTestF, PostTestF_name, PostTestF_arg);
            //flow.WriteLine("\t\t{0}, " + '"' + "{1}" + '"' + ", " + '"' + "{2}" + '"' + " //	string EndOfBodyF = 0, string EndOfBodyF_name = " + '"' + '"' + ", string EndOfBodyF_arg = " + '"' + '"', EndOfBodyF, EndOfBodyF_name, EndOfBodyF_arg);


            flow.WriteLine("\t);");
            flow.WriteLine("TEST_STEP_OUT()");
            //flow.WriteLine("TEST_STEP_OUT(testnum, " + '"' + "{0}" + '"' + ", {1}, {2})", var, G_FLAG_TRUE, G_VAL_TRUE);
            flow.WriteLine();

            if (ate_data[i, 6]?.ToString() == null && ate_data[i, 5]?.ToString().ToUpper() == "SKIP")
            {
                flow.WriteLine("}");
                flow.WriteLine();
            }


            else if (ate_data[i, 6]?.ToString() != null && ate_data[i, 5]?.ToString().ToUpper() == "SKIP")
            {

                string endcnt = ate_data[i, 6]?.ToString();
                MatchCollection matches = Regex.Matches(endcnt, ",");
                int cnt = matches.Count;

                if (cnt == 0)
                {
                    string temp_val = TEST_NAME.Substring(TEST_NAME.Length - 1);

                    if (endcnt == temp_val)
                    {
                        flow.WriteLine("}");
                    }
                }

                else if (cnt != 0)
                {
                    string[] cntarr;
                    cntarr = endcnt.Split(new char[] { ',' }, StringSplitOptions.None);


                    for (int x = 0; x < cntarr.GetLength(0); x++)
                    {
                        string temp_val = TEST_NAME.Substring(TEST_NAME.Length - 1);

                        if (cntarr[x] == temp_val)
                        {
                            flow.WriteLine("}");
                        }

                    }
                }




            }
        }


        public void MFunctional_T(int i, string[] argarraytxt)
        {
            flow_num++;
            testnum = flow_num;

            if (ate_data[i, 6]?.ToString() == null && ate_data[i, 5]?.ToString().ToUpper() == "SKIP")
            {
                flow.WriteLine();
                flow.WriteLine("if (!FAILITEM_SKIP)");
                flow.WriteLine("{");
            }

            else if (ate_data[i, 6]?.ToString() != null && ate_data[i, 5]?.ToString().ToUpper() == "SKIP")
            {

                string endcnt = ate_data[i, 6]?.ToString();
                MatchCollection matches = Regex.Matches(endcnt, ",");
                int cnt = matches.Count;

                if (cnt == 0)
                {
                    string temp_val = TEST_NAME.Substring(TEST_NAME.Length - 1);

                    if (endcnt == temp_val)
                    {
                        flow.WriteLine();
                        flow.WriteLine("if (!FAILITEM_SKIP)");
                        flow.WriteLine("{");
                    }
                }

                else if (cnt != 0)
                {
                    string[] cntarr;
                    cntarr = endcnt.Split(new char[] { ',' }, StringSplitOptions.None);


                    for (int x = 0; x < cntarr.GetLength(0); x++)
                    {
                        string temp_val = TEST_NAME.Substring(TEST_NAME.Length - 1);

                        if (cntarr[x] == temp_val)
                        {
                            flow.WriteLine();
                            flow.WriteLine("if (!FAILITEM_SKIP)");
                            flow.WriteLine("{");
                        }

                    }
                }
            }


            flow.WriteLine();
            flow.WriteLine("testnum++; /*{0}*/;", testnum);
            //flow.WriteLine("tl_pcie_reg_write(0, 0x00140000, 0x0000);   //Set MCG CLK OUT");
            flow.WriteLine("TEST_STEP_IN(testnum, " + '"' + "{0}" + '"' + ", {1}, {2})", var, G_FLAG_TRUE, G_VAL_TRUE);
            flow.WriteLine("\tMFunctional_T(");
            flow.WriteLine("\t\ttestnum,");
            //flow.WriteLine("\t\t" + '"' + "{0}" + '"' + ',' + " //category_job", category_job);
            flow.WriteLine("\t\t" + '"' + "{0}" + '"' + ',' + " //test_name", TEST_NAME);
            //flow.WriteLine("\t\t{0},//	int g_exec_flag_var,	// = -1,	// Exec(1), Skip(0)", G_FLAG_TRUE);
            //flow.WriteLine("\t\t{0},//	int &g_label_var,	// = 0,	", g_label_var);
            flow.WriteLine("\t\t{0},//	int &g_result_flag_var,	// = 0,	", g_result_flag_var);
            flow.WriteLine("\t\t{0},//	int &g_pass_flag_var,	// = 0, ", g_pass_flag_var);
            flow.WriteLine("\t\t{0},//	int &g_fail_flag_var,	// = 0, ", g_fail_flag_var);
            flow.WriteLine("\t\t{0},//	int HWBin,			// = 0, ", HWBin);
            flow.WriteLine("\t\t{0},//	int SWBin,			// = 0, ", SWBin);
            flow.WriteLine("\t\t" + '"' + "{0}" + '"' + ",//	string pat_filename,	// = NULL,", a5);
            flow.WriteLine("\t\t" + '"' + "{0}" + '"' + ",//	string tset_filename,	// = NULL,", tset);
            flow.WriteLine("\t\t" + '"' + "{0}" + '"' + ",//	string pwrset_filename,	// = NULL,", pset);
            //flow.WriteLine("\t\t" + '"' + "{0}" + '"' + ",//	string PrePatF = " + '"' + '"' + ",//arg3", arg3);
            flow.WriteLine("\t\t{0}, " + '"' + "{1}" + '"' + ", " + '"' + "{2}" + '"' + ", //	string StartOfBodyF = 0, string StartOfBodyF_name = " + '"' + '"' + ", string StartOfBodyF_arg = "+'"'+'"' , StartOfBodyF, StartOfBodyF_name, StartOfBodyF_arg);
            //flow.WriteLine("\t\t{0}, " + '"' + "{1}" + '"' + ", //	string PrePatF = 0,//arg3, string PrePatFname = " + '"' + '"', arg3, arg3name);
            //flow.WriteLine("\t\t" + '"' + "{0}" + '"' + ",//	string PrePatFArgs = " + '"' + '"' + ",//arg16", arg16);
            flow.WriteLine("\t\t{0}, " + '"' + "{1}" + '"' + ", " + '"' + "{2}" + '"' + ", //	string PrePatF = 0, string PrePatFname = " + '"' + '"' + ", string PrePatFArgs = " + '"' + '"', arg3, arg3name, arg16);
            flow.WriteLine("\t\t{0}, " + '"' + "{1}" + '"' + ", " + '"' + "{2}" + '"' + ", //	string PreTestF = 0, string PreTestF_name = " + '"' + '"' + ", string PreTestF_arg = " + '"' + '"', PreTestF, PreTestF_name, PreTestF_arg);
            //flow.WriteLine("\t\t" + '"' + "{0}" + '"' + ",//	string PostPatF = " + '"' + '"' + ",//arg6", arg6);
            flow.WriteLine("\t\t{0}, " + '"' + "{1}" + '"' + ", " + '"' + "{2}" + '"' + ", //	string PostTestF = 0, string PostTestF_name = " + '"' + '"' + ", string PostTestF_arg = " + '"' + '"', PostTestF, PostTestF_name, PostTestF_arg);
            //flow.WriteLine("\t\t{0}, " + '"' + "{1}" + '"' + ", //	string PostPatF = 0,//arg6, string PostPatFname = "+'"'+'"', arg6, arg6name);
            //flow.WriteLine("\t\t" + '"' + "{0}" + '"' + ",//	string PostPatFArg = " + '"' + '"' + ",//arg19", arg19);
            flow.WriteLine("\t\t{0}, " + '"' + "{1}" + '"' + ", " + '"' + "{2}" + '"' + ", //	string PostPatF = 0, string PostPatFname = " + '"' + '"' + ", string PostPatFArg = " + '"' + '"', arg6, arg6name, arg19);
            flow.WriteLine("\t\t{0}, " + '"' + "{1}" + '"' + ", " + '"' + "{2}" + '"' + ", //	string EndOfBodyF = 0, string EndOfBodyF_name = " + '"' + '"' + ", string EndOfBodyF_arg = " + '"' + '"', EndOfBodyF, EndOfBodyF_name, EndOfBodyF_arg);
            flow.WriteLine("\t\t" + '"' + "{0}" + '"' + ",//	string SUB_BLOCK = " + '"' + '"' + ",//arg51", arg51);
            flow.WriteLine("\t\t" + '"' + "{0}" + '"' + ",//	string SUB_PINS = " + '"' + '"' + ",//arg52", arg52);
            //flow.WriteLine("\t\t" + '"' + "{0}" + '"' + ",//	string SITEVAR = " + '"' + '"' + ",//arg53", arg53);
            flow.Write("\t\t");
            for (int b =0; b< arg53count; b++)
            {
                flow.Write("{0}, ", argarraytxt[b]); //	string SITEVAR = " + '"' + '"' + ",//arg53", arg53);
            }
            flow.Write(" //SITEVAR //arg53");
            flow.WriteLine();
            flow.WriteLine("\t\t{0}, //	int g_dcon_flag_var = 1;	//1:powerset, 0:powerset skip", powerset);
            flow.WriteLine("\t\t" + '"' + "{0}" + '"' + ", //	string UTIL1_PINS = " + '"'+'"'+',', UTIL1_PINS);
            flow.WriteLine("\t\t" + '"' + "{0}" + '"' + ", //	string UTIL0_PINS = " + '"' + '"'+',', UTIL0_PINS);
            flow.WriteLine("\t\t{0}  //	int &g_label_var = 0,", g_label_var);

            //flow.WriteLine("\t\t{0}, " + '"' + "{1}" + '"' + ", " + '"' + "{2}" + '"' + ", //	string StartOfBodyF = 0, string StartOfBodyF_name = " + '"' + '"' + ", string StartOfBodyF_arg = "+'"'+'"' , StartOfBodyF, StartOfBodyF_name, StartOfBodyF_arg);
            //flow.WriteLine("\t\t{0}, " + '"' + "{1}" + '"' + ", " + '"' + "{2}" + '"' + ", //	string PreTestF = 0, string PreTestF_name = " + '"' + '"' + ", string PreTestF_arg = " + '"' + '"', PreTestF, PreTestF_name, PreTestF_arg);
            //flow.WriteLine("\t\t{0}, " + '"' + "{1}" + '"' + ", " + '"' + "{2}" + '"' + ", //	string PostTestF = 0, string PostTestF_name = " + '"' + '"' + ", string PostTestF_arg = " + '"' + '"', PostTestF, PostTestF_name, PostTestF_arg);
            //flow.WriteLine("\t\t{0}, " + '"' + "{1}" + '"' + ", " + '"' + "{2}" + '"' + " //	string EndOfBodyF = 0, string EndOfBodyF_name = " + '"' + '"' + ", string EndOfBodyF_arg = " + '"' + '"', EndOfBodyF, EndOfBodyF_name, EndOfBodyF_arg);


            flow.WriteLine("\t);");
            flow.WriteLine("TEST_STEP_OUT()");
            //flow.WriteLine("TEST_STEP_OUT(testnum, " + '"' + "{0}" + '"' + ", {1}, {2})", var, G_FLAG_TRUE, G_VAL_TRUE);
            flow.WriteLine();

            if (ate_data[i, 6]?.ToString() == null && ate_data[i, 5]?.ToString().ToUpper() == "SKIP")
            {
                flow.WriteLine("}");
                flow.WriteLine();
            }


            else if (ate_data[i, 6]?.ToString() != null && ate_data[i, 5]?.ToString().ToUpper() == "SKIP")
            {

                string endcnt = ate_data[i, 6]?.ToString();
                MatchCollection matches = Regex.Matches(endcnt, ",");
                int cnt = matches.Count;

                if (cnt == 0)
                {
                    string temp_val = TEST_NAME.Substring(TEST_NAME.Length - 1);

                    if (endcnt == temp_val)
                    {
                        flow.WriteLine("}");
                    }
                }

                else if (cnt != 0)
                {
                    string[] cntarr;
                    cntarr = endcnt.Split(new char[] { ',' }, StringSplitOptions.None);


                    for (int x = 0; x < cntarr.GetLength(0); x++)
                    {
                        string temp_val = TEST_NAME.Substring(TEST_NAME.Length - 1);

                        if (cntarr[x] == temp_val)
                        {
                            flow.WriteLine("}");
                        }

                    }
                }




            }
        }



        public void MakePatNmaeFile(List<string> power_list_name, string power_list2)
        {
            DirectoryInfo dir = new DirectoryInfo(rootsavepath + "Pat\\");
            if (dir.Exists != true)
            {
                dir.Create();
            }

            string savePath = rootsavepath + "Pat\\" + power_list2 + ".txt";

            StreamWriter power_txt_name = new StreamWriter(new FileStream(savePath, FileMode.Create));

            for (int i = 0; i < power_list_name.Count; i++)
            {
                power_txt_name.WriteLine(power_list_name[i].ToString() + ".dat");
            }
            power_txt_name.Close();

        }



        //static void Main(string[] args)
        //{

        //    List<string> a = new List<string>();
        //    string d;
        //    string qq = "aaa";
        //    string ww = "bbb";
        //    string ee = "ccc";


        //    a.Add(qq + "__" + ww + "__" + qq);
        //    a.Add(qq + "__" + ww + "__" + qq);
        //    a.Add(qq + "__" + ww + "__" + ee);
        //    a.Add(qq + "__" + ww + "__" + ww);
        //    a.Add(qq + "__" + ww + "__" + qq);

        //    a = a.Distinct().ToList();

        //    string[] b = new string[a.Count()];
        //    b = a.ToArray();

        //    for (int i = 0; i < b.GetLength(0); i++)
        //    {
        //        Console.WriteLine(b[i].ToString());
        //    }

        //    string[][] c = new string[b.GetLength(0)][];
        //    for (int j = 0; j < b.GetLength(0); j++)
        //    {
        //        d = b[j];
        //        c[j] = d.Split(new string[] { "__" }, StringSplitOptions.None);
        //        for (int q = 0; q < 3; q++)
        //        {
        //            Console.Write(c[j][q].ToString());
        //            MatchCollection matches = Regex.Matches(c[j][q], "a");
        //            int cnt = matches.Count;
        //            Console.WriteLine(cnt.ToString());

        //        }


        //    }
        //    Console.ReadLine();
        //}




        //public void MakeFlagInit(object[,] ate_data, string flagname)
        //{

        //    //flag = new string[ptop_flow_data.GetLength(0)-4];
        //    //site_var = new string[ptop_flow_data.GetLength(0)-4];

        //    for (int i = 5; i <= ate_data.GetLength(0); i++)
        //    {


        //        if (ate_data[i, 22]?.ToString() != null)
        //        {
        //            flag.Add(ate_data[i, 22]?.ToString());
        //        }

        //        if (ate_data[i, 21]?.ToString() != null)
        //        {
        //            flag.Add(ate_data[i, 21]?.ToString());
        //        }

        //    }

        //    flag = flag.Distinct().ToList();


        //    string savePath = @form1.rootsavepath + flagname + ".txt";
        //    StreamWriter power_txt_name = new StreamWriter(new FileStream(savePath, FileMode.Create));

        //    for (int i = 0; i < flag.Count; i++)
        //    {
        //        power_txt_name.WriteLine("int {0} = 0;",flag[i].ToString());
        //    }
        //    power_txt_name.Close();

        //}



        //public void MakeFlow_Txt_etc(string test, int w)
        //{
        //    flow_num++;

        //    int testnum = flow_num;

        //    int i = w;


        //    string G_FLAG_TRUE = "1";
        //    string G_VAL_TRUE = "1";
        //    string var = "1";

        //    string TEST_NAME = ate_data[i, 8]?.ToString();


        //    string g_result_flag_var = "G_RESULT_DUMMY";
        //    string g_pass_flag_var = "G_PASS_DUMMAY";
        //    string g_fail_flag_var = "G_FAIL_DUMMAY";


        //    string HWBin = "BIN_NONE";
        //    string SWBin = "BIN_NONE";

        //    string tset = "";
        //    string pset = "";

        //    if (ate_data[i, 43]?.ToString() != null)
        //    {
        //        tset = ate_data[i, 43]?.ToString() + "_" + ate_data[i, 41]?.ToString() + "_" + ate_data[i, 42]?.ToString() + '.' + "bin";
        //    }

        //    if (ate_data[i, 45]?.ToString() != null)
        //    {
        //        pset = ate_data[i, 45]?.ToString() + "_" + ate_data[i, 39]?.ToString() + "_" + ate_data[i, 40]?.ToString() + '.' + "bin";
        //    }

        //    string arg3 = ate_data[i, 51]?.ToString();
        //    string arg6 = ate_data[i, 54]?.ToString();
        //    string arg16 = ate_data[i, 64]?.ToString();
        //    string arg19 = ate_data[i, 67]?.ToString();
        //    string arg51 = ate_data[i, 99]?.ToString();
        //    string arg52 = ate_data[i, 100]?.ToString();
        //    string arg53 = ate_data[i, 101]?.ToString();

        //    int powerset = 1;

        //    //if (ate_data[i, 30]?.ToString() != null)
        //    //{
        //    //    G_FLAG_TRUE = ate_data[i, 30]?.ToString();
        //    //}

        //    if (ate_data[i, 29]?.ToString() == "flag-true")
        //    {
        //        var = ate_data[i, 29]?.ToString();
        //        G_FLAG_TRUE = ate_data[i, 30]?.ToString();
        //        G_VAL_TRUE = "1";
        //    }


        //    if (ate_data[i, 29]?.ToString() == "site-var=")
        //    {
        //        var = ate_data[i, 29]?.ToString();
        //        G_FLAG_TRUE = ate_data[i, 30]?.ToString();
        //        G_VAL_TRUE = ate_data[i, 31]?.ToString();
        //    }

        //    if (ate_data[i, 21]?.ToString() != null)
        //    {
        //        g_pass_flag_var = ate_data[i, 21]?.ToString();
        //    }

        //    if (ate_data[i, 22]?.ToString() != null)
        //    {
        //        g_fail_flag_var = ate_data[i, 22]?.ToString();
        //    }

        //    if (ate_data[i, 17]?.ToString() != null)
        //    {
        //        HWBin = ate_data[i, 17]?.ToString();
        //    }

        //    if (ate_data[i, 19]?.ToString() != null)
        //    {
        //        SWBin = ate_data[i, 19]?.ToString();
        //    }


        //    if (ate_data[i, 37]?.ToString() != null)
        //    {
        //        type_name = ate_data[i, 37]?.ToString();
        //    }





        //    flow.WriteLine();
        //    flow.WriteLine("TEST_STEP_IN(testnum, {0}, {1}, {2})", var, G_FLAG_TRUE, G_VAL_TRUE);
        //    flow.WriteLine("testnum++; /*{0}*/ {1}();", testnum, test);
        //    flow.WriteLine("TEST_STEP_OUT(testnum, {0}, {1}, {2})", var, G_FLAG_TRUE, G_VAL_TRUE);
        //    flow.WriteLine();
        //}


    }
}
