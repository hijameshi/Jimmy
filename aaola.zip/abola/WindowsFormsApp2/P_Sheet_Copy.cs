﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Runtime.InteropServices;
using Microsoft.Office.Interop.Excel;
using Excel = Microsoft.Office.Interop.Excel;
using System.Text.RegularExpressions;

namespace abola
{
    partial class Bolt
    {

        public string[] temp_str;
        public string[,] aaa;



        public void SheetCopy(string copy_sheet)
        {
            int count = ptop_bb.Sheets.Count;
            //SelectWorksheet(copy_sheet);
            ate_bb.Sheets[copy_sheet].copy(ptop_bb.Sheets[count]);
        }

        public void SheetCopy(Workbook from, Workbook to, string copy_sheet)
        {
            int count = to.Sheets.Count;
            //SelectWorksheet(copy_sheet);
            from.Sheets[copy_sheet].copy(to.Sheets[count]);
        }


        public List<string> ListSingle(object[,] data, int a)
        {
            int row = data.GetLength(0);
            List<string> list = new List<string>();
            for (int i = 5; i <= row; i++)
            {
                if (data[i, a]?.ToString() != null)
                {
                    list.Add(data[i, a].ToString());
                }
            }
            list = list.Distinct().ToList();
            return list;
        }


        public string[][] ListTriple(object[,] ptop_flow_data, int a, int b, int c)
        {
            //int row = ptop_flow_data.GetLength(0);
            //List<Array> list = new List<Array>();
            //string[] array = new string[3];
            //for (int i = 5; i <= row; i++)
            //{
            //    array[0] = ptop_flow_data[i, a].ToString();
            //    array[1] = ptop_flow_data[i, b].ToString();
            //    array[2] = ptop_flow_data[i, c].ToString();
            //    list.Add(array);
            //}
            //list = list.Distinct().ToList();
            //return list;


            List<string> temp_list = new List<string>();
            string d;
            int row = ptop_flow_data.GetLength(0);

            for (int i = 5; i <= row; i++)
            {
            
            string aa = ptop_flow_data[i, a].ToString();
            string bb = ptop_flow_data[i, b].ToString();
            string cc = ptop_flow_data[i, c].ToString();

            temp_list.Add(aa + "__" + bb + "__" + aa);
            }

            temp_list = temp_list.Distinct().ToList();

            temp_str = new string[temp_list.Count()];
            temp_str = temp_list.ToArray();

            for (int i = 0; i < temp_str.GetLength(0); i++)
            {
                Console.WriteLine(temp_str[i].ToString());
            }

            string[][] temp_str2 = new string[temp_str.GetLength(0)][];
            for (int j = 0; j < temp_str.GetLength(0); j++)
            {
                d = temp_str[j];
                temp_str2[j] = d.Split(new string[] { "__" }, StringSplitOptions.None);
                for (int q = 0; q < 3; q++)
                {
                    Console.WriteLine(temp_str2[j][q].ToString());

                    MatchCollection matches = Regex.Matches(temp_str2[j][q], "a");
                    int cnt = matches.Count;
                    Console.WriteLine(cnt.ToString());
                }

            }


            return temp_str2;
        }




        public void UsedSeheetCopy(List<string> list)
        {
            //int row = ptop_flow_data.GetLength(0);
            //List<string> list = new List<string>();
            //for (int i = 5; i <= row; i++)
            //{
            //    list.Add(ptop_flow_data[i, 10].ToString());
            //}
            //list = list.Distinct().ToList();

            for (int i = 0; i < list.Count(); i++)
            {
                //Console.WriteLine(list[i].ToString());
                SheetCopy(list[i].ToString());
            }


        }


    }
}
