﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Runtime.InteropServices;
using Microsoft.Office.Interop.Excel;
using Excel = Microsoft.Office.Interop.Excel;
using System.IO;

namespace abola
{
    partial class Bolt
    {




//        Public Function READ_DVFS_TABLE()

//Dim dvfs_level_count, asv_group_count As Integer
//Dim ThisSite As Variant
//Dim Lmax_offset As Double

//On Error GoTo errHandler

//'######## DVFS Table Select #######

//    If 0 < InStr(1, Part_ID_LEFT, "9820") Then

//        DVFS_TABLE = "DVFS_TABLE"
//        TheExec.Datalog.WriteComment("### DVFS_TABLE_MK ###") 'Add OY By KTJ
        
//    ElseIf 0 < InStr(1, Part_ID_LEFT, "9825") Then

//        DVFS_TABLE = "DVFS_TABLE_BJM"
//        TheExec.Datalog.WriteComment("### DVFS_TABLE_BJM ###") 'Add OY By KTJ
    
//    Else

//        DVFS_TABLE = "DVFS_TABLE_BJM"
//        TheExec.Datalog.WriteComment("### DVFS_TABLE_BJM ###") 'Add OY By KTJ
    
//    End If

//'##################################

//    If CT9D_IDS_MAX(1) = 0 Then

//        Lmax_offset = 0.05  'Temporary Voltage Offset

//        'CT9D CORE DVFS TABLE READ
//        For asv_group_count = 0 To 8
//            CT9D_IDS_MAX(asv_group_count) = CLng(Sheets(DVFS_TABLE).Cells(5, asv_group_count + 5))
//            PM9D_IDS_MAX(asv_group_count) = CLng(Sheets(DVFS_TABLE).Cells(11, asv_group_count + 5))
//            AN9Q_IDS_MAX(asv_group_count) = CLng(Sheets(DVFS_TABLE).Cells(17, asv_group_count + 5))
//            BN9DD_IDS_MAX(asv_group_count) = CLng(Sheets(DVFS_TABLE).Cells(23, asv_group_count + 5))
//            MIF_IDS_MAX(asv_group_count) = CLng(Sheets(DVFS_TABLE).Cells(29, asv_group_count + 5))
//            INT_IDS_MAX(asv_group_count) = CLng(Sheets(DVFS_TABLE).Cells(35, asv_group_count + 5))
//            CP_IDS_MAX(asv_group_count) = CLng(Sheets(DVFS_TABLE).Cells(41, asv_group_count + 5))
//            CAM_IDS_MAX(asv_group_count) = CLng(Sheets(DVFS_TABLE).Cells(47, asv_group_count + 5))

//            CT9D_RO_MAX(asv_group_count) = CLng(Sheets(DVFS_TABLE).Cells(7, asv_group_count + 5))
//            PM9D_RO_MAX(asv_group_count) = CLng(Sheets(DVFS_TABLE).Cells(13, asv_group_count + 5))
//            AN9Q_RO_MAX(asv_group_count) = CLng(Sheets(DVFS_TABLE).Cells(19, asv_group_count + 5))
//            BN9DD_RO_MAX(asv_group_count) = CLng(Sheets(DVFS_TABLE).Cells(25, asv_group_count + 5))
//            MIF_RO_MAX(asv_group_count) = CLng(Sheets(DVFS_TABLE).Cells(31, asv_group_count + 5))
//            INT_RO_MAX(asv_group_count) = CLng(Sheets(DVFS_TABLE).Cells(37, asv_group_count + 5))
//            CP_RO_MAX(asv_group_count) = CLng(Sheets(DVFS_TABLE).Cells(43, asv_group_count + 5))
//            CAM_RO_MAX(asv_group_count) = CLng(Sheets(DVFS_TABLE).Cells(49, asv_group_count + 5))
//        Next asv_group_count

//        'CT9D CORE DVFS TABLE READ
//        For asv_group_count = 0 To 8
//            CT9D_DVFS_L0(0, asv_group_count) = Round((Sheets(DVFS_TABLE).Cells(58, asv_group_count + 5)) / 1000, 4)                     'L0 DATA
//            CT9D_DVFS_ARM_L0(0, asv_group_count) = Round((Sheets(DVFS_TABLE).Cells(58, asv_group_count + 15)) / 1000, 4)                     'L0 TD DATA
//            CT9D_DVFS_TD_L0(0, asv_group_count) = Round((Sheets(DVFS_TABLE).Cells(58, asv_group_count + 25)) / 1000, 4)                     'L0 TD DATA
//'            CT9D_DVFS_L0(1, asv_group_count) = Round((Sheets(DVFS_TABLE).Cells(46, asv_group_count + 5)) / 1000, 4)                     'L0 DATA
//'            CT9D_DVFS_L0(2, asv_group_count) = Round((Sheets(DVFS_TABLE).Cells(59, asv_group_count + 5)) / 1000, 4)                     'L0 DATA
//            CT9D_DVFS_Lmax(0, asv_group_count) = Round((Sheets(DVFS_TABLE).Cells(77, asv_group_count + 5)) / 1000, 4)                     'LMAX DATA
//            CT9D_DVFS_ARM_Lmax(0, asv_group_count) = Round((Sheets(DVFS_TABLE).Cells(77, asv_group_count + 15)) / 1000, 4)                     'LMAX DATA
//            CT9D_DVFS_TD_Lmax(0, asv_group_count) = Round((Sheets(DVFS_TABLE).Cells(77, asv_group_count + 25)) / 1000, 4)                     'LMAX DATA

//''            CT9D_DVFS_ICACHE(0, asv_group_count) = Round((Sheets(DVFS_TABLE).Cells(47, asv_group_count + 5)) / 1000, 4)                     'L0 ICACHE DATA
//''            CT9D_DVFS_ICACHE(1, asv_group_count) = Round((Sheets(DVFS_TABLE).Cells(45, asv_group_count + 5)) / 1000, 4)                     'I-Cache 2.5G DATA
//        Next asv_group_count

//        'MID CORE DVFS TABLE READ
//        For asv_group_count = 0 To 8
//            PM9D_DVFS_L0(0, asv_group_count) = Round((Sheets(DVFS_TABLE).Cells(82, asv_group_count + 5)) / 1000, 4)                      'L0 DATA
//            PM9D_DVFS_ARM_L0(0, asv_group_count) = Round((Sheets(DVFS_TABLE).Cells(82, asv_group_count + 15)) / 1000, 4)                      'L0 DATA
//            PM9D_DVFS_TD_L0(0, asv_group_count) = Round((Sheets(DVFS_TABLE).Cells(82, asv_group_count + 25)) / 1000, 4)                      'L0 DATA
//'            PM9D_DVFS_L0(1, asv_group_count) = Round((Sheets(DVFS_TABLE).Cells(100, asv_group_count + 5)) / 1000, 4)                     'L0 DATA
//            PM9D_DVFS_Lmax(0, asv_group_count) = Round((Sheets(DVFS_TABLE).Cells(99, asv_group_count + 5)) / 1000, 4)                   'LMAX DATA
//            PM9D_DVFS_ARM_Lmax(0, asv_group_count) = Round((Sheets(DVFS_TABLE).Cells(99, asv_group_count + 15)) / 1000, 4)                   'LMAX DATA
//            PM9D_DVFS_TD_Lmax(0, asv_group_count) = Round((Sheets(DVFS_TABLE).Cells(99, asv_group_count + 25)) / 1000, 4)                   'LMAX DATA
//        Next asv_group_count

//        'LTL CORE DVFS TABLE READ
//        For asv_group_count = 0 To 8
//            AN9Q_DVFS_L0(0, asv_group_count) = Round((Sheets(DVFS_TABLE).Cells(107, asv_group_count + 5)) / 1000, 4)                      'L0 DATA
//            AN9Q_DVFS_ARM_L0(0, asv_group_count) = Round((Sheets(DVFS_TABLE).Cells(107, asv_group_count + 15)) / 1000, 4)                      'L0 DATA
//            AN9Q_DVFS_TD_L0(0, asv_group_count) = Round((Sheets(DVFS_TABLE).Cells(107, asv_group_count + 25)) / 1000, 4)                      'L0 DATA
//            AN9Q_DVFS_Lmax(0, asv_group_count) = Round((Sheets(DVFS_TABLE).Cells(122, asv_group_count + 5)) / 1000, 4)                   'LMAX DATA
//            AN9Q_DVFS_ARM_Lmax(0, asv_group_count) = Round((Sheets(DVFS_TABLE).Cells(122, asv_group_count + 15)) / 1000, 4)                   'LMAX DATA
//            AN9Q_DVFS_TD_Lmax(0, asv_group_count) = Round((Sheets(DVFS_TABLE).Cells(122, asv_group_count + 25)) / 1000, 4)                   'LMAX DATA
//            AN9Q_DVFS_ARM_Lmax(1, asv_group_count) = Round((Sheets(DVFS_TABLE).Cells(123, asv_group_count + 15)) / 1000, 4)                   'Switching PLL, Booting
//        Next asv_group_count

//        'BN9DD DVFS TABLE READ
//        For asv_group_count = 0 To 8
//            BN9DD_DVFS_L0(0, asv_group_count) = Round((Sheets(DVFS_TABLE).Cells(128, asv_group_count + 5)) / 1000, 4)                     'L0 DATA
//            BN9DD_DVFS_ARM_L0(0, asv_group_count) = Round((Sheets(DVFS_TABLE).Cells(128, asv_group_count + 15)) / 1000, 4)                     'L0 DATA
//            BN9DD_DVFS_TD_L0(0, asv_group_count) = Round((Sheets(DVFS_TABLE).Cells(128, asv_group_count + 25)) / 1000, 4)                     'L0 DATA
//            BN9DD_DVFS_Lmax(0, asv_group_count) = Round((Sheets(DVFS_TABLE).Cells(137, asv_group_count + 5)) / 1000, 4)                   'LMAX DATA
//            BN9DD_DVFS_ARM_Lmax(0, asv_group_count) = Round((Sheets(DVFS_TABLE).Cells(137, asv_group_count + 15)) / 1000, 4)                   'LMAX DATA
//            BN9DD_DVFS_TD_Lmax(0, asv_group_count) = Round((Sheets(DVFS_TABLE).Cells(137, asv_group_count + 25)) / 1000, 4)                   'LMAX DATA
//        Next asv_group_count

//        'MIF DVFS TABLE READ
//        For asv_group_count = 0 To 8
//            MIF_DVFS_L0(0, asv_group_count) = Round((Sheets(DVFS_TABLE).Cells(144, asv_group_count + 5)) / 1000, 4)                     'L0 DATA
//            MIF_DVFS_DDRINT_L0(0, asv_group_count) = Round((Sheets(DVFS_TABLE).Cells(144, asv_group_count + 15)) / 1000, 4)                     'L1 DATA
//            MIF_DVFS_DDRINT_L0(1, asv_group_count) = Round((Sheets(DVFS_TABLE).Cells(152, asv_group_count + 15)) / 1000, 4)                     'L1 DATA
//            MIF_DVFS_Lmax(0, asv_group_count) = Round((Sheets(DVFS_TABLE).Cells(152, asv_group_count + 5)) / 1000, 4)                   'LMAX DATA
//        Next asv_group_count

//        'INT DVFS TABLE READ
//        For asv_group_count = 0 To 8
//            INT_DVFS_L0(0, asv_group_count) = Round((Sheets(DVFS_TABLE).Cells(157, asv_group_count + 5)) / 1000, 4)                     'L0 DATA
//            INT_DVFS_TD_L0(0, asv_group_count) = Round((Sheets(DVFS_TABLE).Cells(157, asv_group_count + 25)) / 1000, 4)                     'L0 DATA

//            INT_DVFS_Lmax(0, asv_group_count) = Round((Sheets(DVFS_TABLE).Cells(160, asv_group_count + 5)) / 1000, 4)                   'LMAX DATA
//            INT_DVFS_Lmax(1, asv_group_count) = Round((Sheets(DVFS_TABLE).Cells(161, asv_group_count + 5)) / 1000, 4)                   'LMAX DATA
//        Next asv_group_count

//        'DISP DVFS TABLE READ
//        For asv_group_count = 0 To 8
//            DISP_DVFS_L0(0, asv_group_count) = Round((Sheets(DVFS_TABLE).Cells(166, asv_group_count + 5)) / 1000, 4)                     'L0 DATA
//            DISP_DVFS_Lmax(0, asv_group_count) = Round((Sheets(DVFS_TABLE).Cells(169, asv_group_count + 5)) / 1000, 4)                   'LMAX DATA
//        Next asv_group_count

//        'INT_CAM DVFS TABLE READ
//        For asv_group_count = 0 To 8
//            INTCAM_DVFS_L0(0, asv_group_count) = Round((Sheets(DVFS_TABLE).Cells(176, asv_group_count + 5)) / 1000, 4)                  'L0 DATA
//            INTCAM_DVFS_Lmax(0, asv_group_count) = Round((Sheets(DVFS_TABLE).Cells(181, asv_group_count + 5)) / 1000, 4)                'LMAX DATA
//        Next asv_group_count

//        'CAM DVFS TABLE READ
//        For asv_group_count = 0 To 8
//            CAM_DVFS_L0(0, asv_group_count) = Round((Sheets(DVFS_TABLE).Cells(186, asv_group_count + 5)) / 1000, 4)                     'L0 DATA
//            CAM_DVFS_Lmax(0, asv_group_count) = Round((Sheets(DVFS_TABLE).Cells(190, asv_group_count + 5)) / 1000, 4)                   'LMAX DATA
//        Next asv_group_count

//        'CP DVFS TABLE READ
//        For asv_group_count = 0 To 8
//            CP_DVFS_L0(0, asv_group_count) = Round((Sheets(DVFS_TABLE).Cells(195, asv_group_count + 5)) / 1000, 4)                      'L0 DATA
//            CP_DVFS_L0(1, asv_group_count) = Round((Sheets(DVFS_TABLE).Cells(196, asv_group_count + 5)) / 1000, 4)                      'L0 DATA
//            CP_DVFS_MCWLINK_L0(0, asv_group_count) = Round((Sheets(DVFS_TABLE).Cells(196, asv_group_count + 15)) / 1000, 4)                      'L0 DATA
//            CP_DVFS_TD_L0(0, asv_group_count) = Round((Sheets(DVFS_TABLE).Cells(195, asv_group_count + 25)) / 1000, 4)                      'L0 DATA
//            'CP_DVFS_Lmax(0, asv_group_count) = Round((Sheets(DVFS_TABLE).Cells(197, asv_group_count + 5)) / 1000, 4)                    'LMAX DATA
//        Next asv_group_count

//        'IVA DVFS TABLE READ
//        For asv_group_count = 0 To 8
//            IVA_DVFS_L0(0, asv_group_count) = Round((Sheets(DVFS_TABLE).Cells(203, asv_group_count + 5)) / 1000, 4)                      'L0 DATA
//            IVA_DVFS_Lmax(0, asv_group_count) = Round((Sheets(DVFS_TABLE).Cells(207, asv_group_count + 5)) / 1000, 4)                    'LMAX DATA
//        Next asv_group_count

//        'SCORE DVFS TABLE READ
//        For asv_group_count = 0 To 8
//            SCORE_DVFS_L0(0, asv_group_count) = Round((Sheets(DVFS_TABLE).Cells(214, asv_group_count + 5)) / 1000, 4)                      'L0 DATA
//            SCORE_DVFS_Lmax(0, asv_group_count) = Round((Sheets(DVFS_TABLE).Cells(217, asv_group_count + 5)) / 1000, 4)                    'LMAX DATA
//        Next asv_group_count

//        'AUD DVFS TABLE READ
//        For asv_group_count = 0 To 8
//            AUD_DVFS_L0(0, asv_group_count) = Round((Sheets(DVFS_TABLE).Cells(223, asv_group_count + 5)) / 1000, 4)                      'L0 DATA
//            AUD_DVFS_Lmax(0, asv_group_count) = Round((Sheets(DVFS_TABLE).Cells(227, asv_group_count + 5)) / 1000, 4)                    'LMAX DATA
//        Next asv_group_count

//        'MFC DVFS TABLE READ
//        For asv_group_count = 0 To 8
//            MFC_DVFS_L0(0, asv_group_count) = Round((Sheets(DVFS_TABLE).Cells(232, asv_group_count + 5)) / 1000, 4)                      'L0 DATA
//            MFC_DVFS_Lmax(0, asv_group_count) = Round((Sheets(DVFS_TABLE).Cells(236, asv_group_count + 5)) / 1000, 4)                    'LMAX DATA
//        Next asv_group_count

//        'NPU DVFS TABLE READ
//        For asv_group_count = 0 To 8
//            NPU_DVFS_L0(0, asv_group_count) = Round((Sheets(DVFS_TABLE).Cells(241, asv_group_count + 5)) / 1000, 4)                      'L0 DATA
//            NPU_DVFS_Lmax(0, asv_group_count) = Round((Sheets(DVFS_TABLE).Cells(247, asv_group_count + 5)) / 1000, 4)                    'LMAX DATA
//        Next asv_group_count

//        'SCI DVFS TABLE READ
//        For asv_group_count = 0 To 8
//            SCI_DVFS_TD_L0(0, asv_group_count) = Round((Sheets(DVFS_TABLE).Cells(253, asv_group_count + 25)) / 1000, 4)                      'L0 DATA
//        Next asv_group_count

//'''        'SOC/CP TOTAL L0 TABLE READ
//'''        For asv_group_count = 0 To 8
//'''            SOC_TOTAL_L0(0, asv_group_count) = Round((Sheets(DVFS_TABLE).Cells(198, asv_group_count + 5)) / 1000, 4)                      'SOC L0 DATA
//'''            CP_TOTAL_L0(0, asv_group_count) = Round((Sheets(DVFS_TABLE).Cells(202, asv_group_count + 5)) / 1000, 4)                       'CP L0 DATA
//'''            SOC_TOTAL_TD_L0(0, asv_group_count) = Round((Sheets(DVFS_TABLE).Cells(198, asv_group_count + 15)) / 1000, 4)                      'SOC L0 DATA
//'''            CP_TOTAL_TD_L0(0, asv_group_count) = Round((Sheets(DVFS_TABLE).Cells(202, asv_group_count + 15)) / 1000, 4)                       'CP L0 DATA
//'''        Next asv_group_count

//        TheExec.Datalog.WriteComment(vbTab & vbTab & "### Compeleted READ DVFS TABLE ###")
//    End If

//    Exit Function

//errHandler:

//    TheExec.Datalog.WriteComment(vbTab & vbTab & "==========>>>>>> Error READ DVFS TABLE <<<<<<==========")
//    For Each ThisSite In TheExec.Sites.Active
//        TheExec.Sites.Site(ThisSite).SiteVariableValue("READ_INIT_VALUE_SiteVar") = 2
//    Next ThisSite
//End Function

    }
}
