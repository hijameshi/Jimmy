﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Runtime.InteropServices;
using Microsoft.Office.Interop.Excel;
using Excel = Microsoft.Office.Interop.Excel;
using System.IO;

namespace abola
{

    //@Created on 2019. 08.23
    //@author: hojun kim

    partial class Bolt
    {
        public void getflag(Workbook book)
        {
            string[] sheetname = new string[book.Worksheets.Count];
            int count = book.Worksheets.Count;


            //for (int i = 1; i <= count; i++)
            //{
            //    ate_ss = book.Worksheets[i] as Excel.Worksheet;
            //    sheetname[i - 1] = ate_ss.Name;

            //if (sheetname[i - 1].Length > 4)
            //{
            //    if (sheetname[i - 1].Substring(0, 4).ToUpper() == "FLOW")
            //    {
            //        ReadRange();
            //        CopyToArray();
            //        //CopyToArrayString();

            //        MakeFlag(ate_data, "flag_list");
            //        //MakeSitevar(ate_data, "var_list");
            //    }
            //}

            //}

            for (int i = 1; i <= count; i++)
            {
                ate_ss = book.Worksheets[i] as Excel.Worksheet;
                sheetname[i - 1] = ate_ss.Name;

                if (sheetname[i - 1].Length > 4)
                {
                    if (sheetname[i - 1].ToString().ToUpper().Contains("FLOW TABLE") || sheetname[i - 1].ToString().ToUpper().Contains("FLOW_TABLE"))
                    {
                        ReadRange();
                        CopyToArray();
                        //CopyToArrayString();

                        MakeFlag_only_flow(ate_data, "flag_list");
                        //MakeSitevar(ate_data, "var_list");
                    }
                }
            }

            for (int i = 1; i <= count; i++)
            {
                ate_ss = book.Worksheets[i] as Excel.Worksheet;
                sheetname[i - 1] = ate_ss.Name;

                if (sheetname[i - 1].Length > 4)
                {
                    if (sheetname[i - 1].Substring(0, 4).ToUpper() == "FLOW" && (!sheetname[i - 1].ToString().ToUpper().Contains("FLOW TABLE") && !sheetname[i - 1].ToString().ToUpper().Contains("FLOW_TABLE")))
                    {
                        ReadRange();
                        CopyToArray();
                        //CopyToArrayString();

                        MakeFlag_only_flow(ate_data, "flag_list");
                        //MakeSitevar(ate_data, "var_list");
                    }
                }
            }

            Flag_Disinct();
            MakeFlagSave("flag_list");
            //MakeSitevarSave("var_list");
        }

        public void Flag_Disinct()
        {
            flag = flag.Distinct().ToList();
            site_var = site_var.Distinct().ToList();
            not_assign_flag = not_assign_flag.Distinct().ToList();
            //not_assign_var = not_assign_var.Distinct().ToList();

            for (int i = 0; i < not_assign_flag.Count; i++)
            {
                string a = not_assign_flag[i];
                if (flag.IndexOf(a) >= 0)
                {
                    continue;
                }
                if (site_var_check.IndexOf(a) >= 0)
                {
                    continue;
                }
                else
                {
                    not_assign_flag_sort.Add(a);
                }
            }

            not_assign_flag_sort = not_assign_flag_sort.Distinct().ToList();


        }


        public void MakeFlag_only_flow(object[,] ate_data, string flagname)
        {
            string temp;
            //string temp_val;
            string temp_var;
            string temp_var_val;


            if (ate_data[4, 2]?.ToString().ToUpper() == "LABEL")
            {
                start = 7;
            }

            else if (ate_data[4, 1]?.ToString().ToUpper() == "LABEL")
            {
                start = 6;
            }

            for (int i = 5; i <= ate_data.GetLength(0); i++)
            {
                string test_name_p0 = ate_data[i, start]?.ToString();
                string test_name_p1 = ate_data[i + 1, start]?.ToString();
                string test_name_p2 = ate_data[i + 2, start]?.ToString();
                string test_name_p3 = ate_data[i + 3, start]?.ToString();

                if (
                    (test_name_p0 != "flag-false-all" && test_name_p0 != "assign-site-var" && test_name_p0 != "create-site-var" && test_name_p0 != "disable-flow-word" && test_name_p0 != "nop")
                    && (test_name_p1 != "flag-false-all" && test_name_p1 != "assign-site-var" && test_name_p1 != "create-site-var" && test_name_p1 != "disable-flow-word" && test_name_p1 != "nop")
                    && (test_name_p2 != "flag-false-all" && test_name_p2 != "assign-site-var" && test_name_p2 != "create-site-var" && test_name_p2 != "disable-flow-word" && test_name_p2 != "nop")
                    && (test_name_p3 != "flag-false-all" && test_name_p3 != "assign-site-var" && test_name_p3 != "create-site-var" && test_name_p3 != "disable-flow-word" && test_name_p3 != "nop")
                   )
                {
                    break;
                }  

                if (ate_data[i, start]?.ToString() == "flag-false-all")
                {
                    //string aaa = ate_data[i, 8]?.ToString();

                    temp = ate_data[i, start + 1]?.ToString();
                    //temp_val = temp.Substring(temp.Length - 1);
                    temp = temp.Replace(" ", "");
                    //temp = temp.Substring(0, temp.Length - 1);

                    flag.Add(temp);
                    //site_var_val.Add(temp_val);

                }

                if (ate_data[i, start]?.ToString() == "assign-site-var")
                {
                    //string aaa = ate_data[i, 8]?.ToString();

                    temp_var = ate_data[i, start + 1]?.ToString();
                    int index = temp_var.IndexOf(" ");
                    temp_var = temp_var.Replace(" ", "");
                    temp_var_val = temp_var.Substring(index);
                    temp_var = temp_var.Substring(0, index);

                    string temptemp = temp_var + " = " + temp_var_val;
                    site_var.Add(temptemp);
                    site_var_check.Add(temp_var);

                    //site_var.Add(temp_var);
                    //site_var_val.Add(temp_var_val);
                }
            }

            for (int i = 5; i <= ate_data.GetLength(0); i++)
            {
                if (ate_data[i, start - 5]?.ToString().ToUpper() != null) //Label
                {
                    //string aaa = ate_data[i, 8]?.ToString();

                    temp = ate_data[i, start - 5]?.ToString();
                    //temp_val = temp.Substring(temp.Length - 1);
                    temp = temp.Replace(" ", "");
                    //temp = temp.Substring(0, temp.Length - 1);

                    flag.Add(temp);
                    //site_var_val.Add(temp_val);

                }
            }

            for (int i = 5; i <= ate_data.GetLength(0); i++)
            {
                if (ate_data[i, start + 15]?.ToString().ToUpper() != null) //flag_fail
                {
                    //string aaa = ate_data[i, 8]?.ToString();

                    temp = ate_data[i, start + 15]?.ToString();
                    //temp_val = temp.Substring(temp.Length - 1);
                    temp = temp.Replace(" ", "");
                    //temp = temp.Substring(0, temp.Length - 1);

                    not_assign_flag.Add(temp);
                    //site_var_val.Add(temp_val);

                }

                if (ate_data[i, start + 22]?.ToString() == "flag-true")
                {
                    //string aaa = ate_data[i, 8]?.ToString();

                    temp = ate_data[i, start + 22 + 1]?.ToString();
                    //temp_val = temp.Substring(temp.Length - 1);
                    temp = temp.Replace(" ", "");
                    //temp = temp.Substring(0, temp.Length - 1);

                    not_assign_flag.Add(temp);
                    //site_var_val.Add(temp_val);

                }
            }

                //if (ate_data[i, start + 22]?.ToString() == "site-var=")
                //{
                //    //string aaa = ate_data[i, 8]?.ToString();

                //    temp_var = ate_data[i, start +22 + 1 ]?.ToString();
                //    int index = temp_var.IndexOf(" ");
                //    temp_var = temp_var.Replace(" ", "");
                //    temp_var_val = temp_var.Substring(index);
                //    temp_var = temp_var.Substring(0, index);

                //    string temptemp = temp_var + " = " + temp_var_val;
                //    not_assign_var.Add(temptemp);

                //    //site_var.Add(temp_var);
                //    //site_var_val.Add(temp_var_val);
                //}            


            //for (int i = 0; i < not_assign_var.Count; i++)
            //{
            //    string a = not_assign_var[i];
            //    if (site_var.IndexOf(a) >= 0)
            //    {
            //        continue;
            //    }
            //    else
            //    {
            //        not_assign_var_sort.Add(a);
            //    }
            //}

            //not_assign_var_sort = not_assign_var_sort.Distinct().ToList();

        }



        public void MakeFlag(object[,] ate_data, string flagname)
        {
            string temp;
            //string temp_val;
            string temp_var;
            string temp_var_val;


            if (ate_data[4, 2]?.ToString().ToUpper() == "LABEL")
            {
                start = 7;
            }

            else if (ate_data[4, 1]?.ToString().ToUpper() == "LABEL")
            {
                start = 6;
            }

            for (int i = 5; i <= ate_data.GetLength(0); i++)
            {

                if (ate_data[i, start + 15]?.ToString().ToUpper() != null) //flag_fail
                {
                    //string aaa = ate_data[i, 8]?.ToString();

                    temp = ate_data[i, start + 15]?.ToString();
                    //temp_val = temp.Substring(temp.Length - 1);
                    temp = temp.Replace(" ", "");
                    //temp = temp.Substring(0, temp.Length - 1);

                    flag.Add(temp);
                    //site_var_val.Add(temp_val);

                }


                if (ate_data[i, start - 5]?.ToString().ToUpper() != null) //Label
                {
                    //string aaa = ate_data[i, 8]?.ToString();

                    temp = ate_data[i, start - 5]?.ToString();
                    //temp_val = temp.Substring(temp.Length - 1);
                    temp = temp.Replace(" ", "");
                    //temp = temp.Substring(0, temp.Length - 1);

                    flag.Add(temp);
                    //site_var_val.Add(temp_val);

                }

            }

            for (int i = 5; i <= ate_data.GetLength(0); i++)
            {
                if (ate_data[i, start + 22]?.ToString() == "flag-true")
                {
                    //string aaa = ate_data[i, 8]?.ToString();

                    temp = ate_data[i, start + 22 + 1]?.ToString();
                    //temp_val = temp.Substring(temp.Length - 1);
                    temp = temp.Replace(" ", "");
                    //temp = temp.Substring(0, temp.Length - 1);

                    not_assign_flag.Add(temp);
                    //site_var_val.Add(temp_val);

                }

                //if (ate_data[i, start + 22]?.ToString() == "site-var=")
                //{
                //    //string aaa = ate_data[i, 8]?.ToString();

                //    temp_var = ate_data[i, start +22 + 1 ]?.ToString();
                //    int index = temp_var.IndexOf(" ");
                //    temp_var = temp_var.Replace(" ", "");
                //    temp_var_val = temp_var.Substring(index);
                //    temp_var = temp_var.Substring(0, index);

                //    string temptemp = temp_var + " = " + temp_var_val;
                //    not_assign_var.Add(temptemp);

                //    //site_var.Add(temp_var);
                //    //site_var_val.Add(temp_var_val);
                //}

            }

            not_assign_flag = not_assign_flag.Distinct().ToList();
            //not_assign_var = not_assign_var.Distinct().ToList();

            for (int i = 0; i < not_assign_flag.Count; i++)
            {
                string a = not_assign_flag[i];
                if (flag.IndexOf(a) >= 0)
                {
                    continue;
                }
                else
                {
                    not_assign_flag_sort.Add(a);
                }
            }

            //for (int i = 0; i < not_assign_var.Count; i++)
            //{
            //    string a = not_assign_var[i];
            //    if (site_var.IndexOf(a) >= 0)
            //    {
            //        continue;
            //    }
            //    else
            //    {
            //        not_assign_var_sort.Add(a);
            //    }
            //}

            //not_assign_var_sort = not_assign_var_sort.Distinct().ToList();
            not_assign_flag_sort = not_assign_flag_sort.Distinct().ToList();


        }


        public void MakeFlagSave(string flagname)
        {



            string savePath = rootsavepath + flagname + ".txt";
            StreamWriter power_txt_name = new StreamWriter(new FileStream(savePath, FileMode.Create));

            power_txt_name.WriteLine("#pragma region flag_list");

            for (int i = 0; i < flag.Count; i++)
            {
                power_txt_name.WriteLine("int {0} = 0;",
                    flag[i].ToString());
                //site_var_val[i].ToString());
            }

            for (int i = 0; i < site_var.Count; i++)
            {
                power_txt_name.WriteLine("int {0};",
                    site_var[i].ToString());
                //site_var_val[i].ToString());
            }

            power_txt_name.WriteLine("#pragma endregion");
            power_txt_name.WriteLine("\n");
            power_txt_name.WriteLine("\n");
            power_txt_name.WriteLine("#pragma region not_assigned_flag_list");

            for (int i = 0; i < not_assign_flag_sort.Count; i++)
            {
                power_txt_name.WriteLine("int {0} = 0;",
                    not_assign_flag_sort[i].ToString());
                //site_var_val[i].ToString());
            }

            //for (int i = 0; i < not_assign_var_sort.Count; i++)
            //{
            //    power_txt_name.WriteLine("int {0};",
            //        not_assign_var_sort[i].ToString());
            //    //site_var_val[i].ToString());
            //}


            power_txt_name.WriteLine("#pragma endregion");

            power_txt_name.Close();


            savePath = rootsavepath + flagname + "_init.txt";
            power_txt_name = new StreamWriter(new FileStream(savePath, FileMode.Create));

            power_txt_name.WriteLine("#pragma region flag_init_list");

            for (int i = 0; i < flag.Count; i++)
            {
                power_txt_name.WriteLine("{0} = 0;",
                    flag[i].ToString());
                //site_var_val[i].ToString());
            }

            for (int i = 0; i < site_var.Count; i++)
            {
                power_txt_name.WriteLine("{0};",
                    site_var[i].ToString());
                //site_var_val[i].ToString());
            }

            power_txt_name.WriteLine("#pragma endregion");
            power_txt_name.WriteLine("\n");
            power_txt_name.WriteLine("\n");
            power_txt_name.WriteLine("#pragma region not_assigned_flag_init_list");


            for (int i = 0; i < not_assign_flag_sort.Count; i++)
            {
                power_txt_name.WriteLine("{0} = 0;",
                    not_assign_flag_sort[i].ToString());
                //site_var_val[i].ToString());
            }

            //for (int i = 0; i < not_assign_var_sort.Count; i++)
            //{
            //    power_txt_name.WriteLine("{0};",
            //        not_assign_var_sort[i].ToString());
            //    //site_var_val[i].ToString());
            //}

            power_txt_name.WriteLine("#pragma endregion");

            power_txt_name.Close();

        }



        public void MakeSitevar(object[,] ate_data, string flagname)
        {

            string temp_var;
            string temp_var_val;
            for (int i = 5; i <= ate_data.GetLength(0); i++)
            {
                if (ate_data[i, 7]?.ToString() == "assign-site-var")
                {
                    //string aaa = ate_data[i, 8]?.ToString();

                    temp_var = ate_data[i, 8]?.ToString();
                    int index = temp_var.IndexOf(" ");
                    temp_var = temp_var.Replace(" ", "");
                    temp_var_val = temp_var.Substring(index);
                    temp_var = temp_var.Substring(0, index);

                    string temptemp = temp_var + " = " + temp_var_val;
                    site_var.Add(temptemp);

                    //site_var.Add(temp_var);
                    //site_var_val.Add(temp_var_val);


                }
            }
        }


        public void MakeSitevarSave(string flagname)
        {
            site_var = site_var.Distinct().ToList();

            string savePath = rootsavepath + flagname + ".txt";
            StreamWriter power_txt_name = new StreamWriter(new FileStream(savePath, FileMode.Create));

            power_txt_name.WriteLine("#pragma region var_list");

            for (int i = 0; i < site_var.Count; i++)
            {
                power_txt_name.WriteLine("int {0};",
                    site_var[i].ToString());
                //site_var_val[i].ToString());
            }

            power_txt_name.WriteLine("#pragma endregion");

            power_txt_name.Close();


            savePath = rootsavepath + flagname + "_init.txt";
            power_txt_name = new StreamWriter(new FileStream(savePath, FileMode.Create));

            power_txt_name.WriteLine("#pragma region var_init_list");

            for (int i = 0; i < site_var.Count; i++)
            {
                power_txt_name.WriteLine("{0};",
                    site_var[i].ToString());
                //site_var_val[i].ToString());
            }

            power_txt_name.WriteLine("#pragma endregion");

            power_txt_name.Close();


        }



    }
}
