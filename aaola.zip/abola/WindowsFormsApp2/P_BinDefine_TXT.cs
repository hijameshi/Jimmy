﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Runtime.InteropServices;
using Microsoft.Office.Interop.Excel;
using Excel = Microsoft.Office.Interop.Excel;
using System.Text.RegularExpressions;
using System.IO;
using System.Data;


namespace abola
{
    partial class Bolt
    {

        public string[,] bintable_data;
        public string[,] summary_data;
        public string[,] flagcheck_data;

        public string[,] bindefine_data;




        public void CopyObjectSummary()
        {
            summary_data = new string[ate_data.GetLength(0), ate_data.GetLength(1)];
            for (int i = 1; i <= ate_data.GetLength(0); i++)
            {
                for (int j = 1; j <= ate_data.GetLength(1); j++)
                {
                    summary_data[i-1,j-1] = ate_data[i,j]?.ToString();
                }
            }
        }


        public void CopyObjectBintable()
        {
            bintable_data = new string[ate_data.GetLength(0), ate_data.GetLength(1)];
            for (int i = 1; i <= ate_data.GetLength(0); i++)
            {
                for (int j = 1; j <= ate_data.GetLength(1); j++)
                {
                    bintable_data[i - 1, j - 1] = ate_data[i, j]?.ToString();
                }
            }
        }

        public void CopyObjectFlagcheck()
        {
            flagcheck_data = new string[ate_data.GetLength(0), ate_data.GetLength(1)];
            for (int i = 1; i <= ate_data.GetLength(0); i++)
            {
                for (int j = 1; j <= ate_data.GetLength(1); j++)
                {
                    flagcheck_data[i - 1, j - 1] = ate_data[i, j]?.ToString();
                }
            }
        }
        


        //public void CreatNewSheet_par(string ptop_ss_name, string after_val)
        //{
        //    Worksheet temp_ss;

        //    if (ate_bb.Worksheets[ptop_ss_name] == null)
        //    {
        //        temp_ss = ate_bb.Worksheets[after_val];
        //        ptop_ss = ate_bb.Worksheets.Add(After: temp_ss);
        //        ptop_ss.Name = (ptop_ss_name);
        //    }
        //    if (ate_bb.Worksheets[ptop_ss_name] != null)
        //    {
        //        Worksheet temp = ate_bb.Worksheets[ptop_ss_name];
        //        temp.Delete();
        //        temp_ss = ate_bb.Worksheets[after_val];
        //        ptop_ss = ate_bb.Worksheets.Add(After: temp_ss);
        //        ptop_ss.Name = (ptop_ss_name);
        //    }
        //}

        public void MakeBinDefine()
        {

            SelectWorksheet("bin_define");
            ate_ss.UsedRange.Clear();

            string[] bindefinenema = new string[30] { "bin_no_유무", "no", "testname", "flag_con.", "var_con.", "1st_bin", "1st_flag","to_2nd_con.", "2nd_flag_flag", "2nd_var_flag", "2nd_bin", "3rd_bin", "4th_bin", "4th_bin", "4th_bin", "4th_bin", "flag_list", "flag_list", "flag_list", "flag_list", "Op", "T/F", "T/F", "T/F", "T/F", "1st_var", "1st_var_val", "arg1", "arg1", "arg1"};


            for (int u = 0; u < 30; u++)
            {
                //int temp = u + 1;
                ate_ss.Cells[4, u+1] = bindefinenema[u];
                ate_ss.Cells[2, u + 1] = u.ToString();
            }

            ate_ss.Cells[3, 3] = "flow_table";
            //ate_ss.Cells[3, 8] = "instance";
            ate_ss.Cells[3, 9] = "flag_check";
            ate_ss.Cells[3, 12] = "bin_table";


            //string flagname = "bin_define";

            //string savePath = @form1.rootsavepath + flagname + ".txt";
            //StreamWriter bindefine_txt = new StreamWriter(new FileStream(savePath, FileMode.Create));


            bindefine_data = new string[summary_data.GetLength(0), 30];
            for (int i = 4; i< summary_data.GetLength(0); i++)
            {
                int temp_no = i-3;
                bindefine_data[i , 1] = temp_no.ToString(); //no.
                bindefine_data[i , 2] = summary_data[i , 7]; //test name

                if (summary_data[i , 28] == "flag-true")
                {
                    bindefine_data[i , 3] = summary_data[i , 29]; // condition flag
                }


                else if (summary_data[i , 28] == "site-var=")
                {
                    string temp_var = summary_data[i, 29];
                    string temp_var_val = temp_var.Substring(temp_var.Length - 1);
                    temp_var = temp_var.Replace(" ", "");
                    temp_var = temp_var.Substring(0, temp_var.Length - 1);

                    bindefine_data[i , 3] = temp_var; // condition var
                    bindefine_data[i , 4] = temp_var_val; // var value
                }

                bindefine_data[i , 5] = summary_data[i , 18]; // bin
                bindefine_data[i , 6] = summary_data[i , 21]; // fail flag

                bindefine_data[i , 21] = summary_data[i , 100]; // vbt var


                for (int j=0; j< flagcheck_data.GetLength(0); j++)
                {
                    if (summary_data[i, 21] != null && (summary_data[i, 21] == flagcheck_data[j,29]))
                    {
                        bindefine_data[i, 8] = flagcheck_data[j, 21];
                    }

                    if (summary_data[i, 100] != null && (summary_data[i, 100] != null && flagcheck_data[j, 27] != null))
                    {
                        string temp = summary_data[i, 100];
                        bool isThereWord = temp.Contains(flagcheck_data[j, 27]);
                        if (isThereWord)
                        {
                            bindefine_data[i, 9] = flagcheck_data[j, 21];
                        }
                    }

                    if (summary_data[i, 21] != null && (summary_data[i, 21] == flagcheck_data[j, 29]) && flagcheck_data[j,18]!=null)
                    {
                        bindefine_data[i, 10] = flagcheck_data[j, 18];
                    }


                }

                for (int t=0; t< summary_data.GetLength(0); t++)
                {
                    if(summary_data[i, 21] != null && (summary_data[i, 21] == summary_data[t, 29]))
                    {
                        int tempp = t - 3;
                        bindefine_data[i, 7] = tempp.ToString();
                    }
                }
                
                for (int j = 3; j < bintable_data.GetLength(0); j++)
                {
                    if (bindefine_data[i, 8] != null && bintable_data[j, 2] != null)
                    {
                        string temp5 = bintable_data[j, 2];
                        bool isThereWord = temp5.Contains(bindefine_data[i, 8]);

                        if (isThereWord)
                        {
                            string tempbt = bintable_data[j, 2];
                            MatchCollection matches = Regex.Matches(tempbt, ",");
                            int cnt = matches.Count;

                            string[] flag_split;
                            flag_split = tempbt?.Split(new char[] { ',' }, StringSplitOptions.None);

                            for (int c = 0; c <= cnt; c++)
                            {
                                bindefine_data[i, 16 + c] = flag_split[c];
                            }
                            bindefine_data[i, 12] = bintable_data[j, 4];
                        }
                    }

                    if (bindefine_data[i, 6] != null && bintable_data[j, 2] != null)
                    {
                        string temp6 = bintable_data[j, 2];
                        bool isThereWord = temp6.Contains(bindefine_data[i, 6]);

                        if (isThereWord)
                        {
                            bindefine_data[i, 11] = bintable_data[j, 4];
                        }
                    }
                }

                int aa = Convert.ToInt32(bindefine_data[i, 5]);
                int bb = Convert.ToInt32(bindefine_data[i, 7]);
                int cc = Convert.ToInt32(bindefine_data[i, 10]);
                int dd = Convert.ToInt32(bindefine_data[i, 11]);
                int ee = Convert.ToInt32(bindefine_data[i, 12]);

                if ( aa+bb+cc+dd+ee<= 0)
                {
                    bindefine_data[i, 0] = "X";
                }


                for (int k = 0; k < 30; k++)
                {
                    //bindefine_txt.Write(bindefine_data[i,k]?.ToString() + "\t");
                    ate_ss.Cells[i + 1, k + 1] = bindefine_data[i, k]?.ToString();
                }
                                
                //bindefine_txt.Write("\n");
            }


            //bindefine_txt.Close();

            //Save();

            

        }

        

    }
}
