﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Runtime.InteropServices;
using Microsoft.Office.Interop.Excel;
using Excel = Microsoft.Office.Interop.Excel;
using System.IO;

namespace abola
{
    //**************************************************
                //@Created on 2019. 08.23
                //@author: hojun kim
    //**************************************************

    partial class Bolt
    {
        static public List<string> bintablelist = new List<string>();
        static public string pattern_set;

        List<string> site_var = new List<string>();
        List<string> site_var_val = new List<string>();
        List<string> flag = new List<string>();
        List<string> site_var_check = new List<string>();
        List<string> not_assign_flag = new List<string>();
        List<string> not_assign_var = new List<string>();
        List<string> not_assign_flag_sort = new List<string>();
        List<string> not_assign_var_sort = new List<string>();

        string path = "";
        public static Excel.Application app;
        public Workbook ate_bb;
        public Workbook ptop_bb;
        public Worksheet ate_ss;
        public Worksheet ptop_ss;
        public Worksheet temp_ss;
        public Worksheet temp_ss2;
        public Worksheet init_ss;
        public Range ate_range;
        public Range temp_range;
        public Worksheet ptop_ss_temp;
        public Worksheet ptop_job_ss;
        
        Worksheet newmake_ss;

        public Range ptop_flow_range;
        public Range ptop_instance_range;
        public Range ptop_summary_range;
        public Range init_range;
        public Range ptop_job_range;

        public List<string> test_name = new List<string>();
        public List<string> test_name_list = new List<string>();
        public List<string> instance_list = new List<string>();
        //string[][] instance_list_triple = new string[][];

        //List<string> list = new List<string>();

        public object[,] ate_data;
        public object[,] temp_data;
        public object[,] init_data;
        public object[,] ptop_flow_data;
        public object[,] ptop_instance_data;
        public object[,] ptop_summary_data;
        public object[,] ate_data_object;
        public object[,] ptop_write_data;
        public object[,] ptop_temp_write_data;
        public object[,] ptop_job_data;

        public string[,] ate_data_string;


        public int sitevarcnt = 0;

        string flow_name;
        int start;

        int j = 0;
        int flag_j = 0;

        public Bolt()
        {
        }

        public Bolt(string path)
        {
            this.path = path;
            ate_bb = app.Workbooks.Open(path);
            //ws = wb.Worksheets[Sheet];
            //MessageBox.Show("Open 완료");
        }




        string job = "";



        public void MakeFlowSheet()
        {

            PotopSheetInit(ate_data);
            string[] varcheck = new string[3];

            string savePath2 = rootsavepath + "sitevar not 0 list.txt";
            sitevarnot0 = new StreamWriter(new FileStream(savePath2, FileMode.Create));



            for (int i = 5; i <= ate_data.GetLength(0); i++)
            {
                string test_name_p1 = ate_data[i + 1, 7]?.ToString();
                string test_name_p2 = ate_data[i + 2, 7]?.ToString();
                string test_name_p3 = ate_data[i + 3, 7]?.ToString();

                if ((test_name_p1 != "flag-false-all" && test_name_p1 != "assign-site-var" && test_name_p1 != "create-site-var" && test_name_p1 != "disable-flow-word" && test_name_p1 != "nop")
                    && (test_name_p2 != "flag-false-all" && test_name_p2 != "assign-site-var" && test_name_p2 != "create-site-var" && test_name_p2 != "disable-flow-word" && test_name_p2 != "nop")
                        && (test_name_p3 != "flag-false-all" && test_name_p3 != "assign-site-var" && test_name_p3 != "create-site-var" && test_name_p3 != "disable-flow-word" && test_name_p3 != "nop"))
                {
                    assign_flag_end_point = i;
                    break;
                }
            }

            for (int i = 1; i <= ate_data?.GetLength(0); i++)
            {

                if (ate_data[i, 7]?.ToString() == "flag-true-all")
                {
                    MessageBox.Show("flow sheet 에 flag-true-all 존재", "종료", MessageBoxButtons.OK);
                    Environment.Exit(0);
                    System.Diagnostics.Process.GetCurrentProcess().Kill();
                    this.Close();
                }

                if (ate_data[i, 7]?.ToString() == "assign-site-var")
                {

                    //string aaa = ate_data[i, 8]?.ToString();
                    //aaa = aaa.Substring(aaa.Length - 1);

                    string bbb = ate_data[i, 8]?.ToString();
                    int index = bbb.IndexOf(" ");
                    bbb = bbb.Replace(" ", "");
                    string aaa = bbb.Substring(index);
                    bbb = bbb.Substring(0, index);

                    if (aaa != "0")
                    {
                        sitevarcnt++;
                        //Environment.Exit(0);
                        //System.Diagnostics.Process.GetCurrentProcess().Kill();
                        //this.Close();

                        //MessageBox.Show("assign-site-var 에 0 이 아닌 값이 존재", "종료", MessageBoxButtons.OK);


                        sitevarnot0.WriteLine(bbb + " = " + aaa);
                    }



                }

                string job_name = ate_data[i, 4]?.ToString().ToUpper();
                string part_name = ate_data[i, 5]?.ToString().ToUpper();
                string env_name = ate_data[i, 6]?.ToString().ToUpper();
                string opcode_name = ate_data[i, 7]?.ToString().ToUpper();
                string test_name = ate_data[i, 8]?.ToString().ToUpper();
                string lolimit = ate_data[i, 11]?.ToString().ToUpper();
                string hilimit = ate_data[i, 12]?.ToString().ToUpper();


                if (job_name == "COMP" 
                    || job_name == "SCAN" 
                    || job_name == "OTP" 
                    || job_name == "ETC" 
                    || job_name == "BIN" 
                    || test_name == "FLAG_CHECK"
                    || opcode_name == "USE-LIMIT" 
                    || opcode_name == "BINTABLE"
                    || ate_data[i, 7]?.ToString() == "flag-false-all" 
                    || ate_data[i, 7]?.ToString() == "assign-site-var"
                    || opcode_name == "SET-DEVICE"
                    )
                {

                    job = ate_data[i, 4]?.ToString();


                    if (job_name == "BIN" && opcode_name == "CALL")
                    {
                        Bolt.bintablelist.Add(test_name);
                        MakeFlowShhet_sub(ate_data, i);
                        continue;
                    }


                    else if (opcode_name == "CALL")

                    {
                        flow_name = ate_data[i, 8]?.ToString();
                        SelectWorksheet("temp", flow_name);
                        ReadRange("temp");
                        CopyToArray("temp");

                        for (int k = 1; k <= temp_data?.GetLength(0); k++)
                        {
                            string temp_job_name = temp_data[k, 4]?.ToString().ToUpper();
                            string temp_part_name = temp_data[k, 5]?.ToString().ToUpper();
                            string temp_env_name = temp_data[k, 6]?.ToString().ToUpper();
                            string temp_opcode_name = temp_data[k, 7]?.ToString().ToUpper();
                            string temp_test_name = temp_data[k, 8]?.ToString().ToUpper();
                            string temp_lolimit = temp_data[k, 11]?.ToString().ToUpper();
                            string temp_hilimit = temp_data[k, 12]?.ToString().ToUpper();

                            if (temp_job_name == "SKIP" || temp_part_name == "SKIP" || temp_env_name == "SKIP")
                            {
                                continue;
                            }


                            else if (opcode_name == "SET-DEVICE")
                            {
                                //string opcode_flag = ate_data[w, 7]?.ToString();
                                MakeFlowShhet_sub(temp_data, k);
                                continue;
                            }

                            else if (temp_data[k, 7]?.ToString() == "flag-false-all" || temp_data[k, 7]?.ToString() == "assign-site-var")                            {
                                //string opcode_flag = ate_data[w, 7]?.ToString();
                                MakeFlowShhet_sub(temp_data, k);
                                continue;
                            }

                            else if (temp_opcode_name == "TEST" && temp_test_name == "FLAG_CHECK")
                            {
                                MakeFlowShhet_sub_flag(temp_data, k);
                                MakeFlowShhet_sub(temp_data, k);
                                
                                
                            }

                            //else if (temp_opcode_name == "USE-LIMIT" && (temp_lolimit == "0" || temp_lolimit == "" || temp_lolimit == null) && (temp_hilimit == "0" || temp_hilimit == "" || temp_hilimit == null))
                            else if (temp_opcode_name == "USE-LIMIT" )
                            {
                                MakeFlowShhet_sub_flag(temp_data, k);
                                MakeFlowShhet_sub(temp_data, k);
                                continue;
                            }

                            else if (temp_opcode_name == "BINTABLE")
                            {
                                MakeFlowShhet_sub(temp_data, k);
                                continue;
                            }



                            //else if (temp_data[k, 3]?.ToString() == "SCAN" && temp_data[k, 7]?.ToString() == "Test")
                            else if (temp_opcode_name == "TEST" && temp_test_name != "FLAG_CHECK")
                            {
                                MakeFlowShhet_sub(temp_data, k);
                                

                            }

                        }

                        job = "";
                        continue;


                    }

                    if (job_name == "SKIP" || part_name == "SKIP" || env_name == "SKIP")
                    {
                        continue;
                    }

                    else if (i > assign_flag_end_point && (ate_data[i, 7]?.ToString() == "flag-false-all" || ate_data[i, 7]?.ToString() == "assign-site-var"))
                    {
                        //string opcode_flag = ate_data[w, 7]?.ToString();
                        MakeFlowShhet_sub(ate_data, i);
                        continue;
                    }


                    else if (opcode_name == "SET-DEVICE")
                    {
                        //string opcode_flag = ate_data[w, 7]?.ToString();
                        MakeFlowShhet_sub(ate_data, i);
                        continue;
                    }

                    else if (opcode_name == "TEST" && test_name == "FLAG_CHECK")
                    {
                        MakeFlowShhet_sub_flag(ate_data, i);
                        MakeFlowShhet_sub(ate_data, i);
                        continue;
                    }

                    //else if (opcode_name == "USE-LIMIT" && (lolimit == "0" || lolimit == "" || lolimit == null) && (hilimit == "0" || hilimit == "" || hilimit == null))
                    else if (opcode_name == "USE-LIMIT" )
                    {
                        MakeFlowShhet_sub_flag(ate_data, i);
                        MakeFlowShhet_sub(ate_data, i);
                        continue;
                    }

                    else if (opcode_name == "BINTABLE")
                    {
                        MakeFlowShhet_sub(ate_data, i);
                        continue;
                    }

                    else if ((job_name == "COMP" || job_name == "SCAN" || job_name == "OTP" || job_name == "ETC" ) && opcode_name == "TEST")

                    {
                        flow_name = "Flow_Table";
                        MakeFlowShhet_sub(ate_data, i);
                        

                    }
                }

            }

            sitevarnot0.Close();

            //ptop_flow_range = ptop_ss.UsedRange;

            //ptop_flow_data = new object[5000, 200];
            //ptop_flow_data = ptop_write_data;


            //MakeFlag(ate_data, "flag_list");
            //MakeSitevar(ate_data, "var_list");

            //MakeFlagSave("flag_list");
            //MakeSitevarSave("var_list");

            //MessageBox.Show("완료");




        }


        public DateTime Delay(int MS)
        {
            DateTime ThisMoment = DateTime.Now;
            TimeSpan duration = new TimeSpan(0, 0, 0, 0, MS);
            DateTime AfterWards = ThisMoment.Add(duration);

            while (AfterWards >= ThisMoment)
            {
                System.Windows.Forms.Application.DoEvents();
                ThisMoment = DateTime.Now;
            }

            return DateTime.Now;
        }






        public void PotopSheetInit(object[,] ate_data)
        {
            //init_data

            //ptop_write_data = new object[5000, 200];
            //ptop_temp_write_data = new object[5000, 200];

            ptop_write_data[1, 1] = ate_data[1, 1];
            for (int z = 1; z < ate_data.GetLength(1); z++)
            {
                ptop_write_data[3, z+1] = ate_data[3, z + 1];
                ptop_write_data[4, z+1] = ate_data[4, z + 1];
            }
        }

        public void MakeFlowShhet_sub(object[,] ate_data, int i)
        {
            string temp;
            string temp_val;
            j++;
            ptop_write_data[j + 4, 1] = flow_name;
            //test_name.Add(ate_data[i, 8].ToString());

            for (int k = 1; k < ate_data.GetLength(1); k++)
            {
                ptop_write_data[j + 4, k+1] = ate_data[i, k+1]?.ToString();

                if (k >= 3 && ate_data[i, k - 1]?.ToString() == "flag-true")
                {
                    ptop_write_data[j + 4, k] = ate_data[i, k]?.ToString();
                }

                else if (k >= 3 && ate_data[i, k - 1]?.ToString() == "site-var=")
                {

                    temp = ate_data[i, k]?.ToString();
                    int index = temp.IndexOf(" ");
                    temp = temp.Replace(" ", "");
                    temp_val = temp.Substring(index);
                    temp = temp.Substring(0, index);

                    ptop_write_data[j + 4, k] = temp;
                    ptop_write_data[j + 4, k+1] = temp_val;
                }
            }

            string temp2 = ate_data[i, 4]?.ToString();

            if (job != "" && temp2 == null)
            {
                ptop_write_data[j + 4, 4] = job;
            }
        }

        List<string> multiinstance = new List<string>();


        public void MakeFlowShhet_sub(object[,] ate_data, int i, string instance)
        {
            string temp;
            string temp_val;

            int multiinstancecheck = 1;

            j++;
            ptop_write_data[j + 4, 1] = flow_name;
            //test_name.Add(ate_data[i, 8].ToString());

            for (int k = 1; k < ate_data.GetLength(1); k++)
            {
                ptop_write_data[j + 4, k+1] = ate_data[i, k + 1]?.ToString();

                if (k >= 3 && ate_data[i, k - 1]?.ToString() == "flag-true")
                {
                    ptop_write_data[j + 4, k] = ate_data[i, k]?.ToString();
                }

                else if (k >= 3 && ate_data[i, k - 1]?.ToString() == "site-var=")
                {
                    temp = ate_data[i, k]?.ToString();
                    int index = temp.IndexOf(" ");
                    temp = temp.Replace(" ", "");
                    temp_val = temp.Substring(index);
                    temp = temp.Substring(0, index);

                    ptop_write_data[j + 4, k] = temp;
                    ptop_write_data[j + 4, k+1] = temp_val;
                }
            }


            if(instance == "instance") 
            {
                //if(i != 1 && ptop_ss.Cells[j + 4, 2] == ptop_ss.Cells[j + 3, 2])

                string temp1 = ate_data[i, 2]?.ToString();
                string temp5 = ate_data[i - 1, 2]?.ToString();

                if (i != 1 && ate_data[i, 2]?.ToString() == ate_data[i-1, 2]?.ToString())
                {
                    multiinstancecheck++;
                    //j++;
                    //ptop_ss.Cells[j + 4, 1] = flow_name;

                    for (int k = 1; k < ate_data.GetLength(1); k++)
                    {
                        string temp7 = ate_data[i, k + 1]?.ToString();
                        string temp8 = ate_data[i, k + 1]?.ToString();
                        string temp9 = ate_data[i - 1, k + 1]?.ToString();


                        if (ate_data[i, k+1]?.ToString() == null || ate_data[i, k + 1]?.ToString() == "")
                             //&& (ate_data[i, k + 1]?.ToString() != ate_data[i - 1, k + 1]?.ToString())
                        {
                            ptop_write_data[j + 4, k+1] = ate_data[i - 1, k + 1]?.ToString();
                            ate_data[i, k + 1] = ate_data[i - 1, k + 1];

                            //if (k >= 3 && ate_data[i - 1, k - 1]?.ToString() == "flag-true")
                            //{
                            //    ptop_ss.Cells[j + 4, k] = ate_data[i - 1, k]?.ToString();
                            //}

                            //else if (k >= 3 && ate_data[i - 1, k - 1]?.ToString() == "site-var=")
                            //{
                            //    temp = ate_data[i - 1, k]?.ToString();
                            //    temp_val = temp.Substring(temp.Length - 1);
                            //    temp = temp.Replace(" ", "");
                            //    temp = temp.Substring(0, temp.Length - 1);

                            //    ptop_ss.Cells[j + 4, k] = temp;
                            //    ptop_ss.Cells[j + 4, k + 1] = temp_val;
                            //}
                        }
                    }
                }

            }



            string temp2 = ate_data[i, 4]?.ToString();

            if (job != "" && temp2 == null)
            {
                ptop_write_data[j + 4, 4] = job;
            }




        }




        public void MakeFlowShhet_sub_flag(object[,] ate_data, int i)
        {
            string temp;
            string temp_val;
            flag_j++;
            ptop_temp_write_data[flag_j + 4, 1] = flow_name;
            //test_name.Add(ate_data[i, 8].ToString());

            for (int k = 1; k < ate_data.GetLength(1); k++)
            {
                ptop_temp_write_data[flag_j + 4, k+1] = ate_data[i, k + 1]?.ToString();



                if (k >= 3 && ate_data[i, k - 1]?.ToString() == "flag-true")
                {
                    ptop_temp_write_data[flag_j + 4, k ] = ate_data[i, k ]?.ToString();
                }


                else if (k >=3 && ate_data[i, k - 1]?.ToString() == "site-var=")
                {

                    temp = ate_data[i, k]?.ToString();
                    int index = temp.IndexOf(" ");
                    temp = temp.Replace(" ", "");
                    temp_val = temp.Substring(index);
                    temp = temp.Substring(0, index);

                    ptop_temp_write_data[flag_j + 4, k] = temp;
                    ptop_temp_write_data[flag_j + 4, k+1 ] = temp_val;

                }
            }

        }



        public void SaveAs(string path)
        {
            //app.DisplayAlerts = false;
             ptop_bb.SaveAs(Filename: path, Type.Missing, Type.Missing, Type.Missing, Type.Missing, Type.Missing, Excel.XlSaveAsAccessMode.xlNoChange, Type.Missing, Type.Missing, Type.Missing,
            Type.Missing, Type.Missing);
            //ptop_bb.SaveAs(Filename: path);
              

        }


        public void Save()
        {
            //app.DisplayAlerts = false;
            ate_bb.Save();
        }



 }
}
