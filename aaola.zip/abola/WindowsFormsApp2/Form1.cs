﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.Office.Interop.Excel;
using Excel = Microsoft.Office.Interop.Excel;
using Font = System.Drawing.Font;
using System.Timers;

namespace abola
{
    //**************************************************
                //@Created on 2019. 08.23
                //@author: hojun kim
    //**************************************************

    public partial class Form1 : Form
    {

        public string flow_table = "Flow Table";
        public string test_instance = "Test Instances";
        //public string rootsavepath = "D:\\PERSONAL_SPACE\\BOLT\\";
        //public string rootsavepath;

        public Form1()
        {
            InitializeComponent();
        }

        public Form1(string var)
        {

        }


        private void Form1_Load(object sender, EventArgs e)
        {


            label1.Text = "made by hojun kim";

            Bolt bolt = new Bolt();
            Bolt.app = new Excel.Application();



            //string rootpath = Bolt.bolt_open_path;

            //if (rootpath != "")
            //{
            //    int temp = rootpath.LastIndexOf("\\");
            //    string tempstr = rootpath.Substring(0, temp);
            //    rootsavepath = tempstr;
            //}
            //else
            //{
            //    rootsavepath = "\\";
            //}


            bolt.checkfile("");
            textBox1.Text = Bolt.ate_open_path;
            textBox2.Text = Bolt.bolt_save_path;
            textBox3.Text = Bolt.bolt_open_path;

            bolt.rootsavepathdir();

            //bolt.Close();

            FormClosing += new System.Windows.Forms.FormClosingEventHandler(bolt.Form_FormClosing);

            //FormClosed += new FormClosedEventHandler(bolt.closing, "a");





        }

        //void timer_Tick(object sender, EventArgs e)
        //{
        //    // UI 쓰레드에서 실행. 
        //    // UI 컨트롤 직접 엑세스 가능
        //    //label1.Text = DateTime.Now.ToLongTimeString();

        //    richTextBox1.Text += ".";
        //}

        public void Flow_BTN(object sender, EventArgs e)
        {
            //string filename = @rootsavepath + "X9825H1011.xls";
            string filename = Bolt.ate_open_path;
            Bolt bolt = new Bolt();

            if (Bolt.ate_open_path != "")
            {
                int temp = Bolt.ate_open_path.LastIndexOf("\\");
                string tempstr = Bolt.ate_open_path.Substring(temp + 1, Bolt.ate_open_path.Length - temp - 1);
                richTextBox1.Text += tempstr + "   ->  loading... ";
            }


            //System.Timers.Timer timer = new System.Timers.Timer();
            //timer.Interval = 1000; // 1초
            //timer.Elapsed += new ElapsedEventHandler(timer_Tick);
            ////timer.Tick += new EventHandler(timer_Tick);
            //timer.Start();



            //richTextBox1.Text += filename + "  loading ... ";
            bolt.ReadExcel(out bolt.ate_bb, filename);

            //timer.Stop();

            string jobsheetname_1 = "Job";
            string jobsheetname_2 = "Jobs";
            Excel.Worksheet job_sheet;
            int job_choice = 0;

            try
            {
                job_sheet = bolt.ate_bb.Worksheets[jobsheetname_1];
                job_choice = 1;
            }
            catch (Exception ex)
            {
                job_sheet = bolt.ate_bb.Worksheets[jobsheetname_2];
                job_choice = 2;
            }

            Excel.Range job_sheet_range;
            job_sheet_range = job_sheet.UsedRange;
            object[,] jot_sheet_value = job_sheet_range.Value2;



            richTextBox1.Text += "done";
            richTextBox1.Text += Environment.NewLine;




            if (Bolt.bolt_save_path != "")
            {
                int temp = Bolt.bolt_save_path.LastIndexOf("\\");
                string tempstr = Bolt.bolt_save_path.Substring(temp + 1, Bolt.bolt_save_path.Length - temp - 1);
                richTextBox1.Text += tempstr + "   ->  making... ";
            }




            bolt.CreatNewFile(out bolt.ptop_bb);
            bolt.SelectWorksheet(bolt.ptop_bb, out bolt.init_ss, "Sheet1");
            bolt.ReadRange(bolt.init_ss, out bolt.init_range, "A1:B1");
            bolt.RangeResize(ref bolt.init_range, 10000, 200);
            bolt.CopyToArray(bolt.init_range, out bolt.ptop_write_data);
            bolt.CopyToArray(bolt.init_range, out bolt.ptop_temp_write_data);

            bolt.CreatNewSheet(bolt.ptop_bb, out bolt.ptop_ss, "ptop_flow_table");
            bolt.CreatNewSheet(bolt.ptop_bb, out bolt.ptop_ss_temp, "bin_define");
            bolt.CreatNewSheet(bolt.ptop_bb, out bolt.ptop_ss_temp, "flag_check");
                       
            bolt.SelectWorksheet(bolt.ate_bb, out bolt.ate_ss, "Flow ATable");
            bolt.ReadRange(bolt.ate_ss, out bolt.ate_range);
            bolt.CopyToArray(bolt.ate_range, out bolt.ate_data);

            bolt.MakeFlowSheet();
            bolt.CopyToCell(bolt.ptop_ss, bolt.ptop_write_data, out bolt.ptop_flow_data);
            bolt.CopyToCell(bolt.ptop_ss_temp, bolt.ptop_temp_write_data);

            bolt.CreatNewSheet(bolt.ptop_bb, out bolt.ptop_ss, "ptop_test_instance", "ptop_flow_table");
            bolt.SelectWorksheet(bolt.ate_bb, out bolt.ate_ss, "Test Instances");
            bolt.ReadRange(bolt.ate_ss, out bolt.ate_range);
            bolt.CopyToArray(bolt.ate_range, out bolt.ate_data);

            bolt.SelectWorksheet(bolt.ptop_bb, out bolt.init_ss, "Sheet1");
            bolt.ReadRange(bolt.init_ss, out bolt.init_range, "A1:B1");
            bolt.RangeResize(ref bolt.init_range, 20000, 300);
            bolt.CopyToArray(bolt.init_range, out bolt.ptop_write_data);
            bolt.RangeResize(ref bolt.init_range, 7000, 200);
            bolt.CopyToArray(bolt.init_range, out bolt.ptop_instance_data);


            bolt.MakeInstanceSheet();
            bolt.CopyToCell(bolt.ptop_ss, bolt.ptop_write_data, out bolt.ptop_instance_data);


            bolt.SelectWorksheet(bolt.ptop_bb, out bolt.init_ss, "Sheet1");
            bolt.ReadRange(bolt.init_ss, out bolt.init_range, "A1:B1");
            bolt.RangeResize(ref bolt.init_range, 20000, 300);
            bolt.CopyToArray(bolt.init_range, out bolt.ptop_write_data);
            bolt.RangeResize(ref bolt.init_range, 7000, 200);
            bolt.CopyToArray(bolt.init_range, out bolt.ptop_summary_data);
                     
            
            bolt.CreatNewSheet(bolt.ptop_bb, out bolt.ptop_ss, "summary_table_2");
            bolt.MakesummaryTable("");
            bolt.CopyToCell(bolt.ptop_ss, bolt.ptop_write_data, out bolt.ptop_summary_data);
            

            bolt.SelectWorksheet(bolt.ptop_bb, out bolt.init_ss, "Sheet1");
            bolt.ReadRange(bolt.init_ss, out bolt.init_range, "A1:B1");
            bolt.RangeResize(ref bolt.init_range, 20000, 300);
            bolt.CopyToArray(bolt.init_range, out bolt.ptop_write_data);


            bolt.CreatNewSheet(bolt.ptop_bb, out bolt.ptop_ss, "summary_table");
            bolt.MakesummaryTable("normal");
            bolt.CopyToCell(bolt.ptop_ss, bolt.ptop_write_data);


            string pinmap;
            string global_spec;
            string ac_spec;
            string dc_spec;
            string bintable;
            string pattern_set;

            pinmap = jot_sheet_value[5, 3].ToString();
            ac_spec = jot_sheet_value[5, 6].ToString();
            dc_spec = jot_sheet_value[5, 7].ToString();
            bintable = jot_sheet_value[5, 10].ToString();
            Bolt.pattern_set = jot_sheet_value[5, 8]?.ToString();

            string jobsheetnamefinal="";

            if (job_choice == 1) { jobsheetnamefinal = jobsheetname_1; }
            else if (job_choice == 2) { jobsheetnamefinal = jobsheetname_2; }
            bolt.SheetCopy(bolt.ate_bb, bolt.ptop_bb, jobsheetnamefinal);
            job_choice = 0;

            bolt.SheetCopy(bolt.ate_bb, bolt.ptop_bb, "PTOP_DC_SPEC");
            bolt.SheetCopy(bolt.ate_bb, bolt.ptop_bb, pinmap);
            bolt.SheetCopy(bolt.ate_bb, bolt.ptop_bb, "Global Specs");
            bolt.SheetCopy(bolt.ate_bb, bolt.ptop_bb, ac_spec);
            bolt.SheetCopy(bolt.ate_bb, bolt.ptop_bb, dc_spec);

            int tempcnt = Bolt.bintablelist.Count;

            for (int i = 0; i < tempcnt; i++)
            {
                bolt.SheetCopy(bolt.ate_bb, bolt.ptop_bb, Bolt.bintablelist[i]);
            }
            Bolt.bintablelist.Clear();

            bolt.SheetCopy(bolt.ate_bb, bolt.ptop_bb, bintable);
            //bolt.SheetCopy(bolt.ate_bb, bolt.ptop_bb, "DVFS_TABLE_BJM");
            if (Bolt.pattern_set != null) { bolt.SheetCopy(bolt.ate_bb, bolt.ptop_bb, Bolt.pattern_set); }
            if (Bolt.pattern_set == null)
            {
                Bolt.pattern_set = "PATSET";
                bolt.CreatNewSheet(bolt.ptop_bb, out bolt.temp_ss2, Bolt.pattern_set);
                bolt.SelectWorksheet(bolt.ptop_bb, out bolt.temp_ss2, Bolt.pattern_set);

                for (int i = 1; i <= 10; i++)
                {
                    for (int j = 1; j <= 9; j++)
                    {
                        bolt.temp_ss2.Cells[i, j] = " ";
                    }
                }

                bolt.SelectWorksheet(bolt.ptop_bb, out bolt.ptop_job_ss, jobsheetnamefinal);
                bolt.ptop_job_ss.Cells[5, 8] = Bolt.pattern_set;

            }



            bolt.instance_list = bolt.ListSingle(bolt.ptop_instance_data, 10); // instance : 10 = dc sheet
            bolt.UsedSeheetCopy(bolt.instance_list);

            bolt.instance_list = bolt.ListSingle(bolt.ptop_instance_data, 12); // instance : 12 = level sheet
            bolt.UsedSeheetCopy(bolt.instance_list);

            bolt.Delay(1000);


            bolt.SelectWorksheet(bolt.ptop_bb, out bolt.ptop_ss, "summary_table_2");
            bolt.ptop_ss.Activate();

            bolt.Delay(1000);

            bolt.SaveAs(Bolt.bolt_save_path);
            bolt.Close();

            richTextBox1.Text += "done";
            richTextBox1.Text += Environment.NewLine;

            //bolt.app.Quit();

            //Marshal.ReleaseComObject(bolt.app);

            if (bolt.sitevarcnt > 0)
            {
                MessageBox.Show("assign-site-var 에 0 이 아닌 값이 존재", "종료", MessageBoxButtons.OK);
            }

            MessageBox.Show("완료");

        }

        private void Button2_Click(object sender, EventArgs e)
        {
            ////bolt.SaveAs(@"D:\PERSONAL_SPACE\0_ptop\VSTO\ptop_excel_1.xlsx");
            //bolt.CreatNewSheet("ptop_test_instance");
            //bolt.SelectWorksheet(test_instance);
            //bolt.ReadRange();
            //bolt.CopyToArray();
            //bolt.MakeInstanceSheet();

            //bolt.SaveAs(@"D:\PERSONAL_SPACE\0_ptop\VSTO\ptop_excel_2.xlsx");
            //bolt.Close();

        }

        private void Close_BTN(object sender, EventArgs e)
        {
            Bolt bolt = new Bolt();
            bolt.Close();

            MessageBox.Show("완료");
        }


        private void Flow_C_BTN(object sender, EventArgs e)
        {
            Bolt bolt = new Bolt();
            //string savepath = @rootsavepath + "ptop_excel_2.xlsx";

            string savepath = Bolt.bolt_open_path;
            bolt.openfile(savepath);

            string jobsheetname_1 = "Job";
            string jobsheetname_2 = "Jobs";
            Excel.Worksheet job_sheet;
            int job_choice = 0;

            try
            {
                job_sheet = bolt.ate_bb.Worksheets[jobsheetname_1];
                job_choice = 1;
            }
            catch (Exception ex)
            {
                job_sheet = bolt.ate_bb.Worksheets[jobsheetname_2];
                job_choice = 2;
            }

            Excel.Range job_sheet_range;
            job_sheet_range = job_sheet.UsedRange;
            object[,] jot_sheet_value = job_sheet_range.Value2;
            Bolt.bintablenamepublic = jot_sheet_value[5, 10]?.ToString().ToUpper();


            bolt.SelectWorksheet(out bolt.bin_table_sheet, Bolt.bintablenamepublic);
            bolt.ReadRange(out bolt.bin_table_rage, bolt.bin_table_sheet);
            bolt.CopyToArray(out bolt.bin_table_object, bolt.bin_table_rage);

            bolt.SelectWorksheet("summary_table_2");
            bolt.ReadRange();
            bolt.CopyToArray();
            bolt.MakeFlow_Txt();
            
            bolt.Close();

            MessageBox.Show("완료");

        }

        private void Power_C_BTN(object sender, EventArgs e)
        {
            
            //string savepath = @rootsavepath + "ptop_excel_2.xlsx";
            Bolt bolt = new Bolt();

            string savepath = Bolt.bolt_open_path;
            bolt.openfile(savepath);

            //Bolt bolt = new Bolt();
            bolt.SelectWorksheet("summary_table_2");
            bolt.ReadRange();
            bolt.CopyToArray();
            bolt.MakePower_Txt();

            bolt.Close();

            MessageBox.Show("완료");

        }

        private void Timming_C_BTN(object sender, EventArgs e)
        {
            //string savepath = @rootsavepath + "ptop_excel_2.xlsx";
            Bolt bolt = new Bolt();

            string savepath = Bolt.bolt_open_path;
            bolt.openfile(savepath);

            //Bolt bolt = new Bolt();
            bolt.SelectWorksheet("summary_table_2");
            bolt.ReadRange();
            bolt.CopyToArray();
            bolt.MakeTimming_TXT();

            bolt.Close();

            MessageBox.Show("완료");
        }

        private void Bin_Define_BTN(object sender, EventArgs e) //bin define
        {
            


            //string savepath = @rootsavepath + "ptop_excel_2.xlsx";
            Bolt bolt = new Bolt();
            //Bolt bolt = new Bolt();

            string savepath = Bolt.bolt_open_path;
            bolt.openfile(savepath);


            //bolt.CreatNewSheet_par("bin_define", "flag_check");

            bolt.SelectWorksheet("summary_table");
            bolt.ReadRange();
            bolt.CopyToArray();
            bolt.CopyObjectSummary();

            bolt.SelectWorksheet("BIN_TABLE");
            bolt.ReadRange();
            bolt.CopyToArray();
            bolt.CopyObjectBintable();

            bolt.SelectWorksheet("flag_check");
            bolt.ReadRange();
            bolt.CopyToArray();
            bolt.CopyObjectFlagcheck();


            bolt.SelectWorksheet("summary_table");
            bolt.ate_ss.Activate();

            bolt.MakeBinDefine();


            //Bolt.app.DisplayAlerts = true;
            bolt.Save();
            bolt.Close();

            MessageBox.Show("완료");



        }



        private void MadeByLabel(object sender, EventArgs e)
        {

        }

        private void Flag_Var_BTN(object sender, EventArgs e)
        {
            //string savepath = @rootsavepath + "X9825H1011.xls";

            Bolt bolt = new Bolt();

            string savepath = Bolt.ate_open_path;
            bolt.openfile(savepath);

            bolt.getflag(bolt.ate_bb);

            bolt.Close();
            MessageBox.Show("완료");

        }

        private void ATE_EXCEL_OPEN(object sender, EventArgs e)
        {
            Bolt bolt = new Bolt();
            bolt.atefileopen();
            if (bolt.ate_open_file_path != "")
            {
                textBox1.Text = bolt.ate_open_file_path;
            }


        }

        private void ATE_OPEN_TEXT(object sender, EventArgs e)
        {

        }


        private void OpenFileDialog1_FileOk(object sender, CancelEventArgs e)
        {

        }

        private void BOLT_SAVE_TEXT(object sender, EventArgs e)
        {

        }

        private void BOLT_EXCEL_SAVE(object sender, EventArgs e)
        {
            Bolt bolt = new Bolt();
            bolt.boltfilesave();
            if (bolt.bolt_save_file_path != "")
            {
                textBox2.Text = bolt.bolt_save_file_path;
                textBox3.Text = bolt.bolt_save_file_path;
                bolt.rootsavepathdir();
            }
        }

        public void TextBox3_TextChanged(object sender, EventArgs e)
        {

        }

        private void Button7_Click(object sender, EventArgs e)
        {
            Bolt bolt = new Bolt();
            bolt.boltfileopen();
            if (bolt.bolt_open_file_path != "")
            {
                textBox3.Text = bolt.bolt_open_file_path;
                bolt.rootsavepathdir();
            }
        }

        private void GroupBox1_Enter(object sender, EventArgs e)
        {

        }

        private void RichTextBox1_TextChanged(object sender, EventArgs e)
        {
            richTextBox1.SelectionStart = richTextBox1.Text.Length;
            richTextBox1.ScrollToCaret();
            //richTextBox1.Font = new Font(richTextBox1.SelectionFont.FontFamily, 15);
            if (richTextBox1.Lines.Length > 1000)
            {
                richTextBox1.Clear();
            }
        }

        private void Button10_Click(object sender, EventArgs e)
        {
            //string savepath = @rootsavepath + "ptop_excel_2.xlsx";
            Bolt bolt = new Bolt();

            string savepath = Bolt.bolt_open_path;
            bolt.openfile(savepath);


            string jobsheetname_1 = "Job";
            string jobsheetname_2 = "Jobs";
            Excel.Worksheet job_sheet;
            int job_choice = 0;

            try
            {
                job_sheet = bolt.ate_bb.Worksheets[jobsheetname_1];
                job_choice = 1;
            }
            catch (Exception ex)
            {
                job_sheet = bolt.ate_bb.Worksheets[jobsheetname_2];
                job_choice = 2;
            }

            Excel.Range job_sheet_range;
            job_sheet_range = job_sheet.UsedRange;
            object[,] jot_sheet_value = job_sheet_range.Value2;
            string pinmap = jot_sheet_value[5, 3].ToString();


            //Bolt bolt = new Bolt();
            bolt.SelectWorksheet(pinmap);
            bolt.ReadRange();
            bolt.CopyToArray();

            bolt.Make_Pingroup_TXT();

            bolt.Close();

            MessageBox.Show("완료");
        }

        private void Button12_Click(object sender, EventArgs e)
        {

            Bolt bolt = new Bolt();
            //string savepath = @rootsavepath + "ptop_excel_2.xlsx";

            string savepath = Bolt.bolt_open_path;
            bolt.openfile(savepath);

            string jobsheetname_1 = "Job";
            string jobsheetname_2 = "Jobs";
            Excel.Worksheet job_sheet;
            int job_choice = 0;

            try
            {
                job_sheet = bolt.ate_bb.Worksheets[jobsheetname_1];
                job_choice = 1;
            }
            catch (Exception ex)
            {
                job_sheet = bolt.ate_bb.Worksheets[jobsheetname_2];
                job_choice = 2;
            }

            Excel.Range job_sheet_range;
            job_sheet_range = job_sheet.UsedRange;
            object[,] jot_sheet_value = job_sheet_range.Value2;
            Bolt.bintablenamepublic = jot_sheet_value[5, 10]?.ToString().ToUpper();


            bolt.SelectWorksheet(out bolt.bin_table_sheet, Bolt.bintablenamepublic);
            bolt.ReadRange(out bolt.bin_table_rage, bolt.bin_table_sheet);
            bolt.CopyToArray(out bolt.bin_table_object, bolt.bin_table_rage);

            bolt.SelectWorksheet("summary_table_2");
            bolt.ReadRange();
            bolt.CopyToArray();
            bolt.MakeFlow_Txt("timing");

            bolt.Close();

            MessageBox.Show("완료");

        }

        
    }
}
