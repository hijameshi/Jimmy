﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Runtime.InteropServices;
using Microsoft.Office.Interop.Excel;
using Excel = Microsoft.Office.Interop.Excel;
using System.Text.RegularExpressions;
using System.IO;

namespace abola
{
    partial class Bolt
    {
        string[,] power;
        List<string> power_list = new List<string>();
        List<string> power_list_name = new List<string>();
        string power_onerow;
        object[,] ptop_power;
        object[,] level_data;
        object[,] dc_data;
        object[,] level_data_fomula;
        public string dc_spec_name;

        public Form1 form1 = new Form1("temp");

        //string IO18;
        //string IO12;

        //int check = 0;

        //string[] listtoarray;

        string ptop_sheet_name;
        Range ptop_power_range;
        Range level_range;
        Range dc_range;

        

        //string level_value;

        string power_onerow_name;

        string level;
        string category;
        string selector;

        //string pwr;

        static int power_number = 64;

        string[,] ptop_power_data = new string[power_number, 5];

        string temp;


        string IO18 = "DC_18IO";
        string IO12 = "DC_12IO";

        string IO18_2020 = "IO_18";
        string IO12_2020 = "PLLDDRBIGMIPI_12";


        Worksheet ptop_power_sheet;
        Worksheet level_sheet;
        Worksheet dc_sheet;

        
        public void MakePower_Txt()
        {
            ptop_sheet_name = "PTOP_DC_SPEC";
            //string dc_name = "DC_Spec";
            getptopPower(ptop_sheet_name);

            power = new string[ate_data.GetLength(0) - 4, 3];


            string[] ptop_power_name = new string[power_number];


            string jobsheetname_1 = "Job";
            string jobsheetname_2 = "Jobs";
            Excel.Worksheet job_sheet;
            int job_choice = 0;

            try
            {
                job_sheet = ate_bb.Worksheets[jobsheetname_1];
                job_choice = 1;
            }
            catch (Exception ex)
            {
                job_sheet = ate_bb.Worksheets[jobsheetname_2];
                job_choice = 2;
            }

            Excel.Range job_sheet_range;
            job_sheet_range = job_sheet.UsedRange;
            object[,] jot_sheet_value = job_sheet_range.Value2;

            string dc_spec_name = jot_sheet_value[5, 7]?.ToString().ToUpper();
            //bintablenamepublic = jot_sheet_value[5, 10]?.ToString().ToUpper();




            getDCsheet(dc_spec_name);

            for (int i = 1; i <= power_number; i++)
            {
                getptopPower(ptop_sheet_name);
                ptop_power_data[i - 1, 0] = ptop_power[i, 1].ToString();
            }

            for (int i = 1; i <= ate_data.GetLength(0) - 4; i++)
            {
                if (ate_data[i + 4, 45]?.ToString()!=null)
                {

                    power[i - 1, 0] = ate_data[i + 4, 45].ToString(); //Level_DEF_SCAN
                    power[i - 1, 1] = ate_data[i + 4, 39].ToString(); //VDD_SCAN
                    power[i - 1, 2] = ate_data[i + 4, 40].ToString(); //Sel1

                    level = power[i - 1, 0];
                    category = power[i - 1, 1];
                    selector = power[i - 1, 2];

                    power_onerow = level + "__" + category + "__" + selector;
                    power_onerow_name = level + "_" + category + "_" + selector;

                    power_list.Add(power_onerow);
                    power_list_name.Add(power_onerow_name);
                }
            }

            power_list = power_list.Distinct().ToList();
            power_list_name = power_list_name.Distinct().ToList();

            for (int x = 1; x <= power_list.Count; x++)
            {

                string[] listtoarray = new string[3];
                string list_split;
                list_split = power_list[x - 1].ToString();
                listtoarray = list_split.Split(new string[] { "__" }, StringSplitOptions.None);

                level = listtoarray[0];
                category = listtoarray[1];
                selector = listtoarray[2];

                string power_list2 = level + '_' + category + "_" + selector;

                getLvlsheet(level);


                for (int i = 1; i <= power_number; i++)
                //if (!power_list.Contains(power_onerow))
                {



                    //ptop_power_data[i - 1, 0] = ptop_power[i, 1].ToString();
                    //pwr = ptop_power_data[i - 1, 0];

                    for (int j = 1; j <= level_data.GetLength(0); j++)
                    {
                        //if (level_data[j, 2]?.ToString().IndexOf(ptop_power_data[i - 1, 0]) >= 0 && (level_data[j, 4]?.ToString() == "VMain" || level_data[j, 4]?.ToString() == "Vps"))
                        if (level_data[j, 2]?.ToString().ToUpper() == ptop_power_data[i - 1, 0]?.ToString().ToUpper() && (level_data[j, 4]?.ToString() == "VMain" || level_data[j, 4]?.ToString() == "Vps"))
                        {
                            ptop_power_data[i - 1, 1] = level_data[j, 4]?.ToString(); //2번째에 VMain, Vps
                            temp = level_data_fomula[j, 5]?.ToString();

                            MatchCollection matches = Regex.Matches(temp, "=_");
                            int cnt = matches.Count;

                            if (cnt >= 1)
                            {
                                temp = temp.Replace("=_", "");
                                ptop_power_data[i - 1, 3] = temp; //4번째에 power 이름 =_DC2348
                            }

                            //if (temp.Count("=")>=0)
                            //{

                            //}
                            else
                            {
                                temp = level_data[j, 5]?.ToString();
                                //temp = temp.Replace("=", "");
                                //int inttemp = Convert.ToInt32(temp);
                                ptop_power_data[i - 1, 2] = temp;
                                ptop_power_data[i - 1, 4] = "constance";
                                continue;
                            }

                        }
                    }


                    //for (int j = 1; j <= level_data.GetLength(0); j++)
                    //{
                    if (ptop_power_data[i - 1, 0] == IO18)
                    {
                        ptop_power_data[i - 1, 3] = IO18; //4번째에 power 이름 =_DC2348

                    }

                    else if (ptop_power_data[i - 1, 0] == IO18_2020)
                    {
                        ptop_power_data[i - 1, 3] = IO18_2020; //4번째에 power 이름 =_DC2348

                    }


                    if (ptop_power_data[i - 1, 0] == IO12)
                    {
                        ptop_power_data[i - 1, 3] = IO12; //4번째에 power 이름 =_DC2348


                        //ptop_power_data[i - 1, 1] = level_data[j, 4]?.ToString(); //2번째에 VMain, Vps
                        //temp = level_data_fomula[j, 5]?.ToString();

                        //MatchCollection matches = Regex.Matches(temp, "=_");
                        //int cnt = matches.Count;

                        //if (cnt >= 1)
                        //{
                        //    temp = temp.Replace("=_", "");
                        //    ptop_power_data[i - 1, 3] = temp; //4번째에 power 이름 =_DC2348
                        //}

                        ////if (temp.Count("=")>=0)
                        ////{

                        ////}
                        //else
                        //{
                        //    temp = level_data[j, 5]?.ToString();
                        //    //temp = temp.Replace("=", "");
                        //    //int inttemp = Convert.ToInt32(temp);
                        //    ptop_power_data[i - 1, 2] = temp;
                        //    ptop_power_data[i - 1, 4] = "constance";
                        //    continue;
                        //}
                    }

                    else if (ptop_power_data[i - 1, 0] == IO12_2020)
                    {
                        ptop_power_data[i - 1, 3] = IO12_2020; //4번째에 power 이름 =_DC2348
                    }


                    //}


                    //if (ptop_power_data[i - 1, 0] == "VDD_OPTION")
                    //{
                    //    ptop_power_data[i - 1, 3] = 0.ToString(); //4번째에 power 이름 =_DC2348

                    //}



                    for (int j = 1; j <= dc_data.GetLength(0); j++)
                    {
                        string a = dc_data[j, 2]?.ToString();
                        string b = dc_data[j, 4]?.ToString();
                        string c = ptop_power_data[i - 1, 3];


                        //if (b == null)
                        //{
                        //    ptop_power_data[i - 1, 2] = "";
                        //    continue;
                        //}

                        //int? aaa = dc_data[j, 2]?.ToString()?.IndexOf(ptop_power_data[i - 1, 3]);
                        //int? bbb = dc_data[j, 4]?.ToString()?.IndexOf(selector);

                        if (ptop_power_data[i - 1, 4] == "constance")
                        {
                            continue;
                        }

                        if (ptop_power_data[i - 1, 3] == null)
                        {
                            continue;
                        }




                        //else if (dc_data[j, 2]?.ToString()?.IndexOf(ptop_power_data[i - 1, 3]) >= 0 && dc_data[j, 4]?.ToString()?.IndexOf(selector) >= 0)
                        else if (dc_data[j, 2]?.ToString().ToUpper() == ptop_power_data[i - 1, 3]?.ToString().ToUpper() && dc_data[j, 4]?.ToString().ToUpper() == selector.ToUpper())
                        {
                            ptop_power_data[i - 1, 4] = dc_data[j, 5].ToString(); //5번째에 Typ, min, max
                            for (int w = 1; w <= dc_data.GetLength(1); w++)
                            {
                                if (dc_data[3, w]?.ToString().ToUpper() == category.ToUpper())
                                {
                                    int temp_category = 0;
                                    if (ptop_power_data[i - 1, 4] == "Typ")
                                    {
                                        temp_category = 0;
                                    }
                                    else if (ptop_power_data[i - 1, 4] == "Min")
                                    {
                                        temp_category = 1;
                                    }
                                    else if (ptop_power_data[i - 1, 4] == "Max")
                                    {
                                        temp_category = 2;
                                    }


                                    ptop_power_data[i - 1, 2] = dc_data[j, w + temp_category].ToString(); // power 값

                                }
                            }
                        }
                    }

                    if (ptop_power_data[i - 1, 2] == null)
                    {
                        ptop_power_data[i - 1, 1] = "VMain"; //4번째에 power 이름 =_DC2348
                        ptop_power_data[i - 1, 2] = "0"; //4번째에 power 이름 =_DC2348

                    }



                }
                //power_list.Add(power_onerow);


                MakePowerTxtFile(ptop_power_data, power_list2);


            }

            MakePowerNmaeFile(power_list_name, "power_list");
            MakePowerBatFile(power_list_name, "1_CompilePSET");


        }

        int temp_num = 0;

        public void MakePowerTxtFile(string[,] ptop_power_data, string power_list2)
        {

            DirectoryInfo dir = new DirectoryInfo(rootsavepath + "DAT\\Power\\");
            if (dir.Exists != true)
            {
                dir.Create();
            }


            string savePath = rootsavepath + "DAT\\Power\\" + power_list2 + ".dat";
            //string savePath = @form1.rootsavepath + "Power\\" + "PSET_" + power_list2 + ".dat";
            StreamWriter power_txt = new StreamWriter(new FileStream(savePath, FileMode.Create));



            for (int i = 0; i < power_number; i++)
            {

                //double aaa = Convert.ToDouble(ptop_power_data[i, 2]);
                //aaa = aaa * 1000000000000;
                //double number2 = Math.Round(aaa, 13);
                //number2 = number2 / 1000000000000;
                //string str = string.Format("{0:f4}", number2);
                //power_txt.Write(str + "\t");


                string temp0 = ptop_power_data[i, 0];
                string temp1 = ptop_power_data[i, 1];

                if (temp0 == IO18 || temp0 == IO12)
                {
                    temp_num++;
                    temp0 = "VDD_BV" + temp_num; //4번째에 power 이름 =_DC2348
                    temp1 = "VMain";

                }

                else if (temp0 == IO18_2020 || temp0 == IO12_2020)
                {
                    temp_num++;
                    temp0 = "VDD_BV" + temp_num; //4번째에 power 이름 =_DC2348
                    temp1 = "VMain";

                }



                power_txt.WriteLine("{0}\t{1}\t{2}\t{3}\t{4}\t",
                        temp0,
                        temp1,
                        ptop_power_data[i, 2],
                        ptop_power_data[i, 3],
                        ptop_power_data[i, 4]);
            }

            temp_num = 0;

            power_txt.Close();

        }


        public void MakePowerNmaeFile(List<string> power_list_name, string power_list2)
        {

            DirectoryInfo dir = new DirectoryInfo(rootsavepath + "DAT\\");
            if (dir.Exists != true)
            {
                dir.Create();
            }


            string savePath = rootsavepath + "DAT\\" + power_list2 + ".txt";
            StreamWriter power_txt_name = new StreamWriter(new FileStream(savePath, FileMode.Create));

            for (int i = 0; i< power_list_name.Count;i++)
            {
                power_txt_name.WriteLine(power_list_name[i].ToString()+".dat");
                //power_txt_name.WriteLine("PSET_" + power_list_name[i].ToString() + ".dat");
            }
            power_txt_name.Close();

        }


        public void MakePowerBatFile(List<string> power_list_name, string power_list2)
        {

            DirectoryInfo dir = new DirectoryInfo(rootsavepath + "DAT\\");
            if (dir.Exists != true)
            {
                dir.Create();
            }


            string savePath = rootsavepath + "DAT\\" +  power_list2 + ".bat";
            StreamWriter power_txt_name = new StreamWriter(new FileStream(savePath, FileMode.Create));

            power_txt_name.WriteLine("@echo off");
            power_txt_name.WriteLine("echo USAGE : CompilePSET PSET_FILE");
            power_txt_name.WriteLine("rem ======== PSET ========");
            power_txt_name.WriteLine("\n");


            for (int i = 0; i < power_list_name.Count; i++)
            {
                if (i == 0)
                {
                    power_txt_name.WriteLine(@".\UTIL\pset2bin -pwr ./BIN/PINMAP_MAKALU.dat.pin -pset ./Power/{0}.dat > pset_log.txt", power_list_name[i]);
                    //power_txt_name.WriteLine(@".\UTIL\pset2bin -pwr ./BIN/PINMAP_MAKALU.dat.pin -pset ./PAT/{0}.dat", "PSET_" + power_list_name[i]);
                }
                else
                {
                    power_txt_name.WriteLine(@".\UTIL\pset2bin -pwr ./BIN/PINMAP_MAKALU.dat.pin -pset ./Power/{0}.dat >> pset_log.txt", power_list_name[i]);
                    //power_txt_name.WriteLine(@".\UTIL\pset2bin -pwr ./BIN/PINMAP_MAKALU.dat.pin -pset ./PAT/{0}.dat", "PSET_" + power_list_name[i]);
                }
            }

            power_txt_name.WriteLine("\n");
            power_txt_name.WriteLine(@"move .\Power\*.bin .\BIN");
            power_txt_name.WriteLine(@"move .\Power\*.dat.txt .\TEMP");
            power_txt_name.WriteLine("\n");
            power_txt_name.WriteLine("pause");



            power_txt_name.Close();

        }



        public void getDCsheet(string dc_name)
        {
            dc_sheet = ate_bb.Worksheets[dc_name];
            dc_range = dc_sheet.UsedRange;
            dc_data = dc_range.Value2;
        }

        public void getLvlsheet(string level)
        {
            level_sheet = ate_bb.Worksheets[level];
            level_range = level_sheet.UsedRange;
            level_data = level_range.Value2;
            level_data_fomula = level_range.Formula;


        }

        public void getptopPower(string name)
        {
            ptop_power_sheet = ate_bb.Worksheets[name];
            ptop_power_range = ptop_power_sheet.UsedRange;
            ptop_power = ptop_power_range.Value2;

        }

    }

}


