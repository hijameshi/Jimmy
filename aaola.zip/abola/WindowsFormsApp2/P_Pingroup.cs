﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Runtime.InteropServices;
using Microsoft.Office.Interop.Excel;
using Excel = Microsoft.Office.Interop.Excel;
using System.Text.RegularExpressions;
using System.IO;
using System.Data;


namespace abola
{
    partial class Bolt
    {
        public void Make_Pingroup_TXT()
        {
            string savePath = rootsavepath + "pin_group.txt";
            StreamWriter pingroup_txt = new StreamWriter(new FileStream(savePath, FileMode.Create));


            for (int i = 4; i <= ate_data.GetLength(0); i++)
            {
                if (ate_data[i, 3]?.ToString() == null)
                {
                    break;
                }
                if (ate_data[i,2]?.ToString()!=null)
                {
                    if(ate_data[i - 1, 2]?.ToString() ==null || ate_data[i, 2]?.ToString() != ate_data[i-1, 2]?.ToString())
                    {
                        pingroup_txt.Write("\n");
                        pingroup_txt.Write(ate_data[i, 2]?.ToString());
                        pingroup_txt.Write("\t");
                        pingroup_txt.Write(ate_data[i, 3]?.ToString());
                    }
                    else
                    {
                        pingroup_txt.Write(", ");
                        pingroup_txt.Write(ate_data[i, 3]?.ToString());
                    }

                    if (i < ate_data.GetLength(0))
                    {
                        if (ate_data[i, 2]?.ToString() != ate_data[i + 1, 2]?.ToString())
                        {
                            pingroup_txt.Write(";");
                        }
                    }
                    if (i == ate_data.GetLength(0))
                    {
                        pingroup_txt.Write(";");

                    }

                }
            }

            pingroup_txt.Close();
        }
    }

}


