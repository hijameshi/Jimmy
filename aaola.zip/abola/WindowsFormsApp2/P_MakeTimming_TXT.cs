﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Runtime.InteropServices;
using Microsoft.Office.Interop.Excel;
using Excel = Microsoft.Office.Interop.Excel;
using System.Text.RegularExpressions;
using System.IO;
using System.Data;


namespace abola
{
    partial class Bolt
    {

        int tempcnttt = 0;

        string[,] timming;
        List<string> tsetname = new List<string>();
        List<string> time_list = new List<string>();
        List<string> time_list_name = new List<string>();
        List<string> time_list_spdtst = new List<string>();
        List<string> time_list_name_spdtst = new List<string>();
        List<string> timing_error = new List<string>();


        int tsetcnt;
        int tpcnt;
        int nottpcnt;

        string time_onerow;
        object[,] ptop_time;
        object[,] time_data;
        object[,] ac_data;
        object[,] ac_data_temp;
        object[,] time_data_fomula;
        object[,] ptop_time_fomula;
        string[,] time_data_txt;

        string time_ptop_sheet_name;
        Range ptop_time_range;
        Range time_range;
        Range ac_range;

        string[,] time_fomula_check;
        string time_onerow_name;

        string time;
        string time_category;
        string time_selector;

        string time_temp;
        public string ac_spec_name;

        Worksheet ptop_time_sheet;
        Worksheet time_sheet;
        Worksheet ac_sheet;

        string temp_3;
        string temp4;
        string temp5;
        string temp_6;

        List<string> timing_modify = new List<string>();

        public static string rootsavepath;

        public void MakeTimming_TXT()
        {
            string bar;
            string temp_modi;

            timming = new string[ate_data.GetLength(0) - 4, 3];



            string jobsheetname_1 = "Job";
            string jobsheetname_2 = "Jobs";
            Excel.Worksheet job_sheet;
            int job_choice = 0;

            try
            {
                job_sheet = ate_bb.Worksheets[jobsheetname_1];
                job_choice = 1;
            }
            catch (Exception ex)
            {
                job_sheet = ate_bb.Worksheets[jobsheetname_2];
                job_choice = 2;
            }

            Excel.Range job_sheet_range;
            job_sheet_range = job_sheet.UsedRange;
            object[,] jot_sheet_value = job_sheet_range.Value2;

            string ac_spec_name = jot_sheet_value[5, 6]?.ToString().ToUpper();
            //bintablenamepublic = jot_sheet_value[5, 10]?.ToString().ToUpper();




            for (int i = 1; i <= ate_data.GetLength(0) - 4; i++)
            {
                if (ate_data[i + 4, 43] != null)
                {
                    if (ate_data[i+4,5]?.ToString().ToUpper()!="SKIP")
                    {
                        timming[i - 1, 0] = ate_data[i + 4, 43].ToString(); //Level_DEF_SCAN
                        timming[i - 1, 1] = ate_data[i + 4, 41].ToString(); //VDD_SCAN
                        timming[i - 1, 2] = ate_data[i + 4, 42].ToString(); //Sel1

                        time = timming[i - 1, 0];
                        time_category = timming[i - 1, 1];
                        time_selector = timming[i - 1, 2];

                        time_onerow = time + "__" + time_category + "__" + time_selector;
                        time_onerow_name = time + "_" + time_category + "_" + time_selector;

                        time_list.Add(time_onerow);
                        time_list_name.Add(time_onerow_name);
                    }
                }
            }

            time_list = time_list.Distinct().ToList();
            time_list_name = time_list_name.Distinct().ToList();

            for (int v = 0; v< time_list.Count; v++)
            {
                time_list_spdtst.Add(time_list[v]);
                time_list_name_spdtst.Add(time_list_name[v]);
            }

            List<string> time_tp_list = new List<string>();

            time_getDCsheet(ac_spec_name);
            

            for (int i = 5; i<=ac_data.GetLength(0);i++)
            {
                if (ac_data[i,2] == null)
                {
                    tempcnttt = i;
                    break;
                }
            }

            for (int i = tempcnttt + 1; i <= ac_data.GetLength(0); i++)
            {

                    ac_sheet.Rows[i] = null;

            }

            if (tempcnttt > 5 )
            {
                time_getDCsheet(ac_spec_name);
            }

            //ac_sheet.Cells.Delete[i]

            //ac_data_temp = new object[tempcnttt, ac_data.GetLength(1)];

            //for (int i = 1; i <= ac_data_temp.GetLength(0); i++)
            //{
            //    for (int j = 1; j <= ac_data_temp.GetLength(1); j++)
            //    {
            //        ac_data_temp[i, j] = ac_data[i, j];
            //    }
            //}

            //ac_data = ac_data_temp;


            for (int i = 5; i<=ac_data.GetLength(0);i++)
            {
                    time_tp_list.Add(ac_data[i, 2]?.ToString());
            }


            time_tp_list.RemoveAll(item => item == null);
            List<string> time_tp_list_sort = time_tp_list.Distinct().ToList();
            tsetcnt = time_tp_list_sort.Count;
            var listb = time_tp_list_sort.FindAll(x=> x.ToString().ToUpper().IndexOf("TP")>=0);
            var nottp = time_tp_list_sort.FindAll(x => x.ToString().ToUpper().IndexOf("TP") < 0);
            tpcnt = listb.Count;
            nottpcnt = tsetcnt - tpcnt;


            for (int x = 1; x <= time_list.Count; x++)
            {

                string[] listtoarray = new string[3];
                string list_split;
                list_split = time_list[x - 1].ToString();
                listtoarray = list_split.Split(new string[] { "__" }, StringSplitOptions.None);

                time = listtoarray[0];
                time_category = listtoarray[1];
                time_selector = listtoarray[2];

                string power_list2 = time + '_' + time_category + "_" + time_selector;


                string[,] ptop_time_data = new string[time_tp_list_sort.Count, 5];

                for (int i = 1; i <= time_tp_list_sort.Count; i++)
                {
                    ptop_time_data[i - 1, 0] = time_tp_list_sort[i - 1].ToString();
                }

                int temp_check = 0;


                for (int i = 1; i <= time_tp_list_sort.Count; i++)
                {
                    for (int j = 1; j <= ac_data.GetLength(0); j++)
                    {
                        string aa = ac_data[j, 2]?.ToString();
                        string bb = ac_data[j, 4]?.ToString();
                        string cc = ptop_time_data[i - 1, 3];

                        if (ac_data[j, 2]?.ToString().ToUpper() == ptop_time_data[i - 1, 0].ToUpper() && ac_data[j, 4]?.ToString().ToUpper() == time_selector.ToUpper())
                        {
                            ptop_time_data[i - 1, 4] = ac_data[j, 5].ToString(); //5번째에 Typ, min, max
                            for (int w = 1; w <= ac_data.GetLength(1); w++)
                            {
                                string time_category_up = time_category.ToUpper();
                                if (ac_data[3, w]?.ToString().ToUpper() == time_category_up)
                                {
                                    int temp_category = 0;
                                    if (ptop_time_data[i - 1, 4].ToUpper() == "TYP")
                                    {
                                        temp_category = 0;
                                    }
                                    else if (ptop_time_data[i - 1, 4].ToUpper() == "MIN")
                                    {
                                        temp_category = 1;
                                    }
                                    else if (ptop_time_data[i - 1, 4].ToUpper() == "MAX")
                                    {
                                        temp_category = 2;
                                    }

                                    ptop_time_data[i - 1, 2] = ac_data[j, w + temp_category].ToString(); // power 값
                                }
                            }
                        }
                    }
                }

                double[,] tp_var = new double[,] {{0, 8, 10.00, 0.10, 100000000.00},
                                                  {1, 9, 11.25, 0.09, 88888888.89},
                                                  {2, 10, 12.50, 0.08, 80000000.00},
                                                  {3, 11, 13.75, 0.07, 72727272.73},
                                                  {4, 12, 15.00, 0.07, 66666666.67},
                                                  {5, 13, 16.25, 0.06, 61538461.54},
                                                  {6, 14, 17.50, 0.06, 57142857.14},
                                                  {7, 15, 18.75, 0.05, 53333333.33},
                                                  {8, 16, 20.00, 0.05, 50000000.00},
                                                  {12, 20, 25.00, 0.04, 40000000.00},
                                                  {17, 25, 31.25, 0.03, 32000000.00},
                                                  {24, 32, 40.00, 0.03, 25000000.00},
                                                  {32, 40, 50.00, 0.02, 20000000.00},
                                                  {33, 41, 51.25, 0.02, 19512195.12},
                                                  {34, 42, 52.50, 0.02, 19047619.05},
                                                  {35, 43, 53.75, 0.02, 18604651.16},
                                                  {36, 44, 55.00, 0.02, 18181818.18},
                                                  {37, 45, 56.25, 0.02, 17777777.78},
                                                  {38, 46, 57.50, 0.02, 17391304.35},
                                                  {39, 47, 58.75, 0.02, 17021276.60},
                                                  {40, 48, 60.00, 0.02, 16666666.67},
                                                  {41, 49, 61.25, 0.02, 16326530.61},
                                                  {42, 50, 62.50, 0.02, 16000000.00},
                                                  {43, 51, 63.75, 0.02, 15686274.51},
                                                  {44, 52, 65.00, 0.02, 15384615.38},
                                                  {45, 53, 66.25, 0.02, 15094339.62},
                                                  {46, 54, 67.50, 0.01, 14814814.81},
                                                  {47, 55, 68.75, 0.01, 14545454.55},
                                                  {48, 56, 70.00, 0.01, 14285714.29},
                                                  {49, 57, 71.25, 0.01, 14035087.72},
                                                  {50, 58, 72.50, 0.01, 13793103.45},
                                                  {51, 59, 73.75, 0.01, 13559322.03},
                                                  {52, 60, 75.00, 0.01, 13333333.33},
                                                  {53, 61, 76.25, 0.01, 13114754.10},
                                                  {54, 62, 77.50, 0.01, 12903225.81},
                                                  {55, 63, 78.75, 0.01, 12698412.70},
                                                  {56, 64, 80.00, 0.01, 12500000.00},
                                                  {57, 65, 81.25, 0.01, 12307692.31},
                                                  {58, 66, 82.50, 0.01, 12121212.12},
                                                  {59, 67, 83.75, 0.01, 11940298.51},
                                                  {60, 68, 85.00, 0.01, 11764705.88},
                                                  {61, 69, 86.25, 0.01, 11594202.90},
                                                  {62, 70, 87.50, 0.01, 11428571.43},
                                                  {63, 71, 88.75, 0.01, 11267605.63},
                                                  {64, 72, 90.00, 0.01, 11111111.11},
                                                  {65, 73, 91.25, 0.01, 10958904.11},
                                                  {66, 74, 92.50, 0.01, 10810810.81},
                                                  {67, 75, 93.75, 0.01, 10666666.67},
                                                  {68, 76, 95.00, 0.01, 10526315.79},
                                                  {69, 77, 96.25, 0.01, 10389610.39},
                                                  {70, 78, 97.50, 0.01, 10256410.26},
                                                  {71, 79, 98.75, 0.01, 10126582.28},
                                                  {72, 80, 100.00, 0.01, 10000000.00}
                                                  };

                time_getLvlsheet(time);
                time_data_txt = new string[time_data_fomula.GetLength(0), time_data_fomula.GetLength(1)];
                time_fomula_check = new string[time_data_fomula.GetLength(0), time_data_fomula.GetLength(1)];


                //speed
                for (int k = 1; k <= time_data_fomula.GetLength(0); k++)
                {
                    for (int j = 1; j <= time_data_fomula.GetLength(1); j++)
                    {
                        string func = time_data_fomula[k, j].ToString();
                        string cellvalue = time_data[k, j]?.ToString();
                        MatchCollection matches = Regex.Matches(func, "=");
                        int cnt = matches.Count;

                        if (cnt >= 1 && k != 1 && j != 1)
                        {
                            //func = func.Replace("=", "");
                            for (int z = 1; z <= tpcnt; z++)
                            {
                                temp_3 = "_TP" + z.ToString();

                                int mhz = 1000000;
                                double max_speed = Convert.ToDouble(ptop_time_data[z - 1, 2]);
                                int min_speed = 20;
                                string time_category_up = time_category.ToUpper();

                                //if (time_category_up.Contains("SCAN") && temp_3 == "_TP5" && Convert.ToDouble(ptop_time_data[z - 1, 2]) >= 60 * mhz)
                                if (max_speed >= 50 * mhz)
                                {
                                    for (int a = 0; a < tp_var.GetLength(0); a++)
                                    {
                                        if (tp_var[a, 4] <= max_speed * mhz && tp_var[a, 4] >= min_speed * mhz)
                                        {
                                            string temp1 = "SPDTST";
                                            string tp = temp_3;
                                            string speed = tp_var[a, 4].ToString();
                                            time_onerow = time + "__" + time_category + "__" + time_selector + "__" + temp1 + "__" + tp + "__" + speed;
                                            time_onerow_name = time + "_" + time_category + "_" + time_selector + "_" + temp1 + "_" + tp + "_" + speed;

                                            time_list_spdtst.Add(time_onerow);
                                            time_list_name_spdtst.Add(time_onerow_name);
                                        }
                                    }
                                }
                            }
                        }
                    }
                }

            }

            time_list_spdtst = time_list_spdtst.Distinct().ToList();
            time_list_name_spdtst = time_list_name_spdtst.Distinct().ToList();

            time_list.Clear();
            time_list_name.Clear();

            for (int v = 0; v < time_list_spdtst.Count; v++)
            {
                time_list.Add(time_list_spdtst[v]);
                time_list_name.Add(time_list_name_spdtst[v]);
            }


            for (int x = 1; x <= time_list.Count; x++)
            {

                string[] listtoarray = new string[6];
                string list_split;
                list_split = time_list[x - 1].ToString();
                listtoarray = list_split.Split(new string[] { "__" }, StringSplitOptions.None);
                Array.Resize(ref listtoarray, 6);

                time = listtoarray[0];
                time_category = listtoarray[1];
                time_selector = listtoarray[2];
                string spdtst = listtoarray[3];
                string tp_new = listtoarray[4];
                string tp_new_value = listtoarray[5];

                string power_list2 = time + '_' + time_category + "_" + time_selector;
                if (spdtst!=null)
                {
                    power_list2 = power_list2 + '_' + spdtst + '_' + tp_new + '_' + tp_new_value;
                }

                string[,] ptop_time_data = new string[time_tp_list_sort.Count, 5];

                for (int i = 1; i <= time_tp_list_sort.Count; i++)
                {
                    ptop_time_data[i - 1, 0] = time_tp_list_sort[i - 1].ToString();
                }

                int temp_check = 0;


                for (int i = 1; i <= time_tp_list_sort.Count; i++)
                {
                    for (int j = 1; j <= ac_data.GetLength(0); j++)
                    {
                        string aa = ac_data[j, 2]?.ToString();
                        string bb = ac_data[j, 4]?.ToString();
                        string cc = ptop_time_data[i - 1, 3];

                        if (ac_data[j, 2]?.ToString().ToUpper() == ptop_time_data[i - 1, 0].ToUpper() && ac_data[j, 4]?.ToString().ToUpper() == time_selector.ToUpper())
                        {
                            ptop_time_data[i - 1, 4] = ac_data[j, 5].ToString(); //5번째에 Typ, min, max
                            for (int w = 1; w <= ac_data.GetLength(1); w++)
                            {
                                string time_category_up = time_category.ToUpper();
                                if (ac_data[3, w]?.ToString().ToUpper() == time_category_up)
                                {
                                    int temp_category = 0;
                                    if (ptop_time_data[i - 1, 4].ToUpper() == "TYP")
                                    {
                                        temp_category = 0;
                                    }
                                    else if (ptop_time_data[i - 1, 4].ToUpper() == "MIN")
                                    {
                                        temp_category = 1;
                                    }
                                    else if (ptop_time_data[i - 1, 4].ToUpper() == "MAX")
                                    {
                                        temp_category = 2;
                                    }

                                    ptop_time_data[i - 1, 2] = ac_data[j, w + temp_category].ToString(); // power 값
                                }
                            }
                        }
                    }
                }


                //double[,] tp_var = new double[,]{{0, 8, 10.00, 0.10, 100000000.00},
                //                                 {1, 9, 11.25, 0.09, 88888888.89},
                //                                 {2, 10, 12.50, 0.08, 80000000.00},
                //                                 {3, 11, 13.75, 0.07, 72727272.73},
                //                                 {4, 12, 15.00, 0.07, 66666666.67},
                //                                 {5, 13, 16.25, 0.06, 61538461.54},
                //                                 {6, 14, 17.50, 0.06, 57142857.14},
                //                                 {7, 15, 18.75, 0.05, 53333333.33},
                //                                 {8, 16, 20.00, 0.05, 50000000.00},
                //                                 {9, 17, 21.25, 0.05, 47058823.53},
                //                                 {10, 18, 22.50, 0.04, 44444444.44},
                //                                 {11, 19, 23.75, 0.04, 42105263.16},
                //                                 {12, 20, 25.00, 0.04, 40000000.00},
                //                                 {13, 21, 26.25, 0.04, 38095238.10},
                //                                 {14, 22, 27.50, 0.04, 36363636.36},
                //                                 {15, 23, 28.75, 0.03, 34782608.70},
                //                                 {16, 24, 30.00, 0.03, 33333333.33},
                //                                 {17, 25, 31.25, 0.03, 32000000.00},
                //                                 {18, 26, 32.50, 0.03, 30769230.77},
                //                                 {19, 27, 33.75, 0.03, 29629629.63},
                //                                 {20, 28, 35.00, 0.03, 28571428.57},
                //                                 {21, 29, 36.25, 0.03, 27586206.90},
                //                                 {22, 30, 37.50, 0.03, 26666666.67},
                //                                 {23, 31, 38.75, 0.03, 25806451.61},
                //                                 {24, 32, 40.00, 0.03, 25000000.00},
                //                                 {25, 33, 41.25, 0.02, 24242424.24},
                //                                 {26, 34, 42.50, 0.02, 23529411.76},
                //                                 {27, 35, 43.75, 0.02, 22857142.86},
                //                                 {28, 36, 45.00, 0.02, 22222222.22},
                //                                 {29, 37, 46.25, 0.02, 21621621.62},
                //                                 {30, 38, 47.50, 0.02, 21052631.58},
                //                                 {31, 39, 48.75, 0.02, 20512820.51},
                //                                 {32, 40, 50.00, 0.02, 20000000.00},
                //                                 {33, 41, 51.25, 0.02, 19512195.12},
                //                                 {34, 42, 52.50, 0.02, 19047619.05},
                //                                 {35, 43, 53.75, 0.02, 18604651.16},
                //                                 {36, 44, 55.00, 0.02, 18181818.18},
                //                                 {37, 45, 56.25, 0.02, 17777777.78},
                //                                 {38, 46, 57.50, 0.02, 17391304.35},
                //                                 {39, 47, 58.75, 0.02, 17021276.60},
                //                                 {40, 48, 60.00, 0.02, 16666666.67},
                //                                 {41, 49, 61.25, 0.02, 16326530.61},
                //                                 {42, 50, 62.50, 0.02, 16000000.00},
                //                                 {43, 51, 63.75, 0.02, 15686274.51},
                //                                 {44, 52, 65.00, 0.02, 15384615.38},
                //                                 {45, 53, 66.25, 0.02, 15094339.62},
                //                                 {46, 54, 67.50, 0.01, 14814814.81},
                //                                 {47, 55, 68.75, 0.01, 14545454.55},
                //                                 {48, 56, 70.00, 0.01, 14285714.29},
                //                                 {49, 57, 71.25, 0.01, 14035087.72},
                //                                 {50, 58, 72.50, 0.01, 13793103.45},
                //                                 {51, 59, 73.75, 0.01, 13559322.03},
                //                                 {52, 60, 75.00, 0.01, 13333333.33},
                //                                 {53, 61, 76.25, 0.01, 13114754.10},
                //                                 {54, 62, 77.50, 0.01, 12903225.81},
                //                                 {55, 63, 78.75, 0.01, 12698412.70},
                //                                 {56, 64, 80.00, 0.01, 12500000.00},
                //                                 {57, 65, 81.25, 0.01, 12307692.31},
                //                                 {58, 66, 82.50, 0.01, 12121212.12},
                //                                 {59, 67, 83.75, 0.01, 11940298.51},
                //                                 {60, 68, 85.00, 0.01, 11764705.88},
                //                                 {61, 69, 86.25, 0.01, 11594202.90},
                //                                 {62, 70, 87.50, 0.01, 11428571.43},
                //                                 {63, 71, 88.75, 0.01, 11267605.63},
                //                                 {64, 72, 90.00, 0.01, 11111111.11},
                //                                 {65, 73, 91.25, 0.01, 10958904.11},
                //                                 {66, 74, 92.50, 0.01, 10810810.81},
                //                                 {67, 75, 93.75, 0.01, 10666666.67},
                //                                 {68, 76, 95.00, 0.01, 10526315.79},
                //                                 {69, 77, 96.25, 0.01, 10389610.39},
                //                                 {70, 78, 97.50, 0.01, 10256410.26},
                //                                 {71, 79, 98.75, 0.01, 10126582.28},
                //                                 {72, 80, 100.00, 0.01, 10000000.00}};

                double[,] tp_var = new double[,] {{0, 8, 10.00, 0.10, 100000000.00},
                                                  {1, 9, 11.25, 0.09, 88888888.89},
                                                  {2, 10, 12.50, 0.08, 80000000.00},
                                                  {3, 11, 13.75, 0.07, 72727272.73},
                                                  {4, 12, 15.00, 0.07, 66666666.67},
                                                  {5, 13, 16.25, 0.06, 61538461.54},
                                                  {6, 14, 17.50, 0.06, 57142857.14},
                                                  {7, 15, 18.75, 0.05, 53333333.33},
                                                  {8, 16, 20.00, 0.05, 50000000.00},
                                                  {12, 20, 25.00, 0.04, 40000000.00},
                                                  {17, 25, 31.25, 0.03, 32000000.00},
                                                  {24, 32, 40.00, 0.03, 25000000.00},
                                                  {32, 40, 50.00, 0.02, 20000000.00},
                                                  {33, 41, 51.25, 0.02, 19512195.12},
                                                  {34, 42, 52.50, 0.02, 19047619.05},
                                                  {35, 43, 53.75, 0.02, 18604651.16},
                                                  {36, 44, 55.00, 0.02, 18181818.18},
                                                  {37, 45, 56.25, 0.02, 17777777.78},
                                                  {38, 46, 57.50, 0.02, 17391304.35},
                                                  {39, 47, 58.75, 0.02, 17021276.60},
                                                  {40, 48, 60.00, 0.02, 16666666.67},
                                                  {41, 49, 61.25, 0.02, 16326530.61},
                                                  {42, 50, 62.50, 0.02, 16000000.00},
                                                  {43, 51, 63.75, 0.02, 15686274.51},
                                                  {44, 52, 65.00, 0.02, 15384615.38},
                                                  {45, 53, 66.25, 0.02, 15094339.62},
                                                  {46, 54, 67.50, 0.01, 14814814.81},
                                                  {47, 55, 68.75, 0.01, 14545454.55},
                                                  {48, 56, 70.00, 0.01, 14285714.29},
                                                  {49, 57, 71.25, 0.01, 14035087.72},
                                                  {50, 58, 72.50, 0.01, 13793103.45},
                                                  {51, 59, 73.75, 0.01, 13559322.03},
                                                  {52, 60, 75.00, 0.01, 13333333.33},
                                                  {53, 61, 76.25, 0.01, 13114754.10},
                                                  {54, 62, 77.50, 0.01, 12903225.81},
                                                  {55, 63, 78.75, 0.01, 12698412.70},
                                                  {56, 64, 80.00, 0.01, 12500000.00},
                                                  {57, 65, 81.25, 0.01, 12307692.31},
                                                  {58, 66, 82.50, 0.01, 12121212.12},
                                                  {59, 67, 83.75, 0.01, 11940298.51},
                                                  {60, 68, 85.00, 0.01, 11764705.88},
                                                  {61, 69, 86.25, 0.01, 11594202.90},
                                                  {62, 70, 87.50, 0.01, 11428571.43},
                                                  {63, 71, 88.75, 0.01, 11267605.63},
                                                  {64, 72, 90.00, 0.01, 11111111.11},
                                                  {65, 73, 91.25, 0.01, 10958904.11},
                                                  {66, 74, 92.50, 0.01, 10810810.81},
                                                  {67, 75, 93.75, 0.01, 10666666.67},
                                                  {68, 76, 95.00, 0.01, 10526315.79},
                                                  {69, 77, 96.25, 0.01, 10389610.39},
                                                  {70, 78, 97.50, 0.01, 10256410.26},
                                                  {71, 79, 98.75, 0.01, 10126582.28},
                                                  {72, 80, 100.00, 0.01, 10000000.00}
                                                  };

                time_getLvlsheet(time);
                time_data_txt = new string[time_data_fomula.GetLength(0), time_data_fomula.GetLength(1)];
                time_fomula_check = new string[time_data_fomula.GetLength(0), time_data_fomula.GetLength(1)];

                for (int k = 1; k <= time_data_fomula.GetLength(0); k++)
                {


                    for (int j = 1; j <= time_data_fomula.GetLength(1); j++)
                    {
                        string func = time_data_fomula[k, j].ToString();
                        string cellvalue = time_data[k, j]?.ToString();
                        MatchCollection matches = Regex.Matches(func, "=");
                        int cnt = matches.Count;

                        if (cnt >= 1 && k != 1 && j != 1)
                        {
                            //func = func.Replace("=", "");

                            for (int z = 1; z <= tpcnt; z++)
                            {
                                temp_3 = "_TP" + z.ToString();

                                /*
                                8	10.00 	0.10 	100000000.00 
                                9	11.25 	0.09 	88888888.89 
                                10	12.50 	0.08 	80000000.00 
                                11	13.75 	0.07 	72727272.73 
                                12	15.00 	0.07 	66666666.67 
                                13	16.25 	0.06 	61538461.54 
                                14	17.50 	0.06 	57142857.14 
                                15	18.75 	0.05 	53333333.33 
                                16	20.00 	0.05 	50000000.00 
                                17	21.25 	0.05 	47058823.53 
                                18	22.50 	0.04 	44444444.44 
                                19	23.75 	0.04 	42105263.16 
                                20	25.00 	0.04 	40000000.00 
                                21	26.25 	0.04 	38095238.10 
                                22	27.50 	0.04 	36363636.36 
                                23	28.75 	0.03 	34782608.70 
                                24	30.00 	0.03 	33333333.33 
                                25	31.25 	0.03 	32000000.00 
                                26	32.50 	0.03 	30769230.77 
                                27	33.75 	0.03 	29629629.63 
                                28	35.00 	0.03 	28571428.57 
                                29	36.25 	0.03 	27586206.90 
                                30	37.50 	0.03 	26666666.67 
                                31	38.75 	0.03 	25806451.61 
                                32	40.00 	0.03 	25000000.00 
                                33	41.25 	0.02 	24242424.24 
                                34	42.50 	0.02 	23529411.76 
                                35	43.75 	0.02 	22857142.86 
                                36	45.00 	0.02 	22222222.22 
                                37	46.25 	0.02 	21621621.62 
                                38	47.50 	0.02 	21052631.58 
                                39	48.75 	0.02 	20512820.51 
                                40	50.00 	0.02 	20000000.00 
                                41	51.25 	0.02 	19512195.12 
                                42	52.50 	0.02 	19047619.05 
                                43	53.75 	0.02 	18604651.16 
                                44	55.00 	0.02 	18181818.18 
                                45	56.25 	0.02 	17777777.78 
                                46	57.50 	0.02 	17391304.35 
                                47	58.75 	0.02 	17021276.60 
                                48	60.00 	0.02 	16666666.67 
                                49	61.25 	0.02 	16326530.61 
                                50	62.50 	0.02 	16000000.00 
                                51	63.75 	0.02 	15686274.51 
                                52	65.00 	0.02 	15384615.38 
                                53	66.25 	0.02 	15094339.62 
                                54	67.50 	0.01 	14814814.81 
                                55	68.75 	0.01 	14545454.55 
                                56	70.00 	0.01 	14285714.29 
                                57	71.25 	0.01 	14035087.72 
                                58	72.50 	0.01 	13793103.45 
                                59	73.75 	0.01 	13559322.03 
                                60	75.00 	0.01 	13333333.33 
                                61	76.25 	0.01 	13114754.10 
                                62	77.50 	0.01 	12903225.81 
                                63	78.75 	0.01 	12698412.70 
                                64	80.00 	0.01 	12500000.00 
                                65	81.25 	0.01 	12307692.31 
                                66	82.50 	0.01 	12121212.12 
                                67	83.75 	0.01 	11940298.51 
                                68	85.00 	0.01 	11764705.88 
                                69	86.25 	0.01 	11594202.90 
                                70	87.50 	0.01 	11428571.43 
                                71	88.75 	0.01 	11267605.63 
                                72	90.00 	0.01 	11111111.11 
                                73	91.25 	0.01 	10958904.11 
                                74	92.50 	0.01 	10810810.81 
                                75	93.75 	0.01 	10666666.67 
                                76	95.00 	0.01 	10526315.79 
                                77	96.25 	0.01 	10389610.39 
                                78	97.50 	0.01 	10256410.26 
                                79	98.75 	0.01 	10126582.28 
                                80	100.00 	0.01 	10000000.00 
                                 */

                                int mhz = 1000000;

                                if (Convert.ToDouble(ptop_time_data[z - 1, 2]) > 100 * mhz)
                                {
                                    double temp_val = 100000000;

                                    bar = "__";
                                    string tset = time_data_txt[k - 1, 1];
                                    string ment = "TP 100M over";
                                    string temp_period = time_data_txt[k - 1, 2];
                                    string D1 = time_data_txt[k - 1, 9];
                                    string pin = time_data_txt[k - 1, 3];

                                    temp_modi =
                                        power_list2 + bar +
                                        temp_3 + bar +
                                        ment + bar +
                                        pin + bar +
                                        temp_period + bar +
                                        D1 + bar +
                                        ptop_time_data[z - 1, 2] + bar +
                                        temp_val.ToString() + bar +
                                        "" + bar +
                                        ""
                                        ;

                                    timing_modify.Add(temp_modi);

                                    ptop_time_data[z - 1, 2] = temp_val.ToString();

                                    temp_check = 1;
                                }

                                if (spdtst == "SPDTST" && temp_3 == tp_new)
                                {
                                    func = func.Replace(temp_3, tp_new_value);

                                }
                                else
                                {
                                    temp_6 = ptop_time_data[z - 1, 2];
                                    func = func.Replace(temp_3, ptop_time_data[z - 1, 2]);
                                }

                            }


                            for (int w = nottpcnt-1; w >= 0; w--)
                            {
                                temp4 = "_" + nottp[w];
                                func = func.Replace(temp4, ptop_time_data[tpcnt + w, 2]);
                                func = func.Replace("=", "");
                            }

                            //for (int w=0; w< nottpcnt; w++)
                            //{
                            //    temp4 = "_" + nottp[w];
                            //    func = func.Replace(temp4, ptop_time_data[tpcnt+w, 2]);
                            //    func = func.Replace("=", "");
                            //}

                            //temp4 = "_FCLK";
                            //func = func.Replace(temp4, ptop_time_data[9, 2]);

                            //temp5 = "_FCLK2";
                            //func = func.Replace(temp5, ptop_time_data[10, 2]);


                            //func = func.Replace("=", "");



                            //string b = "234";
                            //string a = "29837/3432/" + b;
                            System.Data.DataTable table1 = new System.Data.DataTable();
                            string value1="";
                            try
                            {
                                value1 = table1.Compute(func, "")?.ToString();
                            }
                            catch(DivideByZeroException)
                            {
                                value1 = "0";
                                timing_error.Add(time + "_" + time_category + "_" + time_selector + "\t" +k+"\t"+j+"\t"+ func);

                            }
                                //Console.WriteLine(value);
                                double number1 = Convert.ToDouble(value1);
                                //double number2 = Math.Round(number1, 13);

                                //cellvalue = number1.ToString();

                                time_data_txt[k - 1, j - 1] = number1.ToString();
                                time_fomula_check[k - 1, j - 1] = "fomula";






                            //time_data_txt[k - 1, j - 1] = func;
                            //string aaa = time_data_txt[k - 1, j - 1];

                        }
                        else
                        {
                            time_data_txt[k - 1, j - 1] = func;
                            //string bbb = time_data_txt[k - 1, j - 1];
                        }


                        //                            time_data_fomula;
                    }

                    if (time_data_txt[k - 1, 5].ToUpper() == "I/O" && time_data_txt[k - 1, 6].ToUpper() == "ALLHI")
                    {

                        string temp_val = "PAT";

                        bar = "__";
                        string tset = time_data_txt[k - 1, 1];
                        string ment = "I/O ALLHI";
                        string temp_period = time_data_txt[k - 1, 2];
                        string D1 = time_data_txt[k - 1, 9];
                        string pin = time_data_txt[k - 1, 3];

                        temp_modi =
                            power_list2 + bar +
                            tset + bar +
                            ment + bar +
                            pin + bar +
                            temp_period + bar +
                            D1 + bar +
                            time_data_txt[k - 1, 6] + bar +
                            temp_val.ToString() + bar +
                            "" + bar +
                            ""
                            ;

                        timing_modify.Add(temp_modi);

                        time_data_txt[k - 1, 6] = temp_val.ToString();

                        temp_check = 1;

                    }//"ALLHI";
                    if (time_data_txt[k - 1, 5].ToUpper() == "I/O" && time_data_txt[k - 1, 6].ToUpper() == "ALLLO")
                    {

                        string temp_val = "PAT";

                        bar = "__";
                        string tset = time_data_txt[k - 1, 1];
                        string ment = "I/O ALLLO";
                        string temp_period = time_data_txt[k - 1, 2];
                        string D1 = time_data_txt[k - 1, 9];
                        string pin = time_data_txt[k - 1, 3];

                        temp_modi =
                            power_list2 + bar +
                            tset + bar +
                            ment + bar +
                            pin + bar +
                            temp_period + bar +
                            D1 + bar +
                            time_data_txt[k - 1, 6] + bar +
                            temp_val.ToString() + bar +
                            "" + bar +
                            ""
                            ;

                        timing_modify.Add(temp_modi);

                        time_data_txt[k - 1, 6] = temp_val.ToString();

                        temp_check = 1;

                    }//"ALLLO";

                    if (time_fomula_check[k - 1, 9] == "fomula")
                    {
                        if (time_data_txt[k - 1, 1] != "")
                        {
                            double D1_val = Convert.ToDouble(time_data_txt[k - 1, 9]);
                            double Period = Convert.ToDouble(time_data_txt[k - 1, 2]);

                            if (Period *2 <= D1_val)
                            {
                                double temp_val = 0;
                                
                                for (int i = 10; i >= 1; i--)
                                {
                                    if (D1_val - (Period * i) < Period * 2 && D1_val - (Period * i) > 0)
                                    {
                                        temp_val = D1_val - (Period * i);
                                        break;
                                    }
                                }
                                if (temp_val <= 0 )
                                {
                                    MessageBox.Show("Period *2 < D1 에러발생! 컨버터 검토필요!");
                                }
                                //double temp_val = Convert.ToDouble(time_data_txt[k - 1, 2]) * 1.90; //*1.9

                                bar = "__";
                                string tset = time_data_txt[k - 1, 1];
                                string ment = "Priod *2 < D1";
                                string temp_period = time_data_txt[k - 1, 2];
                                string D1 = time_data_txt[k - 1, 9];
                                string pin = time_data_txt[k - 1, 3];

                                temp_modi =
                                    power_list2 + bar +
                                    tset + bar +
                                    ment + bar +
                                    pin + bar +
                                    temp_period + bar +
                                    D1 + bar +
                                    time_data_txt[k - 1, 9] + bar +
                                    temp_val.ToString() + bar +
                                    "" + bar +
                                    ""
                                    ;

                                timing_modify.Add(temp_modi);

                                time_data_txt[k - 1, 9] = temp_val.ToString();

                                temp_check = 1;
                            }
                        }
                    } //"Priod *2 < D1";

                    if (time_data_txt[k - 1, 12].ToUpper() == "WINDOW")
                    {
                        string temp_val = "Edge";

                        bar = "__";
                        string tset = time_data_txt[k - 1, 1];
                        string ment = "Window -> Edge";
                        string temp_period = time_data_txt[k - 1, 2];
                        string D1 = time_data_txt[k - 1, 9];
                        string pin = time_data_txt[k - 1, 3];

                        temp_modi =
                            power_list2 + bar +
                            tset + bar +
                            ment + bar +
                            pin + bar +
                            temp_period + bar +
                            D1 + bar +
                            time_data_txt[k - 1, 12] + bar +
                            temp_val.ToString() + bar +
                            "" + bar +
                            ""
                            ;

                        timing_modify.Add(temp_modi);

                        time_data_txt[k - 1, 12] = temp_val.ToString();

                        temp_check = 1;
                    } //"Window -> Edge";

                    if (time_fomula_check[k - 1, 13] == "fomula") 
                    {

                        if (time_data_txt[k - 1, 14] == "")
                        {

                            int temp_val = 0;

                            bar = "__";
                            string tset = time_data_txt[k - 1, 1];
                            string ment = "compare D2 empty";
                            string temp_period = time_data_txt[k - 1, 2];
                            string D1 = time_data_txt[k - 1, 9];
                            string pin = time_data_txt[k - 1, 3];

                            temp_modi =
                                power_list2 + bar +
                                tset + bar +
                                ment + bar +
                                pin + bar +
                                temp_period + bar +
                                D1 + bar +
                                "empty" + bar +
                                temp_val.ToString() + bar +
                                "" + bar +
                                ""
                                ;

                            timing_modify.Add(temp_modi);

                            time_data_txt[k - 1, 14] = temp_val.ToString();

                            temp_check = 1;

                        }
                    } //"compare D2 empty";

                    //if (time_fomula_check[k - 1, 10] == "fomula")
                    //{
                    double numcheck = 0.0;
                    if (double.TryParse(time_data_txt[k - 1, 9], out numcheck))
                    {
                        if ((Convert.ToDouble(time_data_txt[k - 1, 10]) - Convert.ToDouble(time_data_txt[k - 1, 9]) < 0.0000000025)
                            && (Convert.ToDouble(time_data_txt[k - 1, 9]) != 0)
                            && (Convert.ToDouble(time_data_txt[k - 1, 10]) != 0))
                        {
                            double temp_val = Convert.ToDouble(time_data_txt[k - 1, 9]) + 0.0000000025;

                            bar = "__";
                            string tset = time_data_txt[k - 1, 1];
                            string ment = "D2_2.5n";
                            string temp_period = time_data_txt[k - 1, 2];
                            string D1 = time_data_txt[k - 1, 9];
                            string pin = time_data_txt[k - 1, 3];

                            temp_modi =
                                power_list2 + bar +
                                tset + bar +
                                ment + bar +
                                pin + bar +
                                temp_period + bar +
                                D1 + bar +
                                time_data_txt[k - 1, 10] + bar +
                                temp_val.ToString() + bar +
                                "" + bar +
                                ""
                                ;

                            timing_modify.Add(temp_modi);

                            time_data_txt[k - 1, 10] = temp_val.ToString();

                            temp_check = 1;
                        }//"D2_2.5n";
                    }//"D2_2.5n";
                    //} //"D2_2.5n";

                    if (time_fomula_check[k - 1, 10] == "fomula")
                    {
                        if (time_data_txt[k - 1, 1] != "")
                        {
                            if (Convert.ToDouble(time_data_txt[k - 1, 10]) / Convert.ToDouble(time_data_txt[k - 1, 2]) >= 1.95)
                            {
                                double temp_val = Convert.ToDouble(time_data_txt[k - 1, 2]) * 1.9; //*1.9

                                bar = "__";
                                string tset = time_data_txt[k - 1, 1];
                                string ment = "Priod *2 < D2";
                                string temp_period = time_data_txt[k - 1, 2];
                                string D1 = time_data_txt[k - 1, 9];
                                string pin = time_data_txt[k - 1, 3];

                                temp_modi =
                                    power_list2 + bar +
                                    tset + bar +
                                    ment + bar +
                                    pin + bar +
                                    temp_period + bar +
                                    D1 + bar +
                                    time_data_txt[k - 1, 10] + bar +
                                    temp_val.ToString() + bar +
                                    "" + bar +
                                    ""
                                    ;

                                timing_modify.Add(temp_modi);

                                time_data_txt[k - 1, 10] = temp_val.ToString();

                                temp_check = 1;
                            }
                        }
                    } //"Priod *2 < D2";

                    if (time_fomula_check[k - 1, 13] == "fomula")
                    {
                        if (Convert.ToDouble(time_data_txt[k - 1, 13]) / Convert.ToDouble(time_data_txt[k - 1, 2])>=1.95)
                        {
                            double temp_val = Convert.ToDouble(time_data_txt[k - 1, 2]) * 1.9;

                            bar = "__";
                            string tset = time_data_txt[k - 1, 1];
                            string ment = "Period *2 < Compare";
                            string temp_period = time_data_txt[k - 1, 2];
                            string D1 = time_data_txt[k - 1, 9];
                            string pin = time_data_txt[k - 1, 3];

                            temp_modi =
                                power_list2 + bar +
                                tset + bar +
                                ment + bar +
                                pin + bar +
                                temp_period + bar +
                                D1 + bar +
                                "" + bar +
                                "" + bar +
                                time_data_txt[k - 1, 13] + bar +
                                temp_val.ToString()
                                ;

                            timing_modify.Add(temp_modi);

                            time_data_txt[k - 1, 13] = temp_val.ToString();

                            temp_check = 1;
                        }
                    } //"Period *2 < Compare";

                    if (time_fomula_check[k - 1, 2] == "fomula")
                    {
                        if (Convert.ToDouble(time_data_txt[k - 1, 2]) < 0.000000010)
                        {
                            double temp_val = 0.000000010;

                            bar = "__";
                            string tset = time_data_txt[k - 1, 1];
                            string ment = "Period < 10n";
                            string temp_period = time_data_txt[k - 1, 2];
                            string D1 = time_data_txt[k - 1, 9];
                            string pin = time_data_txt[k - 1, 3];

                            temp_modi =
                                power_list2 + bar +
                                tset + bar +
                                ment + bar +
                                pin + bar +
                                temp_period + bar +
                                D1 + bar +
                                time_data_txt[k - 1, 2] + bar +
                                temp_val.ToString() + bar +
                                "" + bar +
                                ""
                                ;

                            timing_modify.Add(temp_modi);

                            time_data_txt[k - 1, 2] = temp_val.ToString();

                            temp_check = 1;
                        }
                    } //"Period < 10n";

                    if (k>7 && time_data_txt[k - 1, 5].ToUpper() != "CLOCK" && time_data_txt[k - 1, 13].ToUpper() == "")
                    {
                            double temp_val = 0;

                            bar = "__";
                            string tset = time_data_txt[k - 1, 1];
                            string ment = "compare1 = null -> 0";
                            string temp_period = time_data_txt[k - 1, 2];
                            string D1 = time_data_txt[k - 1, 9];
                            string pin = time_data_txt[k - 1, 3];

                            temp_modi =
                                power_list2 + bar +
                                tset + bar +
                                ment + bar +
                                pin + bar +
                                temp_period + bar +
                                D1 + bar +
                                "null" + bar +
                                temp_val.ToString() + bar +
                                "" + bar +
                                ""
                                ;

                            timing_modify.Add(temp_modi);

                            time_data_txt[k - 1, 13] = temp_val.ToString();

                            temp_check = 1;
                        
                    } //"compare1 = null -> 0";

                    if (k>7 && time_data_txt[k - 1, 5].ToUpper() != "CLOCK" && time_data_txt[k - 1, 14].ToUpper() == "")
                    {
                        double temp_val = 0;

                        bar = "__";
                        string tset = time_data_txt[k - 1, 1];
                        string ment = "compare2 = null -> 0";
                        string temp_period = time_data_txt[k - 1, 2];
                        string D1 = time_data_txt[k - 1, 9];
                        string pin = time_data_txt[k - 1, 3];

                        temp_modi =
                            power_list2 + bar +
                            tset + bar +
                            ment + bar +
                            pin + bar +
                            temp_period + bar +
                            D1 + bar +
                            "null" + bar +
                            temp_val.ToString() + bar +
                            "" + bar +
                            ""
                            ;

                        timing_modify.Add(temp_modi);

                        time_data_txt[k - 1, 14] = temp_val.ToString();

                        temp_check = 1;

                    } //"compare2 = null -> 0";


                    ////debug 20n
                    //if (time_fomula_check[k - 1, 2] == "fomula")
                    //{
                    //    if (Convert.ToDouble(time_data_txt[k - 1, 2]) < 0.000000015)
                    //    {
                    //        double temp_val = 0.000000015;

                    //        bar = "__";
                    //        string tset = time_data_txt[k - 1, 1];
                    //        string ment = "Period < 15n";
                    //        string temp_period = time_data_txt[k - 1, 2];
                    //        string D1 = time_data_txt[k - 1, 9];
                    //        string pin = time_data_txt[k - 1, 3];

                    //        temp_modi =
                    //            power_list2 + bar +
                    //            tset + bar +
                    //            ment + bar +
                    //            pin + bar +
                    //            temp_period + bar +
                    //            D1 + bar +
                    //            time_data_txt[k - 1, 2] + bar +
                    //            temp_val.ToString() + bar +
                    //            "" + bar +
                    //            ""
                    //            ;

                    //        timing_modify.Add(temp_modi);

                    //        time_data_txt[k - 1, 2] = temp_val.ToString();

                    //        temp_check = 1;
                    //    }
                    //}


                }

                if (temp_check == 1)
                {
                    bar = "__";
                    temp_modi = "" + bar + "" + bar + "" + bar + "" + bar + "" + bar + "" + bar + "" + bar + "" + bar +"" + bar + "";

                    timing_modify.Add(temp_modi);



                    temp_check = 0;
                }

                MakeTimeTxtFile(time_data_txt, power_list2);

            }

            MakeTimeNmaeFile(time_list_name, "timing_list");
            MakeErrorFile();
            MakeTimingBatFile(time_list_name, "1_CompileTSET");
            MakeTimingModifyFile(timing_modify, "timing_modify");

        }



        public void MakeTimingModifyFile(List<string> timing_modify, string power_list2)
        {

            DirectoryInfo dir = new DirectoryInfo(rootsavepath + "DAT\\");
            if (dir.Exists != true)
            {
                dir.Create();
            }

            string savePath = rootsavepath + "DAT\\" + power_list2 + ".txt";
            StreamWriter power_txt = new StreamWriter(new FileStream(savePath, FileMode.Create));


            power_txt.WriteLine("timing\t\t\ttset\t\t\tcause\t\t\tpin\t\t\tperiod\t\t\tD1\t\t\tD2_o\t\t\tD2_m\t\t\tcompare_o\t\t\tcompare_m");

            string[] ptop_power_data = new string[10];


            for (int i = 0; i < timing_modify.Count; i++)
            {

                string list_split;
                list_split = timing_modify[i].ToString();
                ptop_power_data = list_split.Split(new string[] { "__" }, StringSplitOptions.None);


                    power_txt.WriteLine("{0}\t\t{1}\t\t{2}\t\t{3}\t\t{4}\t\t{5}\t\t{6}\t\t{7}\t\t{8}\t\t{9}",
                        ptop_power_data?[0],
                        ptop_power_data?[1],
                        ptop_power_data?[2],
                        ptop_power_data?[3],
                        ptop_power_data?[4],
                        ptop_power_data?[5],
                        ptop_power_data?[6],
                        ptop_power_data?[7],
                        ptop_power_data?[8],
                        ptop_power_data?[9]
                        );


                power_txt.Write("\n");
            }

            power_txt.Close();

        }

        public void MakeTimeTxtFile(string[,] ptop_power_data, string power_list2)
        {

            DirectoryInfo dir = new DirectoryInfo(rootsavepath + "DAT\\Timing\\");
            if (dir.Exists != true)
            {
                dir.Create();
            }


            string savePath = rootsavepath + "DAT\\Timing\\" + power_list2 + ".dat";
            //string savePath = @form1.rootsavepath + "Timing\\" + "TSET_" + power_list2 + ".dat";
            StreamWriter power_txt = new StreamWriter(new FileStream(savePath, FileMode.Create));


            string[] all_pins = new string[] { "XAMIC_PDM", "XAUD_FM_SPDY_M", "XAUD_I2S0_BCLK", "Xaud_CODEC_MCLK", "XAUD_I2S0_SDI", "XAUD_I2S0_SDO", "XAUD_I2S0_WS", "XAUD_I2S1_BCLK", "XAUD_I2S1_SDI", "XAUD_I2S1_SDO", "XAUD_I2S1_WS", "XCAM_MCLK0", "XCAM_MCLK1", "XCAM_MCLK2", "XCAM_MCLK3", "XCHUB_GPIO0", "XCHUB_GPIO1", "XCHUB_GPIO2", "XCHUB_GPIO3", "XCHUB_GPIO4", "XCHUB_GPIO5", "XCLKOUT0", "XCLKOUT1", "XCP_ANT_SW0", "XCP_ANT_SW1", "XCP_ANT_SW10", "XCP_ANT_SW11", "XCP_ANT_SW2", "XCP_ANT_SW3", "XCP_ANT_SW4", "XCP_ANT_SW5", "XCP_ANT_SW6", "XCP_ANT_SW7", "XCP_ANT_SW8", "XCP_ANT_SW9", "XCP_C_SUB6_HI_SPEEDY_CLK", "XCP_C_SUB6_HI_SPEEDY_DATA", "XCP_EXT_LNA_ON0", "XCP_EXT_LNA_ON1", "XCP_EXT_LNA_ON2", "XCP_EXT_LNA_ON3", "XCP_EXT_LNA_ON4", "XCP_GPIO_ALV0", "XCP_GPIO_ALV1", "XCP_GPIO_ALV2", "XCP_GPIO_ALV3", "XCP_GPIO_ALV4", "XCP_GPIO_ALV5", "XCP_GPIO0", "XCP_GPIO1", "XCP_GPIO2", "XCP_GPIO3", "XCP_GPIO4", "XCP_GPIO5", "XCP_MIPI_RFFE0_SCLK", "XCP_MIPI_RFFE0_SDATA", "XCP_MIPI_RFFE1_SCLK", "XCP_MIPI_RFFE1_SDATA", "XCP_MIPI_RFFE2_SCLK", "XCP_MIPI_RFFE2_SDATA", "XCP_MIPI_RFFE3_SCLK", "XCP_MIPI_RFFE3_SDATA", "XCP_RFIC_CSPEEDY", "XCP_RFIC_RESET0", "XCP_RFIC_RESET1", "XCP_TX_GSM_POLAR", "XCP_UCPU_MON_CLK", "XCP_USIM0_CLK", "XCP_USIM0_DATA", "XCP_USIM0_RST_N", "XCP_USIM1_CLK", "XCP_USIM1_DATA", "XCP_USIM1_RST_N", "XDMIC_CLK", "XDMIC_CLK_3RD", "XDMIC_PDM", "XEINT_0", "XEINT_1", "XEINT_10", "XEINT_11", "XEINT_2", "XEINT_3", "XEINT_4", "XEINT_5", "XEINT_6", "XEINT_7", "XEINT_8", "XEINT_9", "XGNSS_HI_SPEEDYS", "XGNSS_HI_SPEEDYS_CLK", "XGNSS_LNA_EN", "XGNSS_LNA_EN_DIVL5L2", "XGNSS_SPEEDY", "XGNSS_TSYNC_RFIC", "XGPIO0", "XGPIO1", "XGPIO2", "XGPIO3", "XGPIO4", "XGPIO5", "XGPIO6", "XGPIO7", "Xspeedy_DCXO", "XI3C_PMIC_SCL", "XI3C_PMIC_SDA", "XJTAG_DBGSEL", "XJTAG_TCK", "XJTAG_TDI", "XJTAG_TDO", "XJTAG_TMS", "XJTAG_TRST_N", "XMMC_CARD_CLK", "XMMC_CARD_CMD", "Xmmc_CARD_DATA_0", "Xmmc_CARD_DATA_1", "Xmmc_CARD_DATA_2", "Xmmc_CARD_DATA_3", "XMMC_EMBD_CLK", "XMMC_EMBD_CMD", "Xmmc_EMBD_DATA_0", "Xmmc_EMBD_DATA_1", "Xmmc_EMBD_DATA_2", "Xmmc_EMBD_DATA_3", "Xmmc_EMBD_DATA_4", "Xmmc_EMBD_DATA_5", "Xmmc_EMBD_DATA_6", "Xmmc_EMBD_DATA_7", "XMMC_EMBD_HWRESET", "XMMC_EMBD_RDQS", "XOCP_WARN_CPUCL0", "XOCP_WARN_CPUCL1", "XOCP_WARN_G3D", "XOM_0", "XOM_1", "XOM_2", "XPSHOLD", "XPWM_TOUT_0", "XPWM_TOUT_1", "XRESET_N", "XSMPL_WARN", "XTCXO", "XWLBT_TCXO", "XTE_DECON0", "XUART_DEBUG_RXD", "XUART_DEBUG_TXD", "XUSI_CHUB0_CTSN_CSN_SDA", "XUSI_CHUB0_RTSN_DI_SCL", "XUSI_CHUB0_RXD_CLK_SCL", "XUSI_CHUB0_TXD_DO_SDA", "XUSI_CHUB1_CTSN_CSN_SDA", "XUSI_CHUB1_RTSN_DI_SCL", "XUSI_CHUB1_RXD_CLK_SCL", "XUSI_CHUB1_TXD_DO_SDA", "XUSI_CHUB2_CTSN_CSN_SDA", "XUSI_CHUB2_RTSN_DI_SCL", "XUSI_CHUB2_RXD_CLK_SCL", "XUSI_CHUB2_TXD_DO_SDA", "XUSI_CMGP0_CTSN_CSN_SDA", "XUSI_CMGP0_RTSN_DI_SCL", "XUSI_CMGP0_RXD_CLK_SCL", "XUSI_CMGP0_TXD_DO_SDA", "XUSI_CMGP1_CTSN_CSN_SDA", "XUSI_CMGP1_RTSN_DI_SCL", "XUSI_CMGP1_RXD_CLK_SCL", "XUSI_CMGP1_TXD_DO_SDA", "XUSI_CMGP2_CTSN_CSN_SDA", "XUSI_CMGP2_RTSN_DI_SCL", "XUSI_CMGP2_RXD_CLK_SCL", "XUSI_CMGP2_TXD_DO_SDA", "XUSI_CMGP3_CTSN_CSN_SDA", "XUSI_CMGP3_RTSN_DI_SCL", "XUSI_CMGP3_RXD_CLK_SCL", "XUSI_CMGP3_TXD_DO_SDA", "XUSI0_CTSN_CSN_SDA", "XUSI0_RTSN_DI_SCL", "XUSI0_RXD_CLK_SCL", "XUSI0_TXD_DO_SDA", "XUSI1_CTSN_CSN_SDA", "XUSI1_RTSN_DI_SCL", "XUSI1_RXD_CLK_SCL", "XUSI1_TXD_DO_SDA", "XUSI2_CTSN_CSN_SDA", "XUSI2_RTSN_DI_SCL", "XUSI2_RXD_CLK_SCL", "XUSI2_TXD_DO_SDA", "XUSI3_CTSN_CSN_SDA", "XUSI3_RTSN_DI_SCL", "XUSI3_RXD_CLK_SCL", "XUSI3_TXD_DO_SDA", "XUSI4_CTSN_CSN_SDA", "XUSI4_RTSN_DI_SCL", "XUSI4_RXD_CLK_SCL", "XUSI4_TXD_DO_SDA", "XUSI5_CTSN_CSN_SDA", "XUSI5_RTSN_DI_SCL", "XUSI5_RXD_CLK_SCL", "XUSI5_TXD_DO_SDA", "XUSI6_CLK", "XUSI6_CSN", "XUSI6_DI", "XUSI6_DO", "XUSI7_SCL", "XUSI7_SDA", "XWLBT_RFIC_CTRL0", "XWLBT_RFIC_CTRL1", "XWRESET_N", "XRTCCLK_IN" };


            for (int i = 6; i <= ptop_power_data.GetLength(0); i++)
            {

                if (i>=8 && ptop_power_data?[i-1,2] == "")
                {
                    break;
                }

                //if (ptop_power_data[i - 1, 3].ToUpper() == "ALL_PINS")
                //{
                //    for (int k = 0; k < all_pins.GetLength(0); k++)
                //    {
                //        for (int j = 1; j <= ptop_power_data.GetLength(1); j++)
                //        {
                //            if (j == 4)
                //            {
                //                power_txt.Write(all_pins[k] + "\t");
                //                continue;
                //            }

                //            if (time_fomula_check[i - 1, j - 1] == "fomula")
                //            {
                //                double aaa = Convert.ToDouble(time_data_txt[i - 1, j - 1]);
                //                double number2 = Math.Round(aaa, 13);
                //                string str = string.Format("{0:f12}", number2);
                //                power_txt.Write(str + "\t");
                //            }

                //            else
                //            {
                //                power_txt.Write(ptop_power_data[i - 1, j - 1] + "\t");

                //            }

                //        }
                //        power_txt.Write("\n");

                //    }
                //    continue;
                //}


                for (int j = 1; j <= ptop_power_data.GetLength(1); j++)
                {

                    if (time_fomula_check[i - 1, j - 1] == "fomula")
                    {
                        double aaa = Convert.ToDouble(time_data_txt[i - 1, j - 1]);
                        double number2 = Math.Round(aaa, 13);
                        string str = string.Format("{0:f12}", number2);
                        power_txt.Write(str + "\t");
                    }

                    else
                    {
                        power_txt.Write(ptop_power_data[i - 1, j - 1] + "\t");

                    }

                }
                power_txt.Write("\n");
            }

            power_txt.Close();

        }



        public void MakeTimingBatFile(List<string> power_list_name, string power_list2)
        {

            DirectoryInfo dir = new DirectoryInfo(rootsavepath + "DAT\\");
            if (dir.Exists != true)
            {
                dir.Create();
            }

            string savePath = rootsavepath + "DAT\\" + power_list2 + ".bat";
            StreamWriter power_txt_name = new StreamWriter(new FileStream(savePath, FileMode.Create));

            power_txt_name.WriteLine("@echo off");
            power_txt_name.WriteLine("echo USAGE : CompileTSET TSET_FILE");
            power_txt_name.WriteLine("rem ======== PSET ========");
            power_txt_name.WriteLine("\n");


            for (int i = 0; i < power_list_name.Count; i++)
            {
                if (i == 0)
                {
                    power_txt_name.WriteLine(@".\UTIL\tset2bin -xls -nano -pin ./BIN/PINMAP_MAKALU.dat.pin -tset ./Timing/{0}.dat > tset_log.txt", power_list_name[i]);
                    //power_txt_name.WriteLine(@".\UTIL\tset2bin -xls -nano -pin ./BIN/PINMAP_MAKALU.dat.pin -tset ./PAT/{0}.dat > tset_log.txt", "TSET_" + power_list_name[i]);
                }
                else
                {
                    power_txt_name.WriteLine(@".\UTIL\tset2bin -xls -nano -pin ./BIN/PINMAP_MAKALU.dat.pin -tset ./Timing/{0}.dat >> tset_log.txt", power_list_name[i]);
                    //power_txt_name.WriteLine(@".\UTIL\tset2bin -xls -nano -pin ./BIN/PINMAP_MAKALU.dat.pin -tset ./PAT/{0}.dat >> tset_log.txt", "TSET_" + power_list_name[i]);
                    //power_txt_name.WriteLine("pause");    
                }
            }

            power_txt_name.WriteLine("\n");
            power_txt_name.WriteLine(@"move .\Timing\*.bin .\BIN");
            power_txt_name.WriteLine(@"move .\Timing\*.dat.txt .\TEMP");
            power_txt_name.WriteLine("\n");
            power_txt_name.WriteLine("pause");



            power_txt_name.Close();

        }


        public void MakeTimeNmaeFile(List<string> power_list_name, string power_list2)
        {

            DirectoryInfo dir = new DirectoryInfo(rootsavepath + "DAT\\");
            if (dir.Exists != true)
            {
                dir.Create();
            }


            string savePath = rootsavepath + "DAT\\" + power_list2 + ".txt";
            StreamWriter power_txt_name = new StreamWriter(new FileStream(savePath, FileMode.Create));

            for (int i = 0; i < power_list_name.Count; i++)
            {
                //power_txt_name.WriteLine("TSET_" + power_list_name[i].ToString() + ".dat");
                power_txt_name.WriteLine(power_list_name[i].ToString() + ".dat");
            }
            power_txt_name.Close();

        }
        
        public void MakeErrorFile()
        {

            string savePath = rootsavepath + "timing_making_error.txt";
            StreamWriter power_txt_name = new StreamWriter(new FileStream(savePath, FileMode.Create));

            for (int i = 0; i < timing_error.Count; i++)
            {
                //power_txt_name.WriteLine("TSET_" + power_list_name[i].ToString() + ".dat");
                power_txt_name.WriteLine(timing_error[i].ToString());
            }
            power_txt_name.Close();

        }


        public void time_getDCsheet(string dc_name)
        {
            ac_sheet = ate_bb.Worksheets[dc_name];
            ac_range = ac_sheet.UsedRange;
            ac_data = ac_range.Value2;
        }

        public void time_getLvlsheet(string level)
        {
            time_sheet = ate_bb.Worksheets[level];
            time_range = time_sheet.UsedRange;
            time_data = time_range.Value2;
            time_data_fomula = time_range.Formula;
        }

        public void time_getptopPower(string name)
        {
            ptop_time_sheet = ate_bb.Worksheets[name];
            ptop_time_range = ptop_time_sheet.UsedRange;
            ptop_time = ptop_time_range.Value2;
            ptop_time_fomula = ptop_time_range.Formula;

        }

    }

}


