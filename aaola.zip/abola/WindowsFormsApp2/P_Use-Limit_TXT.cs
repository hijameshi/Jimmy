﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Runtime.InteropServices;
using Microsoft.Office.Interop.Excel;
using Excel = Microsoft.Office.Interop.Excel;
using System.IO;
using System.Text.RegularExpressions;

namespace abola
{
    partial class Bolt
    {

        public void MakeUseLimit(int w, int uselimit_cnt,int uselimitcrosscheck)
        {

            flow_num++;

            string Name = ate_data[w, 8]?.ToString();

            string HBIN = "-1";
            string SBIN = "-1";
            string flag1 = "-1";
            string flag2 = "-1";
            string flag3 = "-1";
            string flag4 = "-1";


            if(ate_data[w, 17]?.ToString() != null) HBIN = ate_data[w, 17]?.ToString();
            if(ate_data[w, 19]?.ToString() != null) SBIN = ate_data[w, 19]?.ToString();
            if(ate_data[w, 49]?.ToString() != null) flag1 = ate_data[w, 49]?.ToString();
            if(ate_data[w, 50]?.ToString() != null) flag2 = ate_data[w, 50]?.ToString();

            string op = "AND";

            string judge1 = "TRUE";
            string judge2 = "TRUE";
            string judge3 = "-1";
            string judge4 = "-1";

            //if (uselimit_cnt != uselimitcrosscheck)
            //{
            //    this.uselimit_cnt = 1;
            //}

            if (uselimit_cnt == 1) { judge1 = "TRUE"; judge2 = "TRUE"; }
            if (uselimit_cnt == 2) { judge1 = "TRUE"; judge2 = "FALSE"; }
            if (uselimit_cnt == 3) { judge1 = "FALSE"; judge2 = "TRUE"; }


            flow.WriteLine("testnum++; /*Use-Limit*/ /*{0}*/ pf_result = bintable(testnum, " + '"' + "{1}" + '"' + ", {2}, {3}, {4}, {5}, " + '"' + "{6}" + '"' + ", {7}, {8}, {9}, {10}, {11}, {12}); FLAG_CHECK_OUT();"
                , flow_num, Name, flag1, flag2, flag3, flag4, op, judge1, judge2, judge3, judge4, HBIN, SBIN);
        }
    }
}


