﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Runtime.InteropServices;
using Microsoft.Office.Interop.Excel;
using Excel = Microsoft.Office.Interop.Excel;
using System.IO;
using System.Text.RegularExpressions;

namespace abola
{
    partial class Bolt
    {

        List<string> bintable_name = new List<string>();
        List<string> flow_bintable_dft_name = new List<string>();

        public StreamWriter bintabletxt;

        string[,] bindable;
        string[,] bin_table_data;
        int[] name_count;
        int name_plus_num = 0;



        int bintabel_temp_num;
        int table_count = 0;
        int table_count_inflow = 0;

        int arg_count_judge = 0;
        int or_judge = 0;


        //public void MakeBinTable()
        //{

        //    string savePath = rootsavepath + "bintable.c";

        //    bintabletxt = new StreamWriter(new FileStream(savePath, FileMode.Create));

        //    for (int i = 1; i <= flow_bintable_object.GetLength(0); i++)
        //    {
        //        if (flow_bintable_object[i, 7]?.ToString() == "Bintable")
        //        {
        //            bintable_name.Add(flow_bintable_object[i, 8].ToString());
        //        }

        //    }


        //    bintable_name = bintable_name.Distinct().ToList();
        //    bindable = new string[bin_table_object.GetLength(0), bin_table_object.GetLength(1)];

        //    name_count = new int[bintable_name.Count()];


        //    //for (int i = 1; i <= ate_data.GetLength(0); i++)
        //    //{
        //    //        flow_bintable_dft_name.Add(temp_data[i + 3, 2]?.ToString());
        //    //}

        //    //flow_bintable_dft_name = flow_bintable_dft_name.Distinct().ToList();


        //    for (int i = 1; i <= bin_table_object.GetLength(0); i++)
        //    {
        //        for (int j = 1; j <= bin_table_object.GetLength(1); j++)
        //        {
        //            bindable[i - 1, j - 1] = bin_table_object[i, j]?.ToString();
        //        }
        //    }

        //    bin_table_data = new string[bindable.GetLength(0), bindable.GetLength(1) + 3];


        //    for (int i = 0; i < bintable_name.Count; i++)
        //    {
        //        bintabel_temp_num = 0;

        //        for (int j = 0; j < bindable.GetLength(0); j++)
        //        {
        //            if (bintable_name[i] == bindable[j, 1]?.ToString())
        //            {
        //                bintabel_temp_num++;
        //                bin_table_data[table_count, 0] = table_count.ToString();


        //                if (j > 0 && bindable[j, 2] == null && bindable[j, 1] == bindable[j - 1, 1])
        //                {
        //                    bindable[j, 2] = bindable[j - 1, 2];
        //                }

        //                for (int k = 1; k < bindable.GetLength(1); k++)
        //                {
        //                    bin_table_data[table_count, k] = bindable[j, k];
        //                }


        //                if (bindable[j, 9] != null)
        //                {
        //                    bin_table_data[table_count, 88] = "// T,F 2개 이상 ";
        //                }

        //                if (bindable[j, 3] == "OR")
        //                {
        //                    bin_table_data[table_count, 89] = "// OR !!!!!!!!!";
        //                }

        //                table_count++;
        //                //flow_bintable_dft
        //            }
        //        }
        //        name_count[i] = bintabel_temp_num;
        //    }


        //    int temp_cnt1 = 0;

        //    for (int i = 0; i < bin_table_data.GetLength(0); i++)
        //    {
        //        if (bin_table_data[i, 1] != null)
        //        {
        //            string Name = bin_table_data[i, 1];
        //            //if (name_count[temp_cnt1] > 1)
        //            //{
        //            //    name_plus_num++;
        //            //    Name = Name + "_" + name_plus_num;
        //            //}
        //            //temp_cnt1++;

        //            string flag = bin_table_data[i, 2];

        //            string[] flag_split;
        //            flag_split = flag?.Split(new char[] { ',' }, StringSplitOptions.None);

        //            string flag1 = flag_split?[0];
        //            string flag2 = "0";

        //            //string inform1 = "";
        //            //string inform2 = "";

        //            //if (bin_table_data?[i, 88] != null)
        //            string inform1 = bin_table_data?[i, 88];
        //            //if (bin_table_data?[i, 89] != null)
        //            string inform2 = bin_table_data?[i, 89];

        //            int cnt = 0;

        //            if (flag != null)
        //            {
        //                MatchCollection matches = Regex.Matches(flag, ",");
        //                cnt = matches.Count;
        //            }

        //            if (cnt >= 1)
        //            {
        //                flag2 = flag_split?[1];
        //            }

        //            string HBIN = bin_table_data[i, 5];
        //            string SBIN = bin_table_data[i, 4];


        //            string judge1 = bin_table_data[i, 7];
        //            if (judge1 == "T") judge1 = "TRUE";
        //            else if (judge1 == "F") judge1 = "FALSE";
        //            else judge1 = "0";
        //            //else MessageBox.Show("bintable judge 에 T, F 외 다른값 존재");



        //            string judge2 = bin_table_data[i, 8];
        //            if (judge2 == "T") judge2 = "TRUE";
        //            else if (judge2 == "F") judge2 = "FALSE";
        //            else judge2 = "0";
        //            //else MessageBox.Show("bintable judge 에 T, F 외 다른값 존재");


        //            //bintabletxt.WriteLine("testnum++;");
        //            //bintabletxt.WriteLine("TEST_STEP_IN(testoffset + testnum, " + '"' + '"' + ", G_FLAG_TRUE) {0} {1}", inform1, inform2);
        //            //bintabletxt.WriteLine("\tpf_result = bintable(testnum, "+ '"' + Name + '"' + ", {0}, {1}, {2}, {3}, {4}, {5});"
        //            //    , flag1, flag2, judge1, judge2, HBIN, SBIN);
        //            //bintabletxt.WriteLine("TEST_STEP_OUT(testoffset + testnum, " + '"' + '"' + ", G_FLAG_TRUE)");
        //            //bintabletxt.WriteLine();

        //            //bintabletxt.WriteLine("testnum++;");
        //            //bintabletxt.WriteLine("TEST_STEP_IN(testoffset + testnum, " + '"' + '"' + ", G_FLAG_TRUE) {0} {1}", inform1, inform2);
        //            bintabletxt.WriteLine("testnum++; pf_result = bintable(testnum, " + '"' + Name + '"' + ", {0}, {1}, {2}, {3}, {4}, {5});"
        //                , flag1, flag2, judge1, judge2, HBIN, SBIN);
        //            //bintabletxt.WriteLine("TEST_STEP_OUT(testoffset + testnum, " + '"' + '"' + ", G_FLAG_TRUE)");
        //            //bintabletxt.WriteLine();

        //        }
        //        name_plus_num = 0;


        //    }

        //    bintabletxt.Close();

        //    MessageBox.Show("완료");
        //}


        public void Makebintable_inflow(int w)
        {
            string bintablename = ate_data[w, 8]?.ToString();


            SelectWorksheet(out flow_bintable_sheet, bintablename);
            ReadRange(out flow_bintable_range, flow_bintable_sheet);
            CopyToArray(out flow_bintable_object, flow_bintable_range);




            for (int i = 1; i <= flow_bintable_object.GetLength(0); i++)
            {
                if (flow_bintable_object[i, 7]?.ToString().ToUpper() == "BINTABLE")
                {
                    bintable_name.Add(flow_bintable_object[i, 8].ToString());
                }

            }


            //bintable_name = bintable_name.Distinct().ToList();
            bindable = new string[bin_table_object.GetLength(0), bin_table_object.GetLength(1)];

            name_count = new int[bintable_name.Count()];


            //for (int i = 1; i <= ate_data.GetLength(0); i++)
            //{
            //        flow_bintable_dft_name.Add(temp_data[i + 3, 2]?.ToString());
            //}

            //flow_bintable_dft_name = flow_bintable_dft_name.Distinct().ToList();


            for (int i = 1; i <= bin_table_object.GetLength(0); i++)
            {
                for (int j = 1; j <= bin_table_object.GetLength(1); j++)
                {
                    bindable[i - 1, j - 1] = bin_table_object[i, j]?.ToString();
                }
            }

            bin_table_data = new string[bindable.GetLength(0), bindable.GetLength(1) + 3];


            for (int i = 0; i < bintable_name.Count; i++)
            {
                bintabel_temp_num = 0;

                for (int j = 0; j < bindable.GetLength(0); j++)
                {
                    if (bintable_name[i] == bindable[j, 1]?.ToString())
                    {
                        bintabel_temp_num++;
                        bin_table_data[table_count, 0] = table_count.ToString();


                        if (j > 0 && bindable[j, 2] == null && bindable[j, 1] == bindable[j - 1, 1])
                        {
                            bindable[j, 2] = bindable[j - 1, 2];
                        }

                        for (int k = 1; k < bindable.GetLength(1); k++)
                        {
                            bin_table_data[table_count, k] = bindable[j, k];
                        }


                        if (bindable[j, 9] != null)
                        {
                            int tempcnt1 = 0;
                            for(int o=7; o<=86; o++)
                            {
                                if (bindable[j, o] != null)
                                {
                                    tempcnt1++;
                                }
                            }
                            if (tempcnt1 > 4)
                            {
                                MessageBox.Show("BIN_TABLE 에 T,F 4개 이상 존재!!!!!, 프로그램 종료!! 컨버터 수정필요!!","종료",MessageBoxButtons.OK);

                                //Environment.Exit(0);
                                //System.Diagnostics.Process.GetCurrentProcess().Kill();
                                //this.Close();
                            }

                            bin_table_data[table_count, 88] = tempcnt1.ToString(); // "// T,F 2개 이상 ";
                        }

                        if (bindable[j, 3].ToUpper() != "AND")
                        {
                            if(bindable[j, 3].ToUpper() != "AND" && bindable[j, 3].ToUpper() != "OR")
                            {
                                MessageBox.Show("BIN_TABLE Op 항목에 AND, OR 외 다른 값 존재!!!!!, 프로그램 종료!! 컨버터 수정필요!!", "종료", MessageBoxButtons.OK);

                                Environment.Exit(0);
                                System.Diagnostics.Process.GetCurrentProcess().Kill();
                                this.Close();
                            }

                            bin_table_data[table_count, 89] = bindable[j, 3].ToUpper(); // "// OR !!!!!!!!!";
                        }

                        table_count++;
                        //flow_bintable_dft
                    }
                }
                name_count[i] = bintabel_temp_num;
            }


            int temp_cnt1 = 0;

            flow.WriteLine("//{0}", bintablename);

            for (int i = 0; i < bin_table_data.GetLength(0); i++)
            {
                if (bin_table_data[i, 1] != null)
                {
                    flow_num++;

                    string Name = bin_table_data[i, 1];
                    //if (name_count[temp_cnt1] > 1)
                    //{
                    //    name_plus_num++;
                    //    Name = Name + "_" + name_plus_num;
                    //}
                    //temp_cnt1++;

                    string flag = bin_table_data[i, 2];

                    string[] flag_split;
                    flag_split = flag?.Split(new char[] { ',' }, StringSplitOptions.None);

                    string flag1 = flag_split[0];
                    //flag1 = flag_split?[0];
                    string flag2 = "-1";
                    string flag3 = "-1";
                    string flag4 = "-1";


                    //Dictionary<string, string> mapName = new Dictionary<string, string>();


                    //    for (int a = 0; a < 100; a++)

                    //{

                    //    //원하는 변수명으로 해당 변수를 선언한 다음 map에다 추가

                    //    mapName.Add(String.Format("strName{0}", i.ToString()),"");



                    //    //변수 사용할 땐 이름으로 바로 호출

                    //    string aaa = mapName["strName" + a];

                    //}

                    //    int Rx0 = 0;
                    //    int Rx1 = 1;
                    //    int Rx2 = 2;

                    //Dictionary<string, int> dic = new Dictionary<string, int>()
                    //            {

                    //            {"Rx0",Rx0},
                    //            {"Rx1",Rx1},
                    //            {"Rx2",Rx2}
                    //            };


                    //    for (int q = 0; q < 3; q++)
                    //    {
                    //        GetDic(dic["Rx" + q.ToString()]);
                    //    }
                    //}

                    //void GetDic(int dicvalue)
                    //{
                    //    Console.WriteLine(dicvalue);
                    //}




                    //SortedList<string, object> flagarry = new SortedList<string, object>();
                    //for (int y = 1; y <= flag_split.GetLength(0); y++)
                    //{
                    //    flagarry.Add("flag" + y , flag_split[y-1]);
                    //    string aaa = flagarry.Contains(0),ti .Values(0);


                    //    //Result("Data1_Num" + y);
                    //}



                    //void Result(object key)
                    //{
                    //    int datanum = int.Parse(Data_Nums[key]);
                    //}


                    string[] flagarray = {  flag1,  flag2,  flag3,  flag4 };

                    //string inform1 = "";
                    //string inform2 = "";

                    //if (bin_table_data?[i, 88] != null)
                    string inform1 = bin_table_data?[i, 88];
                    //if (bin_table_data?[i, 89] != null)
                    string inform2 = bin_table_data?[i, 89];

                    int cnt = 0;

                    if (flag != null)
                    {
                        MatchCollection matches = Regex.Matches(flag, ",");
                        cnt = matches.Count;
                    }

                    if (cnt >= 1)
                    {
                            flag2 = flag_split[1];
                    }

                    if (cnt >= 2)
                    {
                        flag3 = flag_split[2];
                    }

                    if (cnt >= 3)
                    {
                        flag4 = flag_split[3];
                    }

                    //flag + "1" = "sdf";



                    string HBIN = bin_table_data[i, 5];
                    string SBIN = bin_table_data[i, 4];


                    string judge1 = bin_table_data[i, 7];
                    if (judge1 == "T") judge1 = "TRUE";
                    else if (judge1 == "F") judge1 = "FALSE";
                    else if (judge1 == null) judge1 = "-1";
                    else
                    {
                        //MessageBox.Show("bintable judge 에 T, F, 빈칸 외 다른값 존재");
                        MessageBox.Show("bintable judge 에 T, F, 빈칸 외 다른값 존재", "종료", MessageBoxButtons.OK);

                        Environment.Exit(0);
                        System.Diagnostics.Process.GetCurrentProcess().Kill();
                        this.Close();
                    }

                    string judge2 = bin_table_data[i, 8];
                    if (judge2 == "T") judge2 = "TRUE";
                    else if (judge2 == "F") judge2 = "FALSE";
                    else if (judge2 == null) judge2 = "-1";
                    else
                    {
                        //MessageBox.Show("bintable judge 에 T, F , 빈칸 외 다른값 존재");
                        MessageBox.Show("bintable judge 에 T, F , 빈칸 외 다른값 존재", "종료", MessageBoxButtons.OK);

                        Environment.Exit(0);
                        System.Diagnostics.Process.GetCurrentProcess().Kill();
                        this.Close();
                    }


                    string judge3 = bin_table_data[i, 9];
                    if (judge3 == "T") judge3 = "TRUE";
                    else if (judge3 == "F") judge3 = "FALSE";
                    else if (judge3 == null) judge3 = "-1";
                    else
                    {
                        //MessageBox.Show("bintable judge 에 T, F , 빈칸 외 다른값 존재");
                        MessageBox.Show("bintable judge 에 T, F , 빈칸 외 다른값 존재", "종료", MessageBoxButtons.OK);

                        Environment.Exit(0);
                        System.Diagnostics.Process.GetCurrentProcess().Kill();
                        this.Close();
                    }


                    string judge4 = bin_table_data[i, 10];
                    if (judge4 == "T") judge4 = "TRUE";
                    else if (judge4 == "F") judge4 = "FALSE";
                    else if (judge4 == null) judge4 = "-1";
                    else
                    {
                        //MessageBox.Show("bintable judge 에 T, F , 빈칸 외 다른값 존재");
                        MessageBox.Show("bintable judge 에 T, F , 빈칸 외 다른값 존재", "종료", MessageBoxButtons.OK);

                        Environment.Exit(0);
                        System.Diagnostics.Process.GetCurrentProcess().Kill();
                        this.Close();
                    }

                    string op;
                    op = bin_table_data[i, 3]?.ToUpper();


                    //bintabletxt.WriteLine("testnum++;");
                    //bintabletxt.WriteLine("TEST_STEP_IN(testoffset + testnum, " + '"' + '"' + ", G_FLAG_TRUE) {0} {1}", inform1, inform2);
                    //bintabletxt.WriteLine("\tpf_result = bintable(testnum, "+ '"' + Name + '"' + ", {0}, {1}, {2}, {3}, {4}, {5});"
                    //    , flag1, flag2, judge1, judge2, HBIN, SBIN);
                    //bintabletxt.WriteLine("TEST_STEP_OUT(testoffset + testnum, " + '"' + '"' + ", G_FLAG_TRUE)");
                    //bintabletxt.WriteLine();

                    //bintabletxt.WriteLine("testnum++;");
                    //bintabletxt.WriteLine("TEST_STEP_IN(testoffset + testnum, " + '"' + '"' + ", G_FLAG_TRUE) {0} {1}", inform1, inform2);
                    flow.WriteLine("testnum++; /*{0}*/ pf_result = bintable(testnum, " + '"' +  "{1}" + '"' + ", {2}, {3}, {4}, {5}, "+'"'+"{6}"+'"'+", {7}, {8}, {9}, {10}, {11}, {12}); FLAG_CHECK_OUT();"
                        ,flow_num, Name, flag1, flag2, flag3, flag4, op, judge1, judge2, judge3, judge4, HBIN, SBIN);
                    //bintabletxt.WriteLine("TEST_STEP_OUT(testoffset + testnum, " + '"' + '"' + ", G_FLAG_TRUE)");
                    //bintabletxt.WriteLine();


                    //Name = "";
                    //flag1 = "";
                    //flag2 = "";
                    //op = "";
                    //judge1 = "";
                    //judge2 = "";
                    //judge3 = "";
                    //judge4 = "";
                    //HBIN = "";
                    //SBIN = "";
                }
                name_plus_num = 0;



            }
            bintable_name.Clear();
        }

        public void Makebintable(int w)
        {
            string bintablename = ate_data[w, 8]?.ToString();

            bintable_name.Add(ate_data[w, 8]?.ToString());


            //bintable_name = bintable_name.Distinct().ToList();
            bindable = new string[bin_table_object.GetLength(0), bin_table_object.GetLength(1)];

            name_count = new int[bintable_name.Count()];


            //for (int i = 1; i <= ate_data.GetLength(0); i++)
            //{
            //        flow_bintable_dft_name.Add(temp_data[i + 3, 2]?.ToString());
            //}

            //flow_bintable_dft_name = flow_bintable_dft_name.Distinct().ToList();


            for (int i = 1; i <= bin_table_object.GetLength(0); i++)
            {
                for (int j = 1; j <= bin_table_object.GetLength(1); j++)
                {
                    bindable[i - 1, j - 1] = bin_table_object[i, j]?.ToString();
                }
            }

            bin_table_data = new string[bindable.GetLength(0), bindable.GetLength(1) + 3];


            for (int i = 0; i < bintable_name.Count; i++)
            {
                bintabel_temp_num = 0;

                for (int j = 0; j < bindable.GetLength(0); j++)
                {
                    if (bintable_name[i] == bindable[j, 1]?.ToString())
                    {
                        bintabel_temp_num++;
                        bin_table_data[table_count_inflow, 0] = table_count_inflow.ToString();


                        if (j > 0 && bindable[j, 2] == null && bindable[j, 1] == bindable[j - 1, 1])
                        {
                            bindable[j, 2] = bindable[j - 1, 2];
                        }

                        for (int k = 1; k < bindable.GetLength(1); k++)
                        {
                            bin_table_data[table_count_inflow, k] = bindable[j, k];
                        }


                        if (bindable[j, 9] != null)
                        {
                            int tempcnt1 = 0;
                            for (int o = 7; o <= 86; o++)
                            {
                                if (bindable[j, o] != null)
                                {
                                    tempcnt1++;
                                }
                            }
                            if (tempcnt1 > 4)
                            {
                                MessageBox.Show("BIN_TABLE 에 T,F 4개 이상 존재!!!!!, 프로그램 종료!! 컨버터 수정필요!!", "종료", MessageBoxButtons.OK);

                                //Environment.Exit(0);
                                //System.Diagnostics.Process.GetCurrentProcess().Kill();
                                //this.Close();
                            }

                            bin_table_data[table_count_inflow, 88] = tempcnt1.ToString(); // "// T,F 2개 이상 ";
                        }

                        if (bindable[j, 3].ToUpper() != "AND")
                        {
                            if (bindable[j, 3].ToUpper() != "AND" && bindable[j, 3].ToUpper() != "OR")
                            {
                                MessageBox.Show("BIN_TABLE Op 항목에 AND, OR 외 다른 값 존재!!!!!, 프로그램 종료!! 컨버터 수정필요!!", "종료", MessageBoxButtons.OK);

                                Environment.Exit(0);
                                System.Diagnostics.Process.GetCurrentProcess().Kill();
                                this.Close();
                            }

                            bin_table_data[table_count_inflow, 89] = bindable[j, 3].ToUpper(); // "// OR !!!!!!!!!";
                        }

                        table_count_inflow++;
                        //flow_bintable_dft
                    }
                }
                name_count[i] = bintabel_temp_num;
            }


            int temp_cnt1 = 0;

            flow.WriteLine("//{0}", bintablename);

            for (int i = 0; i < bin_table_data.GetLength(0); i++)
            {
                if (bin_table_data[i, 1] != null)
                {
                    flow_num++;

                    string Name = bin_table_data[i, 1];
                    //if (name_count[temp_cnt1] > 1)
                    //{
                    //    name_plus_num++;
                    //    Name = Name + "_" + name_plus_num;
                    //}
                    //temp_cnt1++;

                    string flag = bin_table_data[i, 2];

                    string[] flag_split;
                    flag_split = flag?.Split(new char[] { ',' }, StringSplitOptions.None);

                    string flag1 = flag_split[0];
                    //flag1 = flag_split?[0];
                    string flag2 = "-1";
                    string flag3 = "-1";
                    string flag4 = "-1";


                    //Dictionary<string, string> mapName = new Dictionary<string, string>();


                    //    for (int a = 0; a < 100; a++)

                    //{

                    //    //원하는 변수명으로 해당 변수를 선언한 다음 map에다 추가

                    //    mapName.Add(String.Format("strName{0}", i.ToString()),"");



                    //    //변수 사용할 땐 이름으로 바로 호출

                    //    string aaa = mapName["strName" + a];

                    //}

                    //    int Rx0 = 0;
                    //    int Rx1 = 1;
                    //    int Rx2 = 2;

                    //Dictionary<string, int> dic = new Dictionary<string, int>()
                    //            {

                    //            {"Rx0",Rx0},
                    //            {"Rx1",Rx1},
                    //            {"Rx2",Rx2}
                    //            };


                    //    for (int q = 0; q < 3; q++)
                    //    {
                    //        GetDic(dic["Rx" + q.ToString()]);
                    //    }
                    //}

                    //void GetDic(int dicvalue)
                    //{
                    //    Console.WriteLine(dicvalue);
                    //}




                    //SortedList<string, object> flagarry = new SortedList<string, object>();
                    //for (int y = 1; y <= flag_split.GetLength(0); y++)
                    //{
                    //    flagarry.Add("flag" + y , flag_split[y-1]);
                    //    string aaa = flagarry.Contains(0),ti .Values(0);


                    //    //Result("Data1_Num" + y);
                    //}



                    //void Result(object key)
                    //{
                    //    int datanum = int.Parse(Data_Nums[key]);
                    //}


                    string[] flagarray = { flag1, flag2, flag3, flag4 };

                    //string inform1 = "";
                    //string inform2 = "";

                    //if (bin_table_data?[i, 88] != null)
                    string inform1 = bin_table_data?[i, 88];
                    //if (bin_table_data?[i, 89] != null)
                    string inform2 = bin_table_data?[i, 89];

                    int cnt = 0;

                    if (flag != null)
                    {
                        MatchCollection matches = Regex.Matches(flag, ",");
                        cnt = matches.Count;
                    }

                    if (cnt >= 1)
                    {
                        flag2 = flag_split[1];
                    }

                    if (cnt >= 2)
                    {
                        flag3 = flag_split[2];
                    }

                    if (cnt >= 3)
                    {
                        flag4 = flag_split[3];
                    }

                    //flag + "1" = "sdf";



                    string HBIN = bin_table_data[i, 5];
                    string SBIN = bin_table_data[i, 4];


                    string judge1 = bin_table_data[i, 7];
                    if (judge1 == "T") judge1 = "TRUE";
                    else if (judge1 == "F") judge1 = "FALSE";
                    else if (judge1 == null) judge1 = "-1";
                    else
                    {
                        //MessageBox.Show("bintable judge 에 T, F, 빈칸 외 다른값 존재");
                        MessageBox.Show("bintable judge 에 T, F, 빈칸 외 다른값 존재", "종료", MessageBoxButtons.OK);

                        Environment.Exit(0);
                        System.Diagnostics.Process.GetCurrentProcess().Kill();
                        this.Close();
                    }

                    string judge2 = bin_table_data[i, 8];
                    if (judge2 == "T") judge2 = "TRUE";
                    else if (judge2 == "F") judge2 = "FALSE";
                    else if (judge2 == null) judge2 = "-1";
                    else
                    {
                        //MessageBox.Show("bintable judge 에 T, F , 빈칸 외 다른값 존재");
                        MessageBox.Show("bintable judge 에 T, F , 빈칸 외 다른값 존재", "종료", MessageBoxButtons.OK);

                        Environment.Exit(0);
                        System.Diagnostics.Process.GetCurrentProcess().Kill();
                        this.Close();
                    }


                    string judge3 = bin_table_data[i, 9];
                    if (judge3 == "T") judge3 = "TRUE";
                    else if (judge3 == "F") judge3 = "FALSE";
                    else if (judge3 == null) judge3 = "-1";
                    else
                    {
                        //MessageBox.Show("bintable judge 에 T, F , 빈칸 외 다른값 존재");
                        MessageBox.Show("bintable judge 에 T, F , 빈칸 외 다른값 존재", "종료", MessageBoxButtons.OK);

                        Environment.Exit(0);
                        System.Diagnostics.Process.GetCurrentProcess().Kill();
                        this.Close();
                    }


                    string judge4 = bin_table_data[i, 10];
                    if (judge4 == "T") judge4 = "TRUE";
                    else if (judge4 == "F") judge4 = "FALSE";
                    else if (judge4 == null) judge4 = "-1";
                    else
                    {
                        //MessageBox.Show("bintable judge 에 T, F , 빈칸 외 다른값 존재");
                        MessageBox.Show("bintable judge 에 T, F , 빈칸 외 다른값 존재", "종료", MessageBoxButtons.OK);

                        Environment.Exit(0);
                        System.Diagnostics.Process.GetCurrentProcess().Kill();
                        this.Close();
                    }

                    string op;
                    op = bin_table_data[i, 3]?.ToUpper();


                    //bintabletxt.WriteLine("testnum++;");
                    //bintabletxt.WriteLine("TEST_STEP_IN(testoffset + testnum, " + '"' + '"' + ", G_FLAG_TRUE) {0} {1}", inform1, inform2);
                    //bintabletxt.WriteLine("\tpf_result = bintable(testnum, "+ '"' + Name + '"' + ", {0}, {1}, {2}, {3}, {4}, {5});"
                    //    , flag1, flag2, judge1, judge2, HBIN, SBIN);
                    //bintabletxt.WriteLine("TEST_STEP_OUT(testoffset + testnum, " + '"' + '"' + ", G_FLAG_TRUE)");
                    //bintabletxt.WriteLine();

                    //bintabletxt.WriteLine("testnum++;");
                    //bintabletxt.WriteLine("TEST_STEP_IN(testoffset + testnum, " + '"' + '"' + ", G_FLAG_TRUE) {0} {1}", inform1, inform2);
                    flow.WriteLine("testnum++; /*{0}*/ pf_result = bintable(testnum, " + '"' + "{1}" + '"' + ", {2}, {3}, {4}, {5}, " + '"' + "{6}" + '"' + ", {7}, {8}, {9}, {10}, {11}, {12}); FLAG_CHECK_OUT();"
                        , flow_num, Name, flag1, flag2, flag3, flag4, op, judge1, judge2, judge3, judge4, HBIN, SBIN);
                    //bintabletxt.WriteLine("TEST_STEP_OUT(testoffset + testnum, " + '"' + '"' + ", G_FLAG_TRUE)");
                    //bintabletxt.WriteLine();


                    //Name = "";
                    //flag1 = "";
                    //flag2 = "";
                    //op = "";
                    //judge1 = "";
                    //judge2 = "";
                    //judge3 = "";
                    //judge4 = "";
                    //HBIN = "";
                    //SBIN = "";
                }
                name_plus_num = 0;



            }
            bintable_name.Clear();
        }


    }
}
