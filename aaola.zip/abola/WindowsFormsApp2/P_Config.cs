﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Runtime.InteropServices;
using Microsoft.Office.Interop.Excel;
using Excel = Microsoft.Office.Interop.Excel;
using System.IO;
using System.Configuration;
using System.Reflection;
using System.Linq.Expressions;

namespace abola
{
    partial class Bolt
    {

        public static string ate_open_path;
        public static string bolt_save_path;
        public static string bolt_open_path;
        public static Configuration config;

        public void checkfile(string path)
        {
            configinit(nameof(ate_open_path), nameof(bolt_save_path), nameof(bolt_open_path));

            ate_open_path = configload(nameof(ate_open_path));
            bolt_save_path = configload(nameof(bolt_save_path));
            bolt_open_path = configload(nameof(bolt_open_path));

            
        }

        public void configinit(params string[] key)
        {
            config = ConfigurationManager.OpenExeConfiguration(ConfigurationUserLevel.None);

            
            foreach (string s in key)
            {
                ConfigurationManager.RefreshSection(s);
            }
        }

        //public string getvarname<T>(Expression<Func<T>> expr)
        //{
        //    var body = (MemberExpression)expr.Body;
        //    return body.Member.Name;
        //}

        public string configload(string pathname)
        {

            //string pathname = nameof(path);

            string configpath = ConfigurationManager.AppSettings[pathname];
            return configpath;
        }


        public void configsave(string destination, string data)
        {
            config.AppSettings.Settings[destination].Value = data;
            config.Save(ConfigurationSaveMode.Modified);
            ConfigurationManager.RefreshSection(destination);

        }


        public void configexample(string destination, string data)
        {
            Configuration config = ConfigurationManager.OpenExeConfiguration(ConfigurationUserLevel.None);

            ConfigurationManager.RefreshSection(destination);

            //쓰기
            config.AppSettings.Settings[destination].Value = data;
            //읽기
            string value = ConfigurationManager.AppSettings[destination];

            config.Save(ConfigurationSaveMode.Modified);
            ConfigurationManager.RefreshSection("appSettings");

            Console.WriteLine(value);
        }



    }
}
