﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Runtime.InteropServices;
using Microsoft.Office.Interop.Excel;
using Excel = Microsoft.Office.Interop.Excel;
using System.IO;

namespace abola
{
    partial class Bolt
    {

        public void rootsavepathdir()
        {
            string rootpath = bolt_open_path;

            if (rootpath != "")
            {
                int temp = rootpath.LastIndexOf("\\");
                string tempstr = rootpath.Substring(0, temp + 1);
                rootsavepath = tempstr;
            }
            else
            {
                rootsavepath = @"D:\PERSONAL_SPACE\BOLT\";
            }

        }


        public void ReadExcel(out Workbook book, string name)
        {
            //this.path = path;
            book = app.Workbooks.Open(name);
                //ws = wb.Worksheets[Sheet];
                //MessageBox.Show("Open 완료");
            
        }


        public void CopyToCell(Worksheet sheet, object[,] data)
        {
            //sheet = book.Worksheets[sheet];
            Range range = sheet.UsedRange;
            range = range.Resize[10000, 200];
            range.Value2 = data;

        }

        public void CopyToCell(Worksheet sheet, object[,] data, out object[,] save)
        {
            //sheet = book.Worksheets[sheet];
            Range range = sheet.UsedRange;
            range = range.Resize[10000,200];
            range.Value2 = data;
            //save = data;
            save = range.Value2;
            range = range.Resize[100, 100];

        }

        public void CreatNewFile(out Workbook book)
        {
            book = app.Workbooks.Add(1);
        }
        
        public void CreatNewSheet()
        {
            Worksheet tempsheet = ptop_bb.Worksheets.Add();
        }

        public void CreatNewSheet(string ptop_ss_name)
        {
            ptop_ss = ptop_bb.Worksheets.Add();
            ptop_ss.Name = (ptop_ss_name);
        }

        public void CreatNewSheet(Workbook book, out Worksheet sheet, string name)
        {
            sheet = book.Worksheets.Add();
            sheet.Name = (name);
        }


        public void CreatNewSheet(Workbook book, out Worksheet sheet, string name, string after_val)
        {
            Worksheet temp_ss = book.Worksheets[after_val];
            sheet = book.Worksheets.Add(After: temp_ss);
            sheet.Name = (name);
        }

        public void CreatNewSheet(string ptop_ss_name, string after_val)
        {
            Worksheet temp_ss = ptop_bb.Worksheets[after_val];
            ptop_ss = ptop_bb.Worksheets.Add(After: temp_ss);
            ptop_ss.Name = (ptop_ss_name);
        }

        public void CreatNewSheet_temp(string ptop_ss_name)
        {
            ptop_ss_temp = ptop_bb.Worksheets.Add();
            ptop_ss_temp.Name = (ptop_ss_name);
        }

        public void CreatNewSheet_temp(string ptop_ss_name, string after_val)
        {
            ptop_ss_temp = ptop_bb.Worksheets.Add(After: after_val);
            ptop_ss_temp.Name = (ptop_ss_name);
        }

        public void CreatNewSheet_temp2(string ptop_ss_name, string after_val)
        {
            newmake_ss = ptop_bb.Worksheets.Add(After: after_val);
            newmake_ss.Name = (ptop_ss_name);
        }

        public void SelectWorksheet(string ate_ss_name)
        {

            ate_ss = ate_bb.Worksheets[ate_ss_name];
        }

        public void SelectWorksheet(Workbook book, out Worksheet sheet, string name)
        {

            sheet = book.Worksheets[name];
        }

        public void SelectWorksheet(out Worksheet sheet, string ate_ss_name)
        {
            sheet = ate_bb.Worksheets[ate_ss_name];

        }

        public void SelectWorksheet(string mode, string ate_ss_name)
        {
            if (mode == "temp")
            {
                temp_ss = ate_bb.Worksheets[ate_ss_name];
            }
            else
                ate_ss = ate_bb.Worksheets[ate_ss_name];
        }

        public void ReadRange()
        {
            //ate_range = null;
            ate_range = ate_ss.UsedRange;
        }

        public void ReadRange(Worksheet sheet, out Range range)
        {
            //ate_range = null;
            range = sheet.UsedRange;
        }

        public void ReadRange(Worksheet sheet, out Range range, string xy)
        {
            //ate_range = null;
            range = sheet.Range[xy];
        }


        public void ReadRange(out Range range, Worksheet sheet)
        {
            range = sheet.UsedRange;
        }


        public void ReadRange(string mode)
        {
            if (mode == "temp")
            {
                temp_range = temp_ss.UsedRange;
            }
            else
                ate_range = ate_ss.UsedRange;
        }


        public void CopyToArray()
        {
            //ate_data = null;
            ate_data = ate_range.Value2;
        }

        public void CopyToArrayString()
        {
            for (int i = 0; i < ate_data.GetLength(0); i++)
            {
                for (int j = 0; j < ate_data.GetLength(1); j++)
                {
                    ate_data_string[i, j] = ate_data[i, j]?.ToString();
                }
            }
        }

        public void CopyToArray(Range range, out object[,] data)
        {
            //ate_data = null;
            data = range.Value2;
        }

        public void CopyToArray(out object[,] data_object, Range range)
        {
            //ate_data = null;
            data_object = range.Value2;
        }

        public void RangeResize(ref Range range, int x, int y)
        {
            range = range.Resize[x, y];
        }
        

        //public void CopyToArray()
        //{
        //    ate_data_object = ate_range.Value2;
        //    ate_data = new string[ate_data_object.GetLength(0) + 1, ate_data_object.GetLength(1) + 1];
        //    for (int i = 1; i <= ate_data_object.GetLength(0); i++)
        //    {
        //        for (int j = 1; j <= ate_data_object.GetLength(1); j++)
        //        {
        //            ate_data[i, j] = ate_data_object[i, j]?.ToString();
        //        }
        //    }
        //}

        public void CopyToArray(string mode)
        {
            if (mode == "temp")
                temp_data = temp_range.Value2;
            else
                ate_data = ate_range.Value2;
        }

        public void Form_FormClosing(object sender, FormClosingEventArgs e)
        {
            Close();
            if (MessageBox.Show("종료할까요?", "Text",
                MessageBoxButtons.YesNo, MessageBoxIcon.Question,
                MessageBoxDefaultButton.Button1) == DialogResult.No)
            {
                e.Cancel = true;
            }
        }

        public void Close()
        {

            //System.Diagnostics.Process[] mProcess = System.Diagnostics.Process.GetProcessesByName(Application.ProductName);
            //foreach (System.Diagnostics.Process p in mProcess)
            //    p.Kill();

            ate_bb?.Close(SaveChanges : false);
            ptop_bb?.Close();
            app.Quit();


            //System.Diagnostics.Process.GetCurrentProcess().Kill();



            //if (Excel!=null) Marshal.ReleaseComObject(Excel);
            //if (app != null) Marshal.ReleaseComObject(app);
            if (ate_range != null) Marshal.ReleaseComObject(ate_range);
            if (temp_range != null) Marshal.ReleaseComObject(temp_range);
            if (ptop_flow_range != null) Marshal.ReleaseComObject(ptop_flow_range);
            if (ptop_instance_range != null) Marshal.ReleaseComObject(ptop_instance_range);
            if (ptop_summary_range != null) Marshal.ReleaseComObject(ptop_summary_range);
            if (init_range != null) Marshal.ReleaseComObject(init_range);
            if (ptop_ss_temp != null) Marshal.ReleaseComObject(ptop_ss_temp);
            if (newmake_ss != null) Marshal.ReleaseComObject(newmake_ss);
            if (ate_ss != null) Marshal.ReleaseComObject(ate_ss);
            if (ptop_ss != null) Marshal.ReleaseComObject(ptop_ss);
            if (temp_ss != null) Marshal.ReleaseComObject(temp_ss);
            if (ate_bb != null) Marshal.ReleaseComObject(ate_bb);
            if (ptop_bb != null) Marshal.ReleaseComObject(ptop_bb);


        }


        public void openfile(string path)
        {
            //this.path = path;
            ate_bb = app.Workbooks.Open(path);
        }
    }
}
    
