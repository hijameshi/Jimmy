﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Runtime.InteropServices;
using Microsoft.Office.Interop.Excel;
using Excel = Microsoft.Office.Interop.Excel;
using System.IO;

namespace abola
{

    partial class Bolt
    {

        public string ate_open_file_path;
        public string bolt_save_file_path;
        public string bolt_open_file_path;
        public void atefileopen()
        {

            Form1 f = new Form1();
            ate_open_file_path = "";
            //string file_path = null;
            //openFileDialog1.InitialDirectory = "c:\\";
            if (ate_open_path != "")
            {
                int temp = ate_open_path.LastIndexOf("\\");
                string tempstr = ate_open_path.Substring(temp + 1, ate_open_path.Length - temp - 1);
                f.openFileDialog1.FileName = tempstr;
            }

            if (f.openFileDialog1.ShowDialog() == DialogResult.OK)
            {

                    ate_open_file_path = f.openFileDialog1.FileName;
                //f.textBox1.Text = ate_open_file_path;
                ate_open_path = ate_open_file_path;
                    configsave(nameof(ate_open_path), ate_open_file_path);
            }
                //string text = File.ReadAllText(file_path);
                //richTextBox1.Text = text;
                //p.open(text);

        }
        public void boltfilesave()
        {
            Form1 f = new Form1();
            bolt_save_file_path = "";
            //foldername.Clear();
            //SaveFileDialog save = new SaveFileDialog();
            f.saveFileDialog1.DefaultExt = "xlsx";
            f.saveFileDialog1.Filter = "*.xlsx|*.xlsx";

            if (bolt_save_path != "")
            {
                int temp = bolt_save_path.LastIndexOf("\\");
                string tempstr = bolt_save_path.Substring(temp + 1, bolt_save_path.Length - temp - 1);
                f.saveFileDialog1.FileName = tempstr;
            }

            //save.Filter = "*.txt|*.txt";
            //openFileDialog1.InitialDirectory = "c:\\";
            if (f.saveFileDialog1.ShowDialog() == DialogResult.OK)
            {
                bolt_save_file_path = f.saveFileDialog1.FileName;
                bolt_save_path = bolt_save_file_path;
                bolt_open_path = bolt_save_file_path;
                configsave(nameof(bolt_save_path), bolt_save_file_path);
                configsave(nameof(bolt_open_path), bolt_save_file_path);

            }
        }

        public void boltfileopen()
        {

            Form1 f = new Form1();
            bolt_open_file_path = "";
            //string file_path = null;
            //openFileDialog1.InitialDirectory = "c:\\";

            if (bolt_open_path != "")
            {
                int temp = bolt_open_path.LastIndexOf("\\");
                string tempstr = bolt_open_path.Substring(temp + 1, bolt_open_path.Length - temp - 1);
                f.openFileDialog2.FileName = tempstr;
            }

            if (f.openFileDialog2.ShowDialog() == DialogResult.OK)
            {

                bolt_open_file_path = f.openFileDialog2.FileName;
                //f.textBox3.Text = bolt_open_file_path;
                bolt_open_path = bolt_open_file_path;
                configsave(nameof(bolt_open_path), bolt_open_file_path);
            }
            //string text = File.ReadAllText(file_path);
            //richTextBox1.Text = text;
            //p.open(text);

        }


    }
}
